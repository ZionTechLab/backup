import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

def list_models():
    api_key_input = os.getenv("GEMINI_API_KEY")
    if not api_key_input:
        print("Error: GEMINI_API_KEY not found in .env")
        return

    genai.configure(api_key=api_key_input)
    
    print("\n--- Available Models ---")
    try:
        for m in genai.list_models():
            if 'generateContent' in m.supported_generation_methods:
                print(f"- {m.name} ({m.display_name})")
    except Exception as e:
        print(f"Error listing models: {e}")

if __name__ == "__main__":
    list_models()
