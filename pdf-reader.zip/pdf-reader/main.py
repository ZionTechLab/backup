import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import os
import sys
import subprocess
import threading
from pdf_processor import PDFProcessor

# Set appearance mode and color theme
ctk.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"

class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("PDF Analyst & Extractor")
        self.geometry("900x700")

        self.pdf_processor = None
        self.current_file = None

        self.create_widgets()

    def create_widgets(self):
        # Grid layout configuration
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # --- Sidebar ---
        self.sidebar_frame = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, rowspan=4, sticky="nsew")
        self.sidebar_frame.grid_rowconfigure(4, weight=1)

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="PDF Tool", font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))

        self.open_button = ctk.CTkButton(self.sidebar_frame, text="Open PDF", command=self.open_pdf)
        self.open_button.grid(row=1, column=0, padx=20, pady=10)

        self.mappings_button = ctk.CTkButton(self.sidebar_frame, text="Open Mappings Folder", command=self.open_mappings_folder)
        self.mappings_button.grid(row=2, column=0, padx=20, pady=10)

        self.reload_mappings_button = ctk.CTkButton(self.sidebar_frame, text="Reload Mappings", command=self.reload_mappings)
        self.reload_mappings_button.grid(row=3, column=0, padx=20, pady=10)
        
        self.list_fonts_button = ctk.CTkButton(self.sidebar_frame, text="List Fonts", command=self.list_fonts)
        self.list_fonts_button.grid(row=4, column=0, padx=20, pady=10)
        
        self.export_button = ctk.CTkButton(self.sidebar_frame, text="Export Markdown", command=self.export_markdown)
        self.export_button.grid(row=5, column=0, padx=20, pady=10)
        
        self.use_ocr_check = ctk.CTkCheckBox(self.sidebar_frame, text="Use OCR (Tesseract)")
        self.use_ocr_check.grid(row=6, column=0, padx=20, pady=10)

        # Gemini API Key
        self.api_key_label = ctk.CTkLabel(self.sidebar_frame, text="Gemini API Key:", anchor="w")
        self.api_key_label.grid(row=7, column=0, padx=20, pady=(10, 0))
        self.api_key_entry = ctk.CTkEntry(self.sidebar_frame, placeholder_text="Enter API Key", show="*")
        self.api_key_entry.grid(row=8, column=0, padx=20, pady=(0, 10))

        # Smart Extract Toggle
        self.smart_extract_check = ctk.CTkCheckBox(self.sidebar_frame, text="Smart Extract (Gemini)")
        self.smart_extract_check.grid(row=9, column=0, padx=20, pady=10)

        # --- Main Content ---
        
        # Top Info Bar
        self.info_frame = ctk.CTkFrame(self)
        self.info_frame.grid(row=0, column=1, padx=20, pady=20, sticky="ew")
        
        self.file_label = ctk.CTkLabel(self.info_frame, text="No File Selected", anchor="w")
        self.file_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        self.type_label = ctk.CTkLabel(self.info_frame, text="Type: N/A", font=ctk.CTkFont(weight="bold"))
        self.type_label.grid(row=0, column=1, padx=10, pady=10, sticky="e")
        
        # Controls
        self.controls_frame = ctk.CTkFrame(self)
        self.controls_frame.grid(row=1, column=1, padx=20, pady=(0, 20), sticky="ew")

        self.page_range_label = ctk.CTkLabel(self.controls_frame, text="Page Range (e.g. 1-5, 8):")
        self.page_range_label.pack(side="left", padx=10)
        
        self.page_range_entry = ctk.CTkEntry(self.controls_frame, width=150)
        self.page_range_entry.pack(side="left", padx=10)
        
        self.process_button = ctk.CTkButton(self.controls_frame, text="Analyze & Extract", command=self.process_pdf, state="disabled")
        self.process_button.pack(side="left", padx=10)

        # Output Area
        self.output_textbox = ctk.CTkTextbox(self, width=600)
        self.output_textbox.grid(row=2, column=1, padx=20, pady=(0, 20), sticky="nsew")
        self.output_textbox.insert("0.0", "Output will appear here...\n")

    def open_pdf(self):
        file_path = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
        if file_path:
            self.current_file = file_path
            self.file_label.configure(text=f"File: {os.path.basename(file_path)}")
            self.pdf_processor = PDFProcessor(file_path) # Create processor instance
            if self.pdf_processor.open():
               self.type_label.configure(text="Ready to Analyze")
               self.process_button.configure(state="normal")
            else:
               self.type_label.configure(text="Error Opening File")

    def open_mappings_folder(self):
        mappings_path = os.path.abspath("mappings")
        if not os.path.exists(mappings_path):
            os.makedirs(mappings_path)
        
        if sys.platform == "win32":
            os.startfile(mappings_path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", mappings_path])
        else:
            subprocess.Popen(["xdg-open", mappings_path])

    def reload_mappings(self):
        if self.pdf_processor:
             self.pdf_processor.mapper.load_mappings()
             messagebox.showinfo("Success", "Mappings reloaded successfully!")
        else:
             # Just reload if processor not init yet 
             # (actually processor handles mapping, so we might need a dummy one or static method? 
             # no, let's just ignore or instantiate a temp one to check. 
             # actually better to just say 'Load PDF first' or handle in processor init)
             messagebox.showinfo("Info", "Open a PDF to initialize the processor first.")

    def list_fonts(self):
        if not self.pdf_processor:
            messagebox.showwarning("Warning", "Please open a PDF file first.")
            return

        def run():
            fonts = self.pdf_processor.get_all_fonts()
            msg = f"Fonts found in document:\n\n" + "\n".join(fonts)
            self.after(0, lambda: self.update_output(msg))

        threading.Thread(target=run).start()

    def process_pdf(self):
        if not self.pdf_processor:
            return
            
        page_input = self.page_range_entry.get().strip()
        if not page_input:
            messagebox.showerror("Error", "Please enter a page range.")
            return

        # Parse page range
        try:
            pages = self.parse_page_range(page_input)
        except ValueError:
            messagebox.showerror("Error", "Invalid page range format. Use '1-5', '1,3', etc.")
            return

        # Analyze first page in range to determine type
        if pages:
            # Check OCR toggle
            use_ocr = self.use_ocr_check.get()
            
            if use_ocr:
                 self.update_output("Starting OCR Extraction...\n(Make sure Tesseract is installed)\n")
                 threading.Thread(target=self.run_extraction, args=(pages, True)).start()
            else:
                 doc_type = self.pdf_processor.analyze_page_type(pages[0])
                 self.type_label.configure(text=f"Page {pages[0]} Type: {doc_type}")
                 
                 if doc_type == "Text":
                    self.update_output("Extracting text...\n")
                    self.process_button.configure(state="disabled")
                    self.export_button.configure(state="disabled")
                    threading.Thread(target=self.run_extraction, args=(pages, False)).start()
                 else:
                    self.update_output(f"Page {pages[0]} appears to be Image-based.\nTry checking 'Use OCR'.")

    def run_extraction(self, pages, use_ocr):
        use_smart = self.smart_extract_check.get()
        api_key = self.api_key_entry.get().strip()

        if use_smart and not api_key:
             # Try env var
             api_key = os.environ.get("GEMINI_API_KEY")
             if not api_key:
                 self.after(0, lambda: messagebox.showwarning("Warning", "Gemini API Key is required for Smart Extract."))
                 return

        if use_ocr:
             text = self.pdf_processor.extract_content_with_ocr(pages)
        else:
             text = self.pdf_processor.extract_content(pages)
             
        if use_smart:
             self.after(0, lambda: self.update_output(text + "\n\n[Processing with Gemini... Please wait]"))
             text = self.pdf_processor.refine_with_gemini(text, api_key)

        self.after(0, lambda: self.update_output(text))
        self.after(0, lambda: self.process_button.configure(state="normal"))
        self.after(0, lambda: self.export_button.configure(state="normal"))

    def update_output(self, text):
        self.output_textbox.delete("0.0", "end")
        self.output_textbox.insert("end", text)

    def export_markdown(self):
        text_content = self.output_textbox.get("0.0", "end")
        if not text_content.strip():
            messagebox.showwarning("Warning", "No content to export!")
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".md",
            filetypes=[("Markdown Files", "*.md"), ("Text Files", "*.txt")]
        )
        
        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(text_content)
                messagebox.showinfo("Success", "File exported successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save file: {e}")

    def parse_page_range(self, range_string):
        """Parses '1-5, 8, 10-12' into a list of integers."""
        pages = set()
        parts = range_string.split(',')
        for part in parts:
            part = part.strip()
            if '-' in part:
                start, end = part.split('-')
                if not start.isdigit() or not end.isdigit():
                   continue # or raise error
                pages.update(range(int(start), int(end) + 1))
            else:
                if part.isdigit():
                    pages.add(int(part))
        return sorted(list(pages))

if __name__ == "__main__":
    app = App()
    app.mainloop()
