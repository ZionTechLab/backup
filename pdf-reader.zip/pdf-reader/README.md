# PDF Reader & Extractor

A robust application designed to analyze and extract text from PDF documents. It supports standard text extraction, OCR (Optical Character Recognition) for scanned images, and "Smart Extraction" using Google Gemini AI for refined, structured output.

## Features

- **Multi-Mode Extraction**:
  - **Standard**: Extracts text directly from PDF layers.
  - **OCR (Tesseract)**: Extracts text from images/scanned PDFs.
  - **Smart Refinement**: Uses Google Gemini AI to clean, format, and structure the extracted text.
- **Multiple Interfaces**:
  - **Desktop GUI**: Built with `customtkinter` for a native experience.
  - **Streamlit Web App**: Quick and interactive dashboard.
  - **Flask Web App**: Traditional web application with basic authentication.
- **Mappings**: Support for custom character mappings (useful for legacy fonts).

## Prerequisites

- **Python 3.8+**
- **Tesseract OCR**: Required for OCR functionality.
- **Google Gemini API Key**: Required for "Smart Extraction" features.

## Installation

### 1. Clone the Repository
```bash
git clone <repository-url>
cd pdf-reader
```

### 2. Set Up Virtual Environment (Recommended)

**Windows:**
```powershell
python -m venv venv
.\venv\Scripts\activate
```

**Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

*Note: If you plan to use the Flask application, you may also need to install Flask and dotenv explicitly if they are not picked up:*
```bash
pip install flask python-dotenv
```

### 4. Install Tesseract OCR

**Windows:**
1. Download the installer from the [UB-Mannheim Tesseract GitHub](https://github.com/UB-Mannheim/tesseract/wiki).
2. Install it (e.g., to `C:\Program Files\Tesseract-OCR`).
3. **Important**: Add the installation directory to your System PATH environment variable.

**Linux (Debian/Ubuntu):**
```bash
sudo apt-get update
sudo apt-get install tesseract-ocr
sudo apt install tesseract-ocr-sin
```

## Configuration

Create a `.env` file in the project root to store your secrets:

```ini
# .env file
GEMINI_API_KEY=your_google_gemini_api_key_here
SECRET_KEY=your_flask_secret_key
USER_PASSWORD=your_flask_admin_password
```

## How to Run

You can choose any of the three available interfaces:

### Option 1: Desktop Application (GUI)
Run the native desktop application:
```bash
python main.py
```
*Features: Drag-and-drop, direct file system access, modern dark/light mode UI.*

### Option 2: Streamlit Web App
Run the interactive data dashboard:
```bash
streamlit run app.py
```
*This will open a browser window typically at http://localhost:8501.*

### Option 3: Flask Web App
Run the standard web server:
```bash
python flask_app.py
```
*Access the app at http://127.0.0.1:5000. Default login is username: `admin` and password as set in `.env` (default `admin123`).*

## Troubleshooting

- **Tesseract Not Found**: If you see an error related to Tesseract, ensure it is installed and added to your system's PATH. You may need to restart your terminal/IDE after installing it on Windows.
- **OCR Issues**: OCR performance depends on image quality.
- **Gemini API Errors**: Ensure your API key is valid and has sufficient quota.
