
import os
import pytesseract
import fitz # PyMuPDF
from PIL import Image
import io

def test_ocr():
    pdf_path = "c:/repo/New folder (3)/eee.pdf"
    print(f"Testing OCR on {pdf_path}")
    
    # Open PDF and get page 1 image
    doc = fitz.open(pdf_path)
    page = doc[0]
    pix = page.get_pixmap(dpi=300)
    img_bytes = pix.tobytes("png")
    image = Image.open(io.BytesIO(img_bytes))
    doc.close()

    # Detect Languages
    try:
        langs = pytesseract.get_languages(config='')
        print(f"Available languages: {langs}")
        
        found_sinhala = None
        for lang in langs:
            if 'sinhala' in lang.lower():
                found_sinhala = lang
                break
        
        print(f"Found Sinhala match: {found_sinhala}")
        
        # Test 1: Use found match exactly
        if found_sinhala:
             print(f"\n--- Attempt 1: lang='{found_sinhala}' ---")
             try:
                 text = pytesseract.image_to_string(image, lang=found_sinhala)
                 print(text[:200])
             except Exception as e:
                 print(f"Error: {e}")

             # Test 2: Force forward slash if backslash
             if "\\" in found_sinhala:
                 fixed = found_sinhala.replace("\\", "/")
                 print(f"\n--- Attempt 2: lang='{fixed}' ---")
                 try:
                     text = pytesseract.image_to_string(image, lang=fixed)
                     print(text[:200])
                 except Exception as e:
                     print(f"Error: {e}")
        
        # Test 3: Standard 'sin' if available
        if 'sin' in langs:
             print(f"\n--- Attempt 3: lang='sin' ---")
             text = pytesseract.image_to_string(image, lang='sin')
             print(text[:200])

    except Exception as e:
        print(f"CRITICAL ERROR (Detection Block): {e}")

    # FORCE ATTEMPT
    print("\n--- FORCED ATTEMPT: lang='script/Sinhala' ---")
    try:
        text = pytesseract.image_to_string(image, lang='script/Sinhala')
        print("SUCCESS! Output:")
        print(text[:200])
    except Exception as e:
        print(f"FAILED (script/Sinhala): {e}")

    print("\n--- FORCED ATTEMPT: lang='script\\Sinhala' ---")
    try:
        text = pytesseract.image_to_string(image, lang='script\\Sinhala')
        print("SUCCESS! Output:")
        print(text[:200])
    except Exception as e:
        print(f"FAILED (script\\Sinhala): {e}")

if __name__ == "__main__":
    test_ocr()
