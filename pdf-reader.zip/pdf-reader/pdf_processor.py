import pdfplumber
import os
import json

import google.generativeai as genai

class FontMapper:
    def __init__(self, mappings_dir="mappings"):
        self.mappings_dir = mappings_dir
        self.font_mappings = {}
        self.load_mappings()

    def load_mappings(self):
        """Loads all JSON files in the mappings directory."""
        if not os.path.exists(self.mappings_dir):
            os.makedirs(self.mappings_dir)
            return

        for filename in os.listdir(self.mappings_dir):
            if filename.endswith(".json"):
                try:
                    with open(os.path.join(self.mappings_dir, filename), "r", encoding="utf-8") as f:
                        data = json.load(f)
                        names = data.get("font_family_names", [])
                        mapping = data.get("mapping", {})
                        for name in names:
                            self.font_mappings[name] = mapping
                except Exception as e:
                    print(f"Error loading mapping {filename}: {e}")

    def map_char(self, char, font_name):
        """Maps a character based on font name. Returns original char if no mapping found."""
        # Check against mapped font names (case-insensitive check might be good, but start exact)
        # Font names in PDF might be weird like "ABCDE+FMAbhaya", so we check for substring match
        
        mapped_font = None
        for known_font in self.font_mappings:
            if known_font.lower() in font_name.lower():
                mapped_font = known_font
                break
        
        if mapped_font:
            return self.font_mappings[mapped_font].get(char, char)
        return char

class PDFProcessor:
    def __init__(self, filepath):
        self.filepath = filepath
        self.pdf = None
        self.mapper = FontMapper()

    def open(self):
        try:
            self.pdf = pdfplumber.open(self.filepath)
            return True
        except Exception as e:
            print(f"Error opening PDF: {e}")
            return False

    def close(self):
        if self.pdf:
            self.pdf.close()

    def get_page_count(self):
        if self.pdf:
            return len(self.pdf.pages)
        return 0

    def analyze_page_type(self, page_num):
        """
        Analyzes a page to determine if it's Text-based or Image-based.
        Returns: 'Text' or 'Image'
        """
        if not self.pdf:
            return "Error"
        
        try:
            page = self.pdf.pages[page_num - 1] # 0-indexed
            try:
                chars = page.chars
                # Simple heuristic:
                if len(chars) > 10: 
                    return "Text"
            except Exception as e:
                print(f"Error reading chars on page {page_num}: {e}")
                # Fallback to checking images if text parsing fails
            
            if len(page.images) > 0:
                return "Image"
            else:
                return "Text" # Assume empty text page or failed parse means we treat as text/empty
        except Exception as e:
            return f"Error: {e}"

    def extract_content(self, page_range):
        """
        Extracts content from specified pages.
        page_range: list of page numbers (1-indexed)
        Returns: Markdown string
        """
        if not self.pdf:
            return "PDF not open."

        markdown_output = ""
        
        for p_num in page_range:
            if p_num < 1 or p_num > len(self.pdf.pages):
                continue
            
            page = self.pdf.pages[p_num - 1]
            markdown_output += f"## Page {p_num}\n\n"
            
            try:
                chars = page.chars
            except Exception as e:
                markdown_output += f"_Error processing page text: {e}_\n\n"
                continue

            if not chars:
                markdown_output += "_No text content found (likely image-based or empty)._\n\n"
                continue

            # Calculate global indentation reference (approximate left margin)
            all_x0 = sorted([c['x0'] for c in chars])
            # Use 10th percentile as base margin to ignore localized extreme-left elements (like page nums sometimes)
            if all_x0:
                base_x0 = all_x0[int(len(all_x0) * 0.1)]
            else:
                base_x0 = 0

            # Cluster chars into lines
            lines = {}
            for char in chars:
                # Better line grouping: check if char vertical center fits in existing line range
                found_line = False
                for line_top in lines.keys():
                    # Check vertical proximity (approx 3-5 pts)
                    if abs(char['top'] - line_top) < 4: 
                        lines[line_top].append(char)
                        found_line = True
                        break
                if not found_line:
                    lines[char['top']] = [char]
            
            sorted_lines = sorted(lines.keys())
            
            for line_top in sorted_lines:
                line_chars_objs = sorted(lines[line_top], key=lambda c: c['x0'])
                if not line_chars_objs: continue
                
                # Check indentation (start of line vs base margin)
                first_x0 = line_chars_objs[0]['x0']
                # If indentation is significant (> 15 pts), treat as likely list/indent
                is_indented = (first_x0 - base_x0) > 15
                
                # Construct text with spaces
                line_text = ""
                last_x1 = line_chars_objs[0]['x0'] # Init to start to avoid initial space
                
                # Check header style (size > 14)
                is_header = False
                sizes = [c.get('size', 0) for c in line_chars_objs]
                avg_size = sum(sizes) / len(sizes) if sizes else 0
                if avg_size > 14:
                    is_header = True

                for i, char_obj in enumerate(line_chars_objs):
                    # Add space if gap is detected
                    gap = char_obj['x0'] - last_x1
                    # Threshold: if gap > char_width * 0.3 or fixed value ~1.5
                    # Simple fixed threshold 2.5 works for many PDFs
                    if gap > 2.5: 
                         line_text += " "
                    
                    original_char = char_obj.get('text', '')
                    font_name = char_obj.get('fontname', '')
                    
                    mapped_char = self.mapper.map_char(original_char, font_name)
                    line_text += mapped_char
                    last_x1 = char_obj['x1']
                
                # Reorder Sinhala and formatting
                reordered_text = self.reorder_sinhala(line_text).strip()
                
                if not reordered_text:
                    continue

                # Markdown Formatting
                # Check if it already looks like a list
                is_list_item = False
                if reordered_text.startswith("-") or reordered_text.startswith("•") or reordered_text.startswith("*"):
                     is_list_item = True
                     # Normalize bullet
                     if not reordered_text.startswith("-"):
                         reordered_text = "- " + reordered_text.lstrip("•*")
                elif reordered_text[0].isdigit() and len(reordered_text) > 1 and reordered_text[1] in ['.', ')']:
                     is_list_item = True
                
                # If indented and not already a list, make it a list item
                if is_indented and not is_list_item:
                    reordered_text = "- " + reordered_text
                    is_list_item = True

                if is_header:
                    markdown_output += f"\n### {reordered_text}\n\n"
                elif is_list_item:
                    markdown_output += f"{reordered_text}\n"
                else:
                    # Regular text: use double space for line break to preserve PDF lines
                    markdown_output += f"{reordered_text}  \n"

            markdown_output += "\n---\n" # Page break
            
        return markdown_output

    def reorder_sinhala(self, text):
        """
        Reorders legacy Sinhala text where vowel modifiers (like 'kombuwa' - ෙ) 
        appear before the consonant. In Unicode, they must appear after.
        """
        consonants = set("කඛගඝඞඟචඡජඣඤඥටඨඩඪණඬතථදධනඳපඵබභමඹයරලවශෂසහළෆ")
        
        output = []
        i = 0
        n = len(text)
        
        while i < n:
            char = text[i]
            
            # Check for Kombuwa (ෙ) followed by a consonant (Swap 2)
            if char == 'ෙ' and i + 1 < n:
                next_char = text[i+1]
                # If next is consonant, swap
                if next_char in consonants:
                   output.append(next_char)
                   output.append(char)
                   i += 2
                   continue
                
                # Special Case: Kombuwa + Hal + Consonant? (Double kombuwa handled?)
                # If legacy has 'ff' for 'ai' (ෛ), we might map 'f' -> 'ෙ'.
                # So we see 'ෙ' 'ෙ' 'Consonant'.
                # We need to output 'Consonant' 'ෛ'.
                # But we don't know if next 'ෙ' is coming.
                if next_char == 'ෙ' and i + 2 < n: # Double Kombuwa check
                    next_next = text[i+2]
                    if next_next in consonants:
                         output.append(next_next)
                         output.append('ෛ') # Replace ෙෙ with ෛ
                         i += 3
                         continue
            
            output.append(char)
            i += 1
            
        result = "".join(output)
        
        # Post-processing Normalization
        # Fix split vowel signs
        result = result.replace("අා", "ආ")
        result = result.replace("ේ", "ේ")
        result = result.replace("ො", "ො")
        result = result.replace("ෝ", "ෝ")
        result = result.replace("  ", " ")
        
        return result

        return result

    def extract_content_with_ocr(self, page_range):
        """
        Uses Tesseract OCR to extract text from PDF pages as images.
        This bypasses font mapping issues entirely but requires Tesseract installed.
        """
        try:
            import fitz  # PyMuPDF
            import pytesseract
            from PIL import Image
            import io
            
            # Simple check for Tesseract path on Windows if not in PATH
            tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
            if os.path.exists(tesseract_cmd):
                pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
            
        except ImportError as e:
            return f"Error: OCR libraries not installed: {str(e)}. Please run 'pip install -r requirements.txt'."

        if not self.filepath:
            return "PDF not open."

        markdown_output = ""
        
        try:
            doc = fitz.open(self.filepath)
        except Exception as e:
            return f"Error opening PDF with PyMuPDF: {e}"

        for p_num in page_range:
            if p_num < 1 or p_num > len(doc):
                continue
            
            markdown_output += f"## Page {p_num} (OCR)\n\n"
            
            try:
                page = doc[p_num - 1]
                # Render page to image (300 DPI for better OCR)
                pix = page.get_pixmap(dpi=300)
                img_bytes = pix.tobytes("png")
                image = Image.open(io.BytesIO(img_bytes))
                
                # Check available languages to support 'sin' or 'script/Sinhala'
                try:
                    langs = pytesseract.get_languages(config='')
                    print(f"DEBUG: OCR Available languages: {langs}")
                    
                    found_sinhala = None
                    for lang in langs:
                        if 'sin' == lang.lower():
                            found_sinhala = 'sin'
                            break
                        if 'sinhala' in lang.lower():
                            # likely script/Sinhala
                            found_sinhala = lang
                            break # Prefer explicit match?
                    
                    if found_sinhala:
                        print(f"DEBUG: Found Sinhala language pack: {found_sinhala}")
                        if 'script' in found_sinhala:
                            # Tesseract usually expects forward slash for script even on Windows
                            lang_param = 'script/Sinhala+eng'
                        else:
                            lang_param = 'sin+eng'
                    else:
                        print("DEBUG: Sinhala not explicitly found in list. Forcing 'script/Sinhala' as fallback.")
                        # This works even if get_languages() misses it (common issue with script/ subdir)
                        lang_param = 'script/Sinhala+eng'
                except Exception as e:
                    print(f"Error checking languages: {e}")
                    # Fallback to script/Sinhala as it's the most robust for this user
                    lang_param = 'script/Sinhala+eng'

                print(f"DEBUG: Running OCR with lang='{lang_param}'")
                try:
                    text = pytesseract.image_to_string(image, lang=lang_param)
                except pytesseract.TesseractError as e:
                    print(f"OCR Failed with {lang_param}, trying 'eng' as last resort. Error: {e}")
                     # If script/Sinhala REALLY fails (not installed), fall back to English
                    text = pytesseract.image_to_string(image, lang='eng')
                
                # Basic cleanup
                lines = text.split('\n')
                cleaned_lines = []
                for line in lines:
                    line = line.strip()
                    if not line: continue
                    
                    # Heuristic for header (all caps not applicable for Sinhala, maybe length?)
                    # OCR layout is usually linear.
                    # Just add double space for MD line break
                    cleaned_lines.append(line + "  ")
                
                markdown_output += "\n".join(cleaned_lines)
                
            except Exception as e:
                markdown_output += f"_Error performing OCR on page {p_num}: {e}_\n\n"
                continue

            markdown_output += "\n\n---\n\n" # Page break
            
        doc.close()
        return markdown_output

    def get_all_fonts(self):
        """Differs from extract_content by just listing unique font names found in the PDF processing."""
        if not self.pdf:
            return []
        
        fonts = set()
        for i, page in enumerate(self.pdf.pages):
            try:
                # Check just a subset of chars to be fast? Or all?
                # page.chars is fast enough
                for char in page.chars:
                    font = char.get('fontname')
                    if font:
                        fonts.add(font)
            except Exception as e:
                print(f"Error reading fonts on page {i+1}: {e}")
                # Continue to next page
                continue
        return sorted(list(fonts))

    def refine_with_gemini(self, text, api_key):
        """
        Sends the text to Gemini for cleanup and formatting.
        """
        if not api_key:
            return text + "\n\n[Warning]: API Key missing for Gemini refinement."
        
        try:
            genai.configure(api_key=api_key)
            
            # List of models to try in order of preference/likelihood of working
            # Based on user's available models: 2.5-flash, 2.5-pro, 2.0-flash
            candidate_models = [
                'gemini-2.0-flash',
                'gemini-2.5-flash',
                'gemini-2.5-pro'
            ]
            
            model = None
            last_error = None

            for model_name in candidate_models:
                try:
                    print(f"DEBUG: Trying Gemini model: {model_name}")
                    model = genai.GenerativeModel(model_name)
                    
                    prompt = f"You are a professional Sinhala document editor. The following text was extracted from a PDF using OCR and may contain errors, broken lines, or formatting issues. Please:\n1. Correct spelling and grammar errors in Sinhala.\n2. Fix broken sentences and join lines where appropriate.\n3. Format headers and lists using Markdown.\n4. Do NOT summarize or remove content. Keep the original meaning exactly.\n5. Output ONLY the corrected text in Markdown format.\n\nText to Process:\n{text}"
                    
                    response = model.generate_content(prompt)
                    return response.text
                except Exception as e:
                    print(f"DEBUG: Failed with {model_name}: {e}")
                    last_error = e
                    if "429" in str(e):
                        # Rate limit - maybe stick with this error if we run out of options?
                        pass
                    if "404" in str(e):
                        # Not found - try next
                        pass
            
            # If we get here, all failed
            return text + f"\n\n[Error]: All Gemini models failed. Last error: {last_error}"

        except Exception as e:
            return text + f"\n\n[Error]: Gemini Configuration Failed: {e}"
