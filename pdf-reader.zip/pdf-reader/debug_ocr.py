
import os
import sys
import fitz
import pytesseract
from PIL import Image
import io

def check_tesseract():
    # Check what's in PATH
    print("--- Tesseract in PATH ---")
    try:
        os.system("tesseract --version")
        os.system("tesseract --list-langs")
    except Exception as e:
        print(f"Error checking PATH tesseract: {e}")

    # Check hardcoded path
    hardcoded = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    if os.path.exists(hardcoded):
        print(f"\n--- Tesseract at {hardcoded} ---")
        # temporarily add to path to test? or just run it absolute
        os.system(f'"{hardcoded}" --version')
        os.system(f'"{hardcoded}" --list-langs')
    else:
        print(f"\nHardcoded path {hardcoded} does not exist.")

def ocr_page1():
    print("\n--- OCR Page 1 of eee.pdf ---")
    pdf_path = "c:/repo/New folder (3)/eee.pdf"
    
    try:
        doc = fitz.open(pdf_path)
        page = doc[0]
        pix = page.get_pixmap(dpi=300)
        img_bytes = pix.tobytes("png")
        image = Image.open(io.BytesIO(img_bytes))
        doc.close()
    except Exception as e:
        print(f"Error reading PDF: {e}")
        return

    # Try different configs
    configs = [
        {'lang': 'eng', 'cmd': None}, # Default (PATH or implicit)
        {'lang': 'sin', 'cmd': None},
        {'lang': 'script/Sinhala', 'cmd': None},
    ]

    # Also check with hardcoded path if it exists
    hardcoded = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    if os.path.exists(hardcoded):
        configs.append({'lang': 'sin', 'cmd': hardcoded})
        configs.append({'lang': 'script/Sinhala', 'cmd': hardcoded})
        configs.append({'lang': 'eng', 'cmd': hardcoded})

    for config in configs:
        lang = config['lang']
        cmd = config['cmd']
        cmd_desc = "Hardcoded" if cmd else "PATH"
        
        print(f"\nTesting: Lang='{lang}', Tesseract={cmd_desc}")
        
        if cmd:
            pytesseract.tesseract_cmd = cmd
        else:
            # Helper to reset to default/PATH if needed (pytesseract defaults to 'tesseract')
            pytesseract.tesseract_cmd = 'tesseract'

        try:
            text = pytesseract.image_to_string(image, lang=lang)
            print("output (first 100 chars):")
            print(text[:100].replace('\n', ' '))
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    check_tesseract()
    ocr_page1()
