
import streamlit as st
import os
import tempfile
from pdf_processor import PDFProcessor

st.set_page_config(page_title="PDF Analyst & Extractor", layout="wide")

def main():
    st.title("PDF Analyst & Extractor")
    
    # --- Sidebar ---
    st.sidebar.header("Configuration")
    
    # File Uploader
    uploaded_file = st.sidebar.file_uploader("Upload PDF", type="pdf")
    
    # Mappings
    if st.sidebar.button("Reload Mappings"):
        # We can implement a method to reload, but usually PDFProcessor reloads on init or we can force it.
        # Actually PDFProcessor() initializes mapper.
        st.processed_pdf = None # Force re-init
        st.sidebar.success("Mappings Reloaded (Refreshed Processor)")
        
    st.sidebar.markdown("---")
    
    # OCR Settings
    use_ocr = st.sidebar.checkbox("Use OCR (Tesseract)", value=False)
    
    # Gemini Settings
    st.sidebar.markdown("### Smart Extraction (Gemini)")
    use_smart = st.sidebar.checkbox("Enable Smart Extract", value=False)
    api_key_default = os.environ.get("GEMINI_API_KEY", "")
    api_key_input = st.sidebar.text_input("Gemini API Key", value=api_key_default, type="password")
    
    # --- Main Area ---
    if uploaded_file:
        # Save uploaded file to temporary path for processing
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            tmp_path = tmp_file.name

        st.info(f"Loaded: {uploaded_file.name}")
        
        # Page Range
        page_range_str = st.text_input("Page Range (e.g. 1-5, 8)", "1")
        
        if st.button("Analyze & Extract"):
            # Process
            with st.spinner("Processing..."):
                try:
                    processor = PDFProcessor(tmp_path)
                    if not processor.open():
                         st.error("Failed to open PDF.")
                         return

                    # Parse range  (simple parsing logic or reuse from main.py if exported)
                    # Let's verify we have the parsing logic. It was in App class. logic needs to be here.
                    pages = parse_page_range(page_range_str)
                    
                    if not pages:
                        st.error("Invalid page range.")
                    else:
                        # Extract
                        if use_ocr:
                            text = processor.extract_content_with_ocr(pages)
                        else:
                            text = processor.extract_content(pages)
                        
                        # Smart Refine
                        if use_smart:
                            if not api_key_input:
                                st.warning("Smart Extract enabled but no API Key provided.")
                            else:
                                with st.spinner("Refining with Gemini..."):
                                    text = processor.refine_with_gemini(text, api_key_input)
                        
                        # Display Output
                        st.session_state['output_text'] = text
                        
                except Exception as e:
                    st.error(f"An error occurred: {e}")
                finally:
                    processor.close() # Ensure resources released
                    if os.path.exists(tmp_path):
                        try:
                            os.unlink(tmp_path)
                        except Exception as e:
                            # Might fail on Windows if still open
                            pass

        # Display result if exists
        if 'output_text' in st.session_state:
             st.markdown("### Extracted Text")
             st.text_area("Content", st.session_state['output_text'], height=400)
             
             # Download Button
             st.download_button(
                 label="Download Markdown",
                 data=st.session_state['output_text'],
                 file_name=f"{os.path.splitext(uploaded_file.name)[0]}_extracted.md",
                 mime="text/markdown"
             )
             
    else:
        st.info("Upload a PDF to start.")

def parse_page_range(range_string):
    """Parses '1-5, 8, 10-12' into a list of integers."""
    pages = set()
    parts = range_string.split(',')
    for part in parts:
        part = part.strip()
        if '-' in part:
            try:
                start, end = part.split('-')
                pages.update(range(int(start), int(end) + 1))
            except:
                continue
        else:
            if part.isdigit():
                pages.add(int(part))
    return sorted(list(pages))

if __name__ == "__main__":
    main()
