
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.utils import secure_filename
import os
import tempfile
from functools import wraps
from pdf_processor import PDFProcessor
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = tempfile.gettempdir()
app.secret_key = os.getenv('SECRET_KEY', 'default_dev_key')

# Simple Single User Auth
ADMIN_USER = "admin"
ADMIN_PASS = os.getenv('USER_PASSWORD', 'admin123')

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check against environment variables
        if username == ADMIN_USER and password == ADMIN_PASS:
            session['user'] = username
            return redirect(url_for('index'))
        else:
            error = 'Invalid Credentials. Please try again.'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required # Add protection
def index():
    return render_template('index.html', user=session.get('user'))

@app.route('/process', methods=['POST'])
@login_required # Add protection
def process():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    try:
        # Save uploaded file
        filename = secure_filename(file.filename)
        tmp_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(tmp_path)
        
        processor = PDFProcessor(tmp_path)
        if not processor.open():
             return jsonify({'error': 'Could not open PDF'}), 400
             
        pages = parse_page_range(request.form.get('pages', '1'))
        use_ocr = request.form.get('use_ocr') == 'on'
        use_smart = request.form.get('use_smart') == 'on'
        api_key = request.form.get('api_key')
        
        # Extract
        if use_ocr:
            text = processor.extract_content_with_ocr(pages)
        else:
            text = processor.extract_content(pages)
            
        # Refine
        if use_smart:
            # Prefer form input (user override), otherwise checking environment variable
            if not api_key:
                api_key = os.getenv('GEMINI_API_KEY')
                
            if not api_key:
                return jsonify({'error': 'Smart Extract selected but API Key missing (not in form or .env).'}), 400
                
            text = processor.refine_with_gemini(text, api_key)
            
        processor.close()
        # Clean up in finally block instead
        return jsonify({'text': text})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'tmp_path' in locals() and os.path.exists(tmp_path):
            try: os.unlink(tmp_path)
            except: pass

def parse_page_range(range_string):
    pages = set()
    parts = range_string.split(',')
    for part in parts:
        part = part.strip()
        if '-' in part:
            try:
                start, end = part.split('-')
                pages.update(range(int(start), int(end) + 1))
            except: continue
        else:
            if part.isdigit():
                pages.add(int(part))
    return sorted(list(pages)) or [1]

if __name__ == '__main__':
    print("Starting Flask Web App...")
    print("Open http://127.0.0.1:5000 in your browser.")
    app.run(debug=True, port=5000)
