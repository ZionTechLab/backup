import pdfplumber

def inspect_page():
    path = "c:/repo/New folder (3)/eee.pdf"
    with pdfplumber.open(path) as pdf:
        if len(pdf.pages) < 1:
            print("PDF has fewer than 1 page.")
            return

        page = pdf.pages[0] # Page 1 is index 0
        print(f"--- Page 1 Analysis ---")
        
        # Fonts
        fonts = set()
        for char in page.chars:
            if char.get('fontname'):
                fonts.add(char['fontname'])
        print(f"Fonts found: {fonts}")

        # Raw Text Sample (first 500 chars)
        print("\n--- Raw Text Sample (First 500 chars) ---")
        raw_text = ""
        for i, char in enumerate(page.chars):
            if i > 500: break
            raw_text += char.get('text', '')
        print("\nRaw Text:")
        print(repr(raw_text))

if __name__ == "__main__":
    inspect_page()
