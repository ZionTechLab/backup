try:
    import fitz
    print("fitz imported successfully")
except ImportError as e:
    print(f"fitz import failed: {e}")
except Exception as e:
    print(f"fitz import failed with other error: {e}")

try:
    import pytesseract
    print("pytesseract imported successfully")
except ImportError as e:
    print(f"pytesseract import failed: {e}")

try:
    from PIL import Image
    print("PIL imported successfully")
except ImportError as e:
    print(f"PIL import failed: {e}")
