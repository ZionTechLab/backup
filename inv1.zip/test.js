import fs from "fs";
import axios from "axios";
// OpenAI API Key
const apiKey = "sk-proj-FONOPfoHlE0m6Gz1FW6FT3BlbkFJa2gHrulUn6esDyLAoTtR";

// Function to encode the image
function encodeImage(imagePath) {
  const image = fs.readFileSync(imagePath);
  return image.toString("base64");
}

// Path to your image
const imagePath = "com.jpg";

// Getting the base64 string
const base64Image = encodeImage(imagePath);

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${apiKey}`,
};

const payload = {
  model: "gpt-4o",
  messages: [
    {
      role: "user",
      content: [
        {
          type: "text",
          text: "What’s in this image?",
        },
        {
          type: "image_url",
          image_url: {
            url: `data:image/jpeg;base64,${base64Image}`,
          },
        },
      ],
    },
  ],
  max_tokens: 300,
};

axios
  .post("https://api.openai.com/v1/chat/completions", payload, { headers })
  .then((response) => {
    console.log(response.data);
  })
  .catch((error) => {
    console.error(error);
  });
