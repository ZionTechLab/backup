import OpenAI from "openai";
import fs from "fs";
import fromPath from "pdf2pic";

const options = {
  density: 100,
  saveFilename: "untitled",
  savePath: "./images",
  format: "png",
  //  width: 600,
  //  height: 600,
};

async function convertPdfToImage(pdfPath, pageToConvert) {
  try {
    const convert = fromPath(pdfPath, options);
    const image = await convert(pageToConvert, { responseType: "image" });
    console.log("Page 1 is now converted as image");
  } catch (error) {
    console.error("Error during PDF conversion:", error);
  }
}

convertPdfToImage("C:/Data/DEV/aws/INV/one.pdf", 1);

const openai = new OpenAI({
  apiKey: "sk-proj-FONOPfoHlE0m6Gz1FW6FT3BlbkFJa2gHrulUn6esDyLAoTtR",
});

// const fs = require(`fs`);
function ConvertToBase64(file) {
  let fileData = fs.readFileSync(file);
  return new Buffer.from(fileData).toString("base64");
}
function encodeImage(imagePath) {
  const image = fs.readFileSync(imagePath);
  return image.toString("base64");
}

// Path to your image
const imagePath = "INV/n2.jpeg";

// Getting the base64 string
const base64Image = encodeImage(imagePath);

async function main() {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: 'Please provide the invoice details in JSON format: {"isInvoice": true, "Company": {"Name": "", "Address": "", "Contact": ""}, "Customer": {"Name": "", "Address": "", "Contact": ""}, "InvoiceDetails": {"InvoiceNumber": "", "InvoiceDate": "YYYY-MM-DD"}, "InvoiceTotal": 0.00,InvoiceCurrancy:"USD" ,"NoOfItems": 0,"Services":[], "Items": [{"Item": "", "Description": "", "Quantity": 1, "UnitPrice": 0.00, "TotalPrice": 0.00}]}',
              // text: "I need following details in jason format {isInvoice:?,Company:?,Customer:?,InvoiceTotal:?,NoOfItems:?,Items:[Item:?,Price:?]}",
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`,
                detail: "high",
              },
            },
          ],
        },
      ],
    });
  console.log(response.choices[0]);
}
//main();
