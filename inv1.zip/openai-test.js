import pdf2img from "pdf-img-convert";
import fs from "fs";
// Both HTTP and local paths are supported
// var outputImages1 = pdf2img.convert(
//   "https://carstenrehder-my.sharepoint.com/personal/jendrick_scholz_carstenrehder_de/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fjendrick%5Fscholz%5Fcarstenrehder%5Fde%2FDocuments%2FHayleylines%20Ltd%20%2D%20ABB%20Victoria%20%2D%20all%20invoices%20from%20Nov%2E%2023%20%2D%20Jan%2E%2024%2F20231005%20Kingfisher%20Insurance%20Broker%20GmbH%20108781%2Epdf&parent=%2Fpersonal%2Fjendrick%5Fscholz%5Fcarstenrehder%5Fde%2FDocuments%2FHayleylines%20Ltd%20%2D%20ABB%20Victoria%20%2D%20all%20invoices%20from%20Nov%2E%2023%20%2D%20Jan%2E%2024"
// );
var outputImages1 = pdf2img.convert("INV/one.pdf");

// From here, the images can be used for other stuff or just saved if that's required:

outputImages1.then(function (outputImages) {
  console.log(outputImages.length);
  for (let i = 0; i < outputImages.length; i++) {
    console.log(i);
    fs.writeFile("output" + i + ".png", outputImages[i], function (error) {
      if (error) {
        console.error("Error: " + error);
      }
    });
  }
});
