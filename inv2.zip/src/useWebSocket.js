import { useState, useEffect } from "react";
import { addNotification } from "./Store";//store, FileUploadAsync, 
import { useDispatch } from "react-redux";//, useSelector

const useWebSocket = (url) => {
  const [socket, setSocket] = useState(null);
  const dispatch = useDispatch();
  useEffect(() => {
    const ws = new WebSocket(url);

    ws.onopen = () => {
      console.log("Connected to WebSocket server");
      dispatch(
        addNotification({
          message: "Connected to WebSocket server",
          variant: "info",
          autoHideDuration: 1000,
          isHide: false,
        })
      );
    };
    ws.onmessage = (event) => {
      const newMessage = JSON.parse(event.data);
      dispatch(
        addNotification({
          message: newMessage.Messege,
          variant: "info",
          autoHideDuration: 1000,
          isHide: false,
          msgType: newMessage.type,
          processID:newMessage.processID,
        })
      );
    };

    ws.onclose = () => {
      console.log("Disconnected from WebSocket server");
      dispatch(
        addNotification({
          message: "Disconnected from WebSocket server",
          variant: "error",
          autoHideDuration: 1000,
          isHide: false,
        })
      );
    };

    setSocket(ws);

    return () => {
      ws.close();
    };
  }, [url]);

  const sendMessage = (message) => {
    if (socket) {
      socket.send(message);
    }
  };

  return { sendMessage };
};

export default useWebSocket;
