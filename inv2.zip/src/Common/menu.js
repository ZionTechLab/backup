import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import Inventory2OutlinedIcon from "@mui/icons-material/Inventory2Outlined";
import InventoryOutlinedIcon from "@mui/icons-material/InventoryOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import InsertDriveFileSharpIcon from "@mui/icons-material/InsertDriveFileSharp";
import FolderCopySharpIcon from "@mui/icons-material/FolderCopySharp";
import VerifiedSharpIcon from "@mui/icons-material/VerifiedSharp";
import HistoryToggleOffSharpIcon from "@mui/icons-material/HistoryToggleOffSharp";

export const MenuItems = [
  [<HomeOutlinedIcon />, "Home"],
  [<InsertDriveFileSharpIcon />, "Manual Feed"],
  [<FolderCopySharpIcon />, "Bulk Process"],
  [<VerifiedSharpIcon />, "Cross Verification"],
  [<HistoryToggleOffSharpIcon />, "History"],
];
