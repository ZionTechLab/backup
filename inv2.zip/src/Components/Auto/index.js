import React, { useState } from "react";
import "react-json-view-lite/dist/index.css"; // Import styles
import Spinner from "../../Components/Spinner";
import { store, BulkProcessAsync, addNotification } from "../../Store";
import { useDispatch, useSelector } from "react-redux";
import TextField from "@mui/material/TextField";
import Alert from "@mui/material/Alert";

const Manual = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [result, setresult] = useState([]);
  const [text, setText] = useState("");

  const data = useSelector((state) => state.file.bulk);
  const dispatch = useDispatch();

  // const handleBtnClick = (event) => {
  //   console.log("Input text:", text);
  //   // setSelectedFile(event.target.files[0]);
  // };

  const handleBtnClick = async (event) => {
    // console.log("Input text:", text);
    event.preventDefault();
    if (text == "") {
      dispatch(
        addNotification({
          message: "Please select a folder",
          variant: "warning",
          autoHideDuration: 10000,
          isHide: false,
          // contentShow: true,
        })
      );
      return;
    }
    dispatch(BulkProcessAsync({ Folder: text }));
  };

  const handleChange = (event) => {
    setText(event.target.value);
  };
  // const handleBtnClick = async (event) => {
  //   console.log("ss");
  //   event.preventDefault();
  //   if (!selectedFile) return;

  //   const formData = new FormData();
  //   formData.append("file", selectedFile);
  //   dispatch(FileUploadAsync(formData));
  // };
  const Header = (
    <div>
      <hr /> <h1>Automated Invoice extracting (Bulk Process)</h1>
      <hr />{" "}
      <h3>
        Effortlessly extract data from all invoices in a designated folder
      </h3>
      <p>
        This feature automates invoice processing, eliminating manual steps.
        Here's how it works:
      </p>
      <ol>
        <li>
          <b>Initial Setup:</b> Configure a specific folder on your computer to
          store invoices. (This is a one-time setup){" "}
        </li>
        <li>
          <b>Automated Processing:</b> Simply place your invoices (PDF or JPEG)
          in the designated folder.{" "}
        </li>
        <li>
          <b>AI-powered Extraction:</b> Our intelligent AI automatically
          triggers, analyzing each invoice and extracting key data points.
          (Choose scheduled or manual trigger)
        </li>
        <li>
          <b>Unified JSON Output:</b> Upon completion, a single JSON file
          containing all extracted data from the folder will be available for
          download. This format integrates seamlessly with any third-party ERP
          system.
        </li>
      </ol>
      <h3> Benefits:</h3>
      <li>
        <b>Effortless Automation:</b> Free yourself from manual data entry and
        repetitive tasks.
      </li>
      <li>
        <b>Increased Efficiency:</b> Streamline invoice processing with
        automatic triggers.
      </li>
      <li>
        <b>Standardized Output:</b> Easily integrate extracted data with your
        existing ERP system (JSON format).
      </li>
      <hr />
      <div>
        <TextField
          fullWidth
          variant="filled"
          id="Folder"
          name="Folder"
          label="Folder"
          value={text}
          onChange={handleChange}
        />

        <button type="submit" onClick={handleBtnClick}>
          Process
        </button>

        <hr />
      </div>
    </div>
  );
  let page = "";
  if (data.loading) page = <Spinner />;
  else if (
    data.loading == false &&
    data.isSuccess == false &&
    data.error != null
  )
    page = <Alert severity="error">{data.error}</Alert>;
  else if (data.messege != "")
    page = <Alert severity="info">{data.messege}</Alert>;

  return (
    <div>
      {Header}
      {page}
    </div>
  );
};

export default Manual;
//to do - image upload
