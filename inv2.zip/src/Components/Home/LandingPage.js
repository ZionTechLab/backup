import classes from "./LandingPage.module.css";

function LandingPage(props) {
  return (
    <div className={classes.Wraper}>
      <div className={classes.Contains}>{props.children}</div>
    </div>
  );
}

export default LandingPage;
