function App() {
  return (
    <div>
      <hr />
      <h1>Supercharge Your AP Workflow with AI-powered Invoice Processing</h1>
      <hr />
      <h3>
        Eliminate manual data entry and embrace a new era of intelligent invoice
        processing.
      </h3>
      <p>
        This cutting-edge demo showcases a revolutionary solution that leverages
        AI to automate invoice processing, regardless of format. Free your team
        from tedious tasks and unlock a world of efficiency and accuracy.
      </p>
      <h2>Experience the Power of AI Automation:</h2>

      <li>
        <b> Bulk Upload & Processing:</b>
        <br /> Upload hundreds of invoices in a single batch for streamlined
        processing.
      </li>
      <li>
        <b> Intelligent Data Extraction:</b>
        <br /> Our advanced AI engine intelligently extracts key data points
        from diverse invoice layouts with unmatched accuracy.
      </li>
      <li>
        <b> Seamless Data Verification: </b>
        <br />
        Intuitive tools allow for effortless verification of extracted data,
        complete with confidence scores and side-by-side comparisons.
      </li>

      <h3>Unlock Measurable Advantages:</h3>

      <li>
        <b>Effortless Time Savings:</b>
        <br /> Redirect your valuable team resources from manual data entry to
        strategic initiatives.
      </li>
      <li>
        <b>Unprecedented Accuracy:</b>
        <br />
        AI-powered verification ensures data integrity, minimizing errors and
        improving financial control.
      </li>
      <li>
        <b> Faster Invoice Cycles:</b>
        <br /> Expedite invoice processing cycles, leading to improved cash flow
        and financial planning. Enhanced Visibility: Gain real-time insights
        into your Accounts Payable operations for better decision-making.
      </li>

      <h2>
        Empower your AP team with the power of AI and experience the future of
        invoice processing!
      </h2>
    </div>
  );
}

export default App;
