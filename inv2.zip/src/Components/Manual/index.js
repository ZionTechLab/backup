import React, { useState } from "react";
import { JsonToTable } from "react-json-to-table";
import { JsonView, allExpanded, darkStyles } from "react-json-view-lite";
import "react-json-view-lite/dist/index.css";
import Spinner from "../../Components/Spinner";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { store, FileUploadAsync, addNotification } from "../../Store";
import { useDispatch, useSelector } from "react-redux";
import Alert from "@mui/material/Alert";

const Manual = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [result, setresult] = useState([]);

  const data = useSelector((state) => state.file.single);
  const dispatch = useDispatch();

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!selectedFile) {
      dispatch(
        addNotification({
          message: "Please select a file",
          variant: "warning",
          autoHideDuration: 10000,
          isHide: false,
        })
      );
      return;
    }
    const formData = new FormData();
    formData.append("file", selectedFile);

    dispatch(FileUploadAsync(formData));
  };
  const Header = (
    <div>
      <hr /> <h1>Upload & Extract Invoice Data (Single File)</h1>
      <hr /> <h3>Supported formats: PDF (.pdf), JPEG (.jpeg)</h3>
      <ol>
        <li> Click "Browse" and select your invoice. </li>
        <li>Upload the file. </li>
        <li>
          AI extracts key data & displays it in JSON format (ready for any ERP
          system).
        </li>
      </ol>
      <hr />
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} />
        <button type="submit">Upload</button>
      </form>{" "}
      <hr />
    </div>
  );
  let page = "";
  if (data.loading) page = <Spinner />;
  else if (
    data.loading == false &&
    data.isSuccess == false &&
    data.error != null
  )
    page = <Alert severity="error">{data.error}</Alert>;
  else if (data.messege != "")
    page = (
      <div>
        {data.loading ? (
          <Spinner />
        ) : (
          <div>
            <div>
              <hr />
              {data.pending}
              <Accordion defaultExpanded>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography>Result</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <JsonToTable json={data.invoiceData} />
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2-content"
                  id="panel2-header"
                >
                  <Typography>JSON Format</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <JsonView
                    data={data.invoiceData}
                    shouldExpandNode={allExpanded}
                    style={darkStyles}
                  />
                </AccordionDetails>
              </Accordion>
              <hr />
            </div>
          </div>
        )}
      </div>
    );

  return (
    <div>
      {Header}
      {page}
    </div>
  );
};

export default Manual;
