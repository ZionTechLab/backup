import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as Config from "../../Common/Config";
import axios from "axios";

const FileUploadAsync = createAsyncThunk("file/FileUpload", async (payload) => {
  try {
    let url = Config.API_URL + "readFile";
    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return {
      invoiceData: response.data,
      loading: false,
      isSuccess: true,
      error: "",
    };
  } catch (error) {
    return {
      invoiceData: [],
      loading: false,
      isSuccess: false,
      error: error.response != null ? error.response.data : error.message,
    };
  }
});

const BulkProcessAsync = createAsyncThunk(
  "file/BulkProcess",
  async (payload) => {
    try {
     
      let url = Config.API_URL + "BulkProcess";
      const response = await axios.post(url, payload);
      return { messege: response.data, loading: false, isSuccess: true };
    } catch (error) {
      console.log(error);
      return {
        messege: "",
        loading: false,
        isSuccess: false,
        error: error.response != null ? error.response.data : error.message,
      };
    }
  }
);

const GetProcessedData = createAsyncThunk(
  "file/GetProcessedData",
  async (payload) => {
    console.log(payload);
    try {
      let url = Config.API_URL + "GetProcessedData";
      const response = await axios.post(url, payload);
       console.log(response);
      return {
        invoiceData: response.data,
        loading: false,
        isSuccess: true,
        error: "",
      };
    } catch (error) {
      console.log(error);
      return {
        invoiceData: [],
        loading: false,
        isSuccess: false,
        error: error.response != null ? error.response.data : error.message,
      };
    }
  }
);

const fileSlice = createSlice({
  name: "file",
  initialState: {
    single: {
      invoiceData: [],
      loading: false,
      isSuccess: false,
      error: null,
    },
    bulk: {
      messege: "",
      loading: false,
      isSuccess: false,
      error: null,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(FileUploadAsync.pending, (state) => {
        return {
          ...state,
          single: {
            invoiceData: [],
            loading: true,
            isSuccess: false,
            error: null,
          },
        };
      })
      .addCase(FileUploadAsync.fulfilled, (state, action) => {
        return {
          ...state,
          single: action.payload,
        };
      })
      .addCase(FileUploadAsync.rejected, (state, action) => {
        return {
          ...state,
          single: {
            invoiceData: [],
            loading: false,
            isSuccess: false,
            error: action,
          },
        };
      })
      .addCase(BulkProcessAsync.pending, (state) => {
        return {
          ...state,
          bulk: {
            messege: "",
            loading: true,
            isSuccess: false,
            error: null,
          },
        };
      })
      .addCase(BulkProcessAsync.fulfilled, (state, action) => {
        return {
          ...state,
          bulk: action.payload,
        };
      })
      .addCase(BulkProcessAsync.rejected, (state, action) => {
        return {
          ...state,
          bulk: {
            messege: "",
            loading: false,
            isSuccess: false,
            error: action,
          },
        };
      })

      .addCase(GetProcessedData.pending, (state) => {
        return {
          ...state,
          single: {
            invoiceData: [],
            loading: true,
            isSuccess: false,
            error: null,
          },
        };
      })
      .addCase(GetProcessedData.fulfilled, (state, action) => {
        return {
          ...state,
          single: action.payload,
        };
      })
      .addCase(GetProcessedData.rejected, (state, action) => {
        return {
          ...state,
          bulk: {
            messege: "",
            loading: false,
            isSuccess: false,
            error: action,
          },
        };
      });
  },
});

export const fileReducer = fileSlice.reducer;

export { FileUploadAsync, BulkProcessAsync, GetProcessedData };
