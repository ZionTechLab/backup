import { createSlice } from "@reduxjs/toolkit";

const notificationSlice = createSlice({
  name: "notification",
  initialState: {
    message: "",
    variant: "info",
    autoHideDuration: 1000,
    isHide: true,
    contentShow: false,
    processID:0,
    msgType:''
  },
  reducers: {
    addNotification(state, action) {
      const {
        message,
        variant,
        autoHideDuration,
        isHide,
        contentShow,
        processID,
        msgType,
      } = action.payload;
      return {
        ...state,
        message,
        variant,
        autoHideDuration,
        isHide,
        contentShow,
        processID,
        msgType,
      };
    },
  },
});

export const { addNotification } = notificationSlice.actions;
export const notificationReducer = notificationSlice.reducer;
