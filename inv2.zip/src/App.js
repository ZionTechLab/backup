import React from "react";
import "./App.css";
import Login from "./Components/Login";
import { useDispatch, useSelector } from "react-redux";
import { addNotification, GetProcessedData } from "./Store";
import Drawer from "./Components/Drawer";
import Home from "./Components/Home";
import LandingPage from "./Components/Home/LandingPage";
import Manual from "./Components/Manual";
import Auto from "./Components/Auto";
import { SnackbarProvider, useSnackbar } from "notistack";
import useWebSocket from "./useWebSocket";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { JsonToTable } from "react-json-to-table";
import { JsonView, allExpanded, darkStyles } from "react-json-view-lite";
import Enumerable from "linq";

const style = {
  position: "absolute",
  // top: "50%",
  // left: "50%",
  // transform: "translate(-50%, -50%)",
  width: 100,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function App() {
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  const notificationData = useSelector((state) => state.notification);


   const [open, setOpen] = React.useState(false);
   const handleOpen = () => setOpen(true);
   const handleClose = () => setOpen(false);
  const data = useSelector((state) => state.file.single);
  React.useEffect(() => {
    if (authData.isAuthOK === true) {
      dispatch(
        addNotification({
          message: "Login Succesfull",
          variant: "info",
          autoHideDuration: 1000,
          isHide: false,
        })
      );
    }
  }, [authData.isAuthOK]);

  React.useEffect(() => {
    if (notificationData.isHide === false) {
      if (notificationData.msgType === "B") {
        enqueueSnackbar("", {
          variant: notificationData.variant,
          autoHideDuration: 1000000000,
          // content: notificationData.content,
          action: (key) => (
            <div>
              {notificationData.message}
              <a>{notificationData.processID}</a>
              <Button
                color="secondary"
                size="small"
                onClick={() =>{ console.log(notificationData.processID);  
                   dispatch(
                     GetProcessedData({ 'processID': notificationData.processID })
                   );
                  handleOpen();
                  closeSnackbar(key)
                }}
              >
                OK
              </Button>
            </div>
          ),
        });
      } else {
        enqueueSnackbar(notificationData.message, {
          variant: notificationData.variant,
          autoHideDuration: notificationData.autoHideDuration,
        });
      }
    }
  }, [notificationData]);

  const { sendMessage } = useWebSocket("ws://localhost:8765");

  let contains = "";
  if (authData.isAuthOK === false) contains = <Login />;
  else if (authData.isAuthOK === true)
    contains = (
      <div className="aa">
        <Drawer />
        <LandingPage>
          {(() => {
            switch (authData.ActiveForm) {
              case "Home":
                return <Home />;
              case "Manual Feed":
                return <Manual />;
              case "Bulk Process":
                return <Auto />;
              default:
                return "404";
            }
          })()}
        </LandingPage>
      </div>
    );

  return (
    <div className="App">
      {contains}
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box className="modal">
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Extracted Invoice Detail
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            <Accordion defaultExpanded>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1-content"
                id="panel1-header"
              >
                <Typography>Result</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <JsonToTable
                  json={Enumerable.from(data.invoiceData)
                    .select((user) => ({
                      file: user.fileName + user.type,
                      invoiceData: user.response,
                    }))
                    .toArray()}
                />
              </AccordionDetails>
            </Accordion>
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography>JSON Format</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <JsonView
                  data={data.invoiceData}
                  shouldExpandNode={allExpanded}
                  style={darkStyles}
                />
              </AccordionDetails>
            </Accordion>
          </Typography>
        </Box>
      </Modal>
    </div>
  );
}

export default function IntegrationNotistack() {
  return (
    <SnackbarProvider
      maxSnack={7}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
    >
      <App />
    </SnackbarProvider>
  );
}
