import axios from "axios";
import React, { useState } from "react";
import { JsonToTable } from "react-json-to-table";

const FileUpload = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [result, setresult] = useState([]);

  const handleFileChange = (event) => {
    console.log("ss");
    setSelectedFile(event.target.files[0]);
  };

  const handleSubmit = async (event) => {
    console.log("ss");
    event.preventDefault();
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      const response = await axios.post(
        "http://127.0.0.1:5000/readFile",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log(response.data);
      setresult(response.data);
      // Handle successful upload response
    } catch (error) {
      setresult(error);
      console.error(error); // Handle upload error
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="App">
        <h1>Invoice Extractor</h1>
        <h5>Please Select and Upload Invoice(PDF or JPG Format).....</h5>
        <input type="file" onChange={handleFileChange} />
        <button type="submit">Upload</button>
        <hr />
        <JsonToTable json={result} />
        {/* ===================== */}
      </div>
    </form>
  );
};

export default FileUpload;
