import React, { Component } from 'react';
import { connect } from 'react-redux';
import Test from './Components/Test/Test'
import RouteWiseCustomers from './Containers/Customer/RouteWiseCustomers'
import Auth from './Containers/Auth/Auth'
import Spinner from './Components/UI/Spinner/Spinner'
import * as actions from './store/actions/index';
import * as actionTypes from './store/actions/actionTypes';
import Drawer from './Components/Drawer/Drawer'
import Help from './Containers/Help/Help'
import classes from './App.module.css';
import Dashboard from './Containers/Dashboard/Dashboard'
import Users from './Containers/Users/Users'

import Order from './Components/POS/Order'

class App extends Component {
  state = {
    LoginOK: '0',
    isInitialized: 0
  }
  handleLanguage = (langValue) => {

    this.setState({ LoginOK: 1 });

  }
  componentDidMount() {

  }

  componentDidUpdate(prevProps) {

    if (this.props.isValiedSession && this.state.isInitialized === 0) {
      this.setState({ isInitialized: 3 });
      console.log("method call");
      this.props.onInitialize(this.props.userId, false);
    };

    if (this.state.isInitialized === 3 && this.props.init === actionTypes.INIT_FAIL) {
      this.setState({ isInitialized: 2 });
      console.log("method fail");
    };

    if (this.state.isInitialized === 3 && this.props.init === actionTypes.INIT_SUCCESS) {
      this.setState({ isInitialized: 2 });
      console.log("method Scuuess");
    };



  };

  render() {
    let form = <Auth />;

    if (this.props.loading) {
      form = (
        <div>
          initializing
          <Spinner />
        </div>
      )
    };
    if (this.props.init === actionTypes.INIT_FAIL) {
      form = 'System Initialization Failed.Please check your internet connection and retry or contact your system administrator'
    };

    if (this.props.init === actionTypes.INIT_SUCCESS) {
      form = <div><Drawer /></div>
      // <Test />
    };

    if (this.props.ActiveForm === 'Help') {
      form = <div>
        <Drawer />
        <div className={classes.Container}>
          <Dashboard /></div>
      </div>
    }
    else if (this.props.ActiveForm === 'Inventory') {
      form = <div>
        <Drawer />
        <div className={classes.Container}>
          <Test /></div>
      </div>
    }
    else if (this.props.ActiveForm === 'Customers') {
      form = <div>
        <Drawer />
        <div className={classes.Container}>
          <RouteWiseCustomers /></div>
      </div>
    }
    else if (this.props.ActiveForm === 'Users') {
      //  console.log("aDO");
      form = <div>
        <Drawer />
        <div className={classes.Container}>
          <Users /></div>
      </div>
    }
    else if (this.props.ActiveForm === 'Order') {
      //  console.log("aDO");
      form = <div>
        <Drawer />
        <div className={classes.Container}>
          <Order /></div>
      </div>
    }
    // else if (this.props.ActiveForm === 'Help') {
    //   form = <div>
    //     <TemporaryDrawer />
    //     <div className={classes.Container}>
    //     <Help /></div>
    //   </div>
    // };

    return (



      <div >
        <Order/>
     <Item
     ItemID="A1233"
     ItemName="Tahukana item Eka"
      UnitPrice="100.00"
      PackingSize="10"
      MaxDiscount="25"
      />
         <Item
            ItemID="A12e2"
            ItemName="Tahukana item Deka"
      UnitPrice="120.00"
      PackingSize="12"
      MaxDiscount="15"
      />
        {form}

      </div>

    );
  }
}

const mapStateToProps = state => {
  console.log(state.activeForm.ActiveForm);
  return {
    isValiedSession: state.auth.isValiedSession,
    userId: state.auth.userId,
    init: state.init.type,
    loading: state.init.loading,
    ActiveForm: state.activeForm.ActiveForm,
  };
};


const mapDispatchToProps = dispatch => {
  return {
    onInitialize: (userId, isRefresh) => dispatch(actions.init(userId, isRefresh))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);