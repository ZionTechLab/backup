import * as actionTypes from './actionTypes';

export const setActiveForm = (FormName) => {
     return { 
        type: actionTypes.ACTIVE_FORM_UPDATE,
        ActiveForm: FormName
    };
};

export const activeForm = (FormName) => {
  
    return dispatch => {
        dispatch(setActiveForm(FormName));
    };
};