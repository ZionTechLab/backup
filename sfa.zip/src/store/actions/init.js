import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as Config from '../../Common/Config';

export const fetchStart = () => {
    return {
        type: actionTypes.INIT_START
    };
};

export const fetchSuccess = (Items, SyncTime) => {
    return {
        type: actionTypes.INIT_SUCCESS,
        items: Items,
        syncTime: SyncTime,
    };
};


export const fetchFail = (error) => {
    return {
        type: actionTypes.INIT_FAIL,
        error: error
    };
};

export const init = (userId, isRefresh) => {

    return dispatch => {
        dispatch(fetchStart());

        let initialized = false;
        let itm = [];

        let DateNow = (new Date()).toLocaleDateString("en-US");
        let DateStored = localStorage.getItem('synchronizedTime');
        let userIdStored = localStorage.getItem('userId');

        if (isRefresh === false) {
            if ((DateNow === DateStored) && (userId === userIdStored))
                initialized = true;
        }

        if (initialized) {
            itm = JSON.parse(localStorage.getItem('items'));
            dispatch(fetchSuccess(itm, DateStored));
        }
        else {
            let url = Config.API_URL + 'Inventory/initialize';

            const inventoryData = {
                user_Id: userId
            };

            axios.post(url, inventoryData)
                .then(response => {
                    localStorage.setItem('items', JSON.stringify(response.data.items));
                    localStorage.setItem('customer', JSON.stringify(response.data.customer));
                    localStorage.setItem('customerOutstanding', JSON.stringify(response.data.customerOutstanding));
                    localStorage.setItem('synchronizedTime', DateNow);
                    localStorage.setItem('userId', userId);
                    localStorage.setItem('route', response.data.route);
                    localStorage.setItem('userType', response.data.userType);
                    localStorage.setItem('saleHistory',JSON.stringify( response.data.saleHistory));
                    console.log(response.data);
                    dispatch(fetchSuccess(response.data.items, DateNow));
                })
                .catch(err => {
                    dispatch(fetchFail(err));
                });
        }
    };
};