import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as Config from '../../Common/Config';

export const authStart = () => {
    return {
        type: actionTypes.AUTH_START
    };
};

export const authSuccess = (userId) => {
    console.log(userId);
    return {
        type: actionTypes.AUTH_SUCCESS,
        userId: userId
    };
};

export const authFail = (error) => {
    return {
        type: actionTypes.AUTH_FAIL,
        error: error
    };
};

export const auth = (email, password) => {
    return dispatch => {
        dispatch(authStart());
       
        const authData = {
            user_id: email,
            password: password
        };

        let url = Config.API_URL +'Inventory/Login';
        
        axios.post(url, authData)
            .then(response => {
              console.log(response.data.isSuccess);
              if(response.data.isSuccess===true)
                dispatch(authSuccess(email));
                else
                dispatch(authFail(response.data.varOutMsg));
       
            })
            .catch(err => {
                console.log(err);
                dispatch(authFail(err.response.data.error));
            });
    };
};