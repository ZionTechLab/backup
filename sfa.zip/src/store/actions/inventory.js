import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as Config from '../../Common/Config';

export const fetchStart = () => {
    return {
        type: actionTypes.FETCH_INVENTORY_START
    };
};

export const fetchSuccess = (data) => {
    return {
        type: actionTypes.FETCH_INVENTORY_SUCCESS,
        stock: data,
    };
};


export const fetchFail = (error) => {
    return {
        type: actionTypes.FETCH_INVENTORY_FAIL,
        error: error
    };
};

export const inventory = () => {
    return dispatch => {
        dispatch(fetchStart());

        let url = Config.API_URL + 'Inventory/Get_Inventory';

        axios.get(url)
            .then(response => {
                console.log(response);
                dispatch(fetchSuccess(response.data));
            })
            .catch(err => {
                console.log(err);
               // console.log(JSON.stringify(err))
               // console.log(error.response.data);  
     //console.log(error.response.status);  
     //console.log(error.response.headers); 
                dispatch(fetchFail(err));
            });
    };
};