import * as actionTypes from '../actions/actionTypes';
import { updateObject } from '../utility';

const initialState = {
    type:null,
    error: null,
    items:null,
    loading:null
};

const fetchStart = ( state, action ) => {
    return updateObject( state, { 
        type:action.type,
        error: null,
        loading: true 
        } );
};

const fetchSuccess = (state, action) => {

    return updateObject( state, { 
        type:action.type,
        error: null,
        loading: false,
        stock:action.stock
     } );
};

const fetchFail = (state, action) => {
    return updateObject( state, {
        type:action.type,
        error: action.error,
        loading: false,
    });
}

const reducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case actionTypes.FETCH_INVENTORY_START: return fetchStart(state, action);
        case actionTypes.FETCH_INVENTORY_SUCCESS: return fetchSuccess(state, action);
        case actionTypes.FETCH_INVENTORY_FAIL: return fetchFail(state, action);
        default:
            return state;
    }
};

export default reducer;