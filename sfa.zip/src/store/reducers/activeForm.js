import { updateObject } from '../utility';
import * as actionTypes from '../actions/actionTypes';

const initialState = {
    ActiveForm: null,

};

const setActiveForm = ( state, action ) => {
    return updateObject( state, { 
        ActiveForm: action.ActiveForm,
        } );
};

const reducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case actionTypes.ACTIVE_FORM_UPDATE: return setActiveForm(state, action);
        default:
            return state;
    }
};

export default reducer;