import * as actionTypes from '../actions/actionTypes';
import { updateObject } from '../utility';

const initialState = {
    type:null,
    error: null,
    loading: false,
    items:null,
    syncTime:null,
};

const fetchStart = ( state, action ) => {
    return updateObject( state, { 
        type:action.type,
        error: null,
        loading: true 
        } );
};

const fetchSuccess = (state, action) => {
    return updateObject( state, { 
        type:action.type,
        error: null,
        loading: false,
        items: action.items,
        syncTime:action.syncTime
     } );
};

const fetchFail = (state, action) => {
    return updateObject( state, {
        type:action.type,
        error: action.error,
        loading: false,
    });
}

const reducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case actionTypes.INIT_START: return fetchStart(state, action);
        case actionTypes.INIT_SUCCESS: return fetchSuccess(state, action);
        case actionTypes.INIT_FAIL: return fetchFail(state, action);
        default:
            return state;
    }
};

export default reducer;