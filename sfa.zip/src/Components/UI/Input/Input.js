import React from 'react';
import classes from './Input.module.css';
import Switch from '@material-ui/core/Switch';

const input = ( props ) => {
    let inputElement = null;
    const inputClasses = [classes.InputElement];
    let LabalClasses = classes.LabelHide;

    if (props.invalid && props.shouldValidate && props.touched) {
        inputClasses.push(classes.Invalid);
        LabalClasses=classes.Label;
    }
    if (props.value !=='') 
        LabalClasses=classes.Label;
    else
    LabalClasses = classes.LabelHide;
    // console.log(props.elementConfig);
    switch ( props.elementType ) {
        case ( 'input' ):
            inputElement = <input 
                className={inputClasses.join(' ')}
                {...props.elementConfig}
                value={props.value}    
                readOnly=  {props.readOnly}
                onChange={props.changed} />;
            break;
        case ( 'textarea' ):
            inputElement = <textarea
                className={inputClasses.join(' ')}
                {...props.elementConfig}
                value={props.value}
                selectedIndex={-1}
                readOnly=  {props.readOnly}
                onChange={props.changed} />;
            break;
        case ( 'select' ):
            inputElement = (  
                <select
          
                    className={inputClasses.join(' ')}
                    value={props.value}
                    disabled=  {props.readOnly}
                    onChange={props.changed}>
                    {props.elementConfig.options.map(option => (
                        <option key={option.key} value={option.key}>
                           {option.value}
                        </option>
                    )
                    )}
                </select>
            );
            break;
            case ( 'switch' ):
                inputElement = <div  className={classes.SwitchElement}>
                {props.elementConfig.placeholder}
                     <Switch
                defaultChecked
                color="primary"
                inputProps={{ 'aria-label': 'primary' }}          />
                </div>
                // <input
                //     className={inputClasses.join(' ')}
                //     {...props.elementConfig}
                //     value={props.value}
                //     onChange={props.changed} />;
                break;
        default:
            inputElement = <input
                className={inputClasses.join(' ')}
                {...props.elementConfig}
                value={props.value} 
                onChange={props.changed}
                 />;
    }

    return (
        <div className={classes.Input}>
            <label  className={LabalClasses}>{props.elementConfig.placeholder}</label> 

            {inputElement}
        </div>
    );

};

export default input;