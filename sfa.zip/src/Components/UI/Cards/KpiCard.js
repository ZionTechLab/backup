import React from "react";
import classes from "./KpiCard.module.css";
import { Price } from "../../../Common/DecimalFormater";


const KpiCard = (props) => {
    const Header = {
        backgroundColor: props.Color
    }

    return (
        <div className={classes.t1} onClick={props.clicked}>
            <div className={classes.heading} style={Header}>{props.Heading}</div>
            <div className={classes.sub}>
                <Price showDecimals={true} showSymbol={false}>{props.Value1}</Price>
            </div>
        </div>
    );
};

export default KpiCard;
