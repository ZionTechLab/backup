import React, { useState, useEffect } from "react";
import linq from "linq";
import classes from './Autocomplete.module.css';
import ClearIcon from '@material-ui/icons/Clear';

const Autocomplete = (props) => {
    const [CustomersFilterd, setCustomersFilterd] = useState([]);
    const [DropStyle, setDropStyle] = useState([]);
    const [Text, setText] = useState('');
    const [CWidth, setWidth] = useState('');

    let Dstyle = {
        Width: CWidth
    }

    const onSearch = (event) => {
        updateFilter(event.target.value.toUpperCase());
    };
    const Click = (event) => {
        setDropStyle([classes.Drop, classes.Drop_Show])
    };
    const chg = (event) => {
        setText(CustomersFilterd[event.target.options.selectedIndex].value);
        setDropStyle([classes.Drop, classes.Drop_hide]);
        props.changed(event.target.value);
    };

    const ClearValue = (event) => {
        setText('');
        setDropStyle([classes.Drop, classes.Drop_hide]);
        props.changed('');
    };

    const updateFilter = (value) => {
        setText(value);

        let result = linq
            .from(props.options)
            .where((p) => p.value.toUpperCase().includes(value))
            .take(10)
            .toArray();

        setCustomersFilterd(result);
        setDropStyle([classes.Drop, classes.Drop_Show]);
    };

    const mount = () => {
        setDropStyle([classes.Drop, classes.Drop_hide]);
        Dstyle = { Width: CWidth };

    };

    useEffect(mount, []);

    return (
        <div className={classes.Autocomlete}
            ref={el => {

                if (!el) return;
                setWidth(el.getBoundingClientRect().width);
                // console.log(el.getBoundingClientRect().width); // prints 200px
            }}
        >
            <select className={DropStyle.join(" ")}
                size="10"
                onChange={chg} id="myselect" style={Dstyle} >

                {CustomersFilterd.map(option => (
                    <option key={option.key} value={option.key}>
                        {option.value}
                    </option>)
                )}
            </select>
            <div className={classes.aa}>

                <input
                    className={classes.InputElement}
                    value={Text}
                    onChange={onSearch}
                    onClick={Click} >

                </input>
                <div className={classes.ClearButton} onClick={ClearValue}><ClearIcon fontSize="small" /></div>
            </div>
        </div>
    )
};

export default Autocomplete;