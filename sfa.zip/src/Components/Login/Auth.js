import React,{Component} from 'react';

class auth extends  Component{
    state={
        controls:{
            email:{
                elemenType:'input',
                elementConfig:{
                    type:'email',
                    placeholder:'Email Address'
                },
                value:'',
                validation:{
                    required:true,
                    isEmail:true
                },
                valid:false,
                touched:false
            },
            password:{
                elemenType:'input',
                elementConfig:{
                    type:'password',
                    placeholder:'Password'
                },
                value:'',
                validation:{
                    required:true,
                    minLength:6
                },
                valid:false,
                touched:false
            }
        }
    }
    render(){
        return(
            <div>
                <form>

                    gggg
                </form>
            </div>
        )
    }
}

export default auth;