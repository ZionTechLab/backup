import React from 'react';
import './Login.css';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import { Component } from 'react'

class login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      pw: ''
    };
  }
  shoot = (event) => {
    if (this.state.username !== "IndikaAdmin" | this.state.pw !== 'ieplus')
      alert('Invalied User Name Or Password');
    else
      this.props.onSelectLanguage("OK");
  }
  myChangeHandler = (event) => {

    this.setState({ username: event.target.value });
  }
  myChangeHandler2 = (event) => {

    this.setState({ pw: event.target.value });
  }
  
  // componentDidMount() {
  //   fetch('https://rapi-00001.zionsl.com/Inventory/Get')
  //     .then(res => res.json())
  //     .then((data) => {
  //       this.setState({ contacts: data, FilterdList: data })
  //     })
  //     .catch(console.log)
  // }
  // onSearch = (event) => {
  //   this.setState({
  //     FilterdList: this.state.contacts.filter((item) => item.itemName.toUpperCase().includes(event.target.value.toUpperCase()))
  //   });

  // }

  render() {
    return (


      <div className="Login-Container" >
        <Grid item xs={12}>
          <Grid container justify="center"  >
            <img className="logo" src={'/image/ieplus-logo.png'} />
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid container justify="center"  >
            <Grid item sm={4} xs={12}>

              <Grid justify="center" >

                <Box color="error.contrastText" p={1}  >
                  <Grid container justify="center"  >
                    <TextField id="filled-basic" fullWidth label="User Name" variant="filled" color="secondary" onChange={this.myChangeHandler} />
                  </Grid>
                </Box>
                <Box color="error.contrastText" p={1}  >
                  <Grid container justify="center"  >
                    <TextField id="filled-basic" fullWidth label="Password" variant="filled" type="password" color="secondary" onChange={this.myChangeHandler2} />
                  </Grid>
                </Box>
                <Box color="error.contrastText" p={1}  >
                  <Grid container justify="center"  >

                    <Button type="submit" fullWidth variant="contained" color="primary" onClick={this.shoot}>Log In</Button>


                  </Grid>
                </Box>

              </Grid>


            </Grid>

          </Grid>
        </Grid>




      </div>
    );
  }
}

export default login;







