import { Component } from 'react'
import { connect } from 'react-redux';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import './Test.css';
import TextField from '@material-ui/core/TextField';
import * as actions from '../../store/actions/index';
import linq from "linq";

class test extends Component {
  state = {
    FilterdList: [],
    FilterText: ''
  }

  componentDidMount() {



    this.props.onFetchInventory();

    this.interval = setInterval(() => {
      this.props.onFetchInventory();
      console.log("update");
    }
      , 600000);

  }

  onSearch = (event) => {

    const result3 = linq.from(this.props.items)
      .join(
        this.props.stock,
        pk => pk.item_ID,
        fk => fk.item_ID,
        (left, right) => ({ ...left, ...right })
      )
      .toArray();

    this.setState({
      FilterdList: result3.filter((item) => item.itemName.toUpperCase().includes(event.target.value.toUpperCase()))
    });

  }

  render() {
    return (
      <div >

        <div >

          <div className="UpdatedTime"> {this.props.lastUpdatedOn}  </div>
          <TextField id="filled-basic" label="search" variant="filled" onChange={this.onSearch} value={this.state.searchedValue} />
   
        </div>


        <div className="Page-Cotaint">
          <Paper >
            <TableContainer component={Paper}>
              <Table stickyHeader size="small" aria-label="sticky table" >
                <TableHead>
                  <TableRow>
                    <TableCell>Item Code</TableCell>
                    <TableCell>Item Name</TableCell>
                    <TableCell align="right">qty</TableCell>

                  </TableRow>
                </TableHead>
                <TableBody>
                  {this.state.FilterdList.map((row) => (
                    <TableRow hover role="checkbox" key={row.item_ID}>
                      <TableCell component="th" scope="row"> {row.item_ID}</TableCell>
                      <TableCell align="left">{row.itemName}</TableCell>
                      <TableCell align="right">{row.qty}</TableCell>

                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>

        </div>
        {/* <Contacts contacts={this.state.contacts} /> */}

      </div>
    );
  }
}


let mapStateToProps = state => {

  return {
    stock: state.inventory.stock,
    items: state.init.items


  };
};

const mapDispatchToProps = dispatch => {
  console.log("dis");
  return {

    onFetchInventory: () => dispatch(actions.inventory())

  };
};

export default connect(mapStateToProps, mapDispatchToProps)(test);
