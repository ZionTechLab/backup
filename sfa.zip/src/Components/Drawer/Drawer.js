import React, { Component } from 'react';
import { connect } from 'react-redux';
import Drawer from '@material-ui/core/Drawer';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import ContactsIcon from '@material-ui/icons/Contacts';
import InventoryIcon from '@material-ui/icons/ListAlt';
import HelpOutlineIcon from '@material-ui/icons/HelpOutline';
import UsersIcon from '@material-ui/icons/AccountCircle';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import RefreshIcon from '@material-ui/icons/Refresh';
import AccountCircle from '@material-ui/icons/AccountCircle';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import * as actions from '../../store/actions/index';
import classes from './Drawer.module.css';

class TemporaryDrawer extends Component {
    state = {
        isDrawerOpened: false,
        icons:[],
        Functions:[]
    }

    componentDidMount() {
        let userType = Number(localStorage.getItem('userType'));
        if(userType==1){
            this.setState({
                icons: [<UsersIcon /> ,<HelpOutlineIcon />],
                Functions:['Users',  'Help']
                 });
        }
        else if(userType==3){
            this.setState({
                icons: [ <ContactsIcon />, <InventoryIcon />,<ShoppingCartIcon/>, <HelpOutlineIcon />],
                Functions:['Customers', 'Inventory','Order', 'Help']
                 });
        }
       
        
        
    }
    Refresh = () => {
        this.props.onInitialize(this.props.userId, true);
    }
    
    toggleDrawer = (event, isOpen) => {
        this.setState({ isDrawerOpened: isOpen });
    }
    shoot = (event, FormName) => {
        console.log('call FormName');
        this.props.onFormChange(FormName.text);
    }
    render() {

        //   const toggleDrawer = ( open) => (event) => {
        //     // if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
        //     //   return;
        //     // }

        //    this. setState({isDrawerOpened: open });
        //   };

        let company = (
            <div  >
                <img className={classes.Logo} alt='' src={'/image/ZionSFM_logo.png'} />
            </div>);

 

        const list = () => (
            
            <div
                // className={classes.list}
                role="presentation"
                onClick={(event) => this.toggleDrawer(event, false)}

                onKeyDown={(event) => this.toggleDrawer(event, false)}
            >
               
                {company}
                <Divider />
                <List>

                    {this.state.Functions.map((text, index) => (
                        <ListItem button key={text}
                            onClick={(event) => this.shoot(event, { text })}
                        >
                            <ListItemIcon> {this.state. icons[index]} </ListItemIcon>
                            <ListItemText primary={text} />
                            {/* onClick={this.props.onSelectLanguage({text})} */}
                        </ListItem>
                    ))}
                </List>
                <Divider />
                <p className={classes.CopyRight}>
                    Copyright 2021 © Indika Enterprises (PVT) LTD.
       <br />
       All Rights Reserved. Solution by Zion Technologies.</p>

            </div>
        );


        return (
            <div >
                <div className={classes.appBar}>
                    <IconButton edge="start" color="inherit" aria-label="menu"
                        onClick={(event) => this.toggleDrawer(event, true)} >
                        <MenuIcon />
                    </IconButton>
                    <Drawer open={this.state.isDrawerOpened}
                        onClose={(event) => this.toggleDrawer(event, false)}>
                        {list()}
                    </Drawer>

                    <Button color="inherit">{this.props.ActiveForm}</Button>

                    <div className={classes.IconUser}>
                        <IconButton edge="start" color="inherit" aria-label="Refresh"
                            onClick={this.Refresh}                     >
                            <RefreshIcon />
                        </IconButton>
                        <IconButton
                            aria-label="account of current user"
                            aria-controls="menu-appbar"
                            aria-haspopup="true" edge="end"
                            //  onClick={handleMenu}
                            color="inherit" >
                            <AccountCircle />
                        </IconButton>
                    </div>
                </div>




            </div>
        )
    }
}


const mapStateToProps = state => {
    return {
        userId: state.auth.userId,
        ActiveForm: state.activeForm.ActiveForm,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFormChange: (FormName) => dispatch(actions.activeForm(FormName))
        , onInitialize: (userId, isRefresh) => dispatch(actions.init(userId, isRefresh))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(TemporaryDrawer);