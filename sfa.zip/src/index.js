import React from 'react';
import ReactDOM from 'react-dom';
import {createStore, applyMiddleware, compose, combineReducers} from 'redux';
import {Provider} from 'react-redux';
import thunk from 'redux-thunk';

import './index.css';
import App from './App';
// import reducer from './store/reducer';
import authReducer from './store/reducers/auth';
import inventoryReducer from './store/reducers/inventory';
import initReducer from './store/reducers/init';
import activeFormReducer from './store/reducers/activeForm';

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const rootReducer=combineReducers({
  auth:authReducer,
  // reducer:reducer,
  inventory:inventoryReducer,
  init:initReducer,
  activeForm:activeFormReducer
})
const store =createStore(rootReducer,composeEnhancers(
  applyMiddleware(thunk)
));

ReactDOM.render(
  <Provider store={ store }>
    <React.StrictMode>
      <App />
    </React.StrictMode>
  </Provider>,
  document.getElementById('root')
);