import axios from 'axios';
import * as Config from '../Common/Config';

export function getUsers() {
    let url = Config.API_URL + 'Users/Get_Users';
    let x = []

    // axios.get(url)
    // .then(response => {
    //     x=response.data;
    //     console.log(x);
    // })
    // .catch(err => {
    //     console.log(err);
    // });

    // x = async () => {
    //     axios.get(url)
    //         .then(response => {
    //             x = response.data;

    //         })
    //         .catch(err => {
    //             console.log(err);
    //         });

    // }

     x = async () => {
        try {
            const resp = await axios.get(url);
            console.log(resp.data);
        } catch (err) {
            console.error(err);
        }
    };

    return x;
}