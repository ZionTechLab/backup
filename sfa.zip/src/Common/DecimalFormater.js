import React, { useState } from "react";

export function Price  (props)  {
 
  const price = props.children.toLocaleString("en", {
    style: props.showSymbol ? "currency" : undefined,
    currency: props.showSymbol ? "USD" : undefined,
    maximumFractionDigits: props.showDecimals ? 2 : 0,
    minimumFractionDigits: 2
  });
  
    return <span className={props.className}>{price}</span>;
  };