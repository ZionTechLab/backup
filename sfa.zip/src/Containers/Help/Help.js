
import classes from './Help.module.css';
import Grid from '@material-ui/core/Grid';
import WhatsAppIcon from '@material-ui/icons/WhatsApp';
import { green,red } from '@material-ui/core/colors';
import MailOutlineIcon from '@material-ui/icons/MailOutline';

const help = (props) => {
    return (
        <div className={classes.help}>
            <img className={classes.Logo} alt ="" src={'/image/ZionSFM_logo.png'} />
        
            <h5>Don't hesitate to contact us...</h5>
                    
            <Grid container spacing={1} justify="center">
                <Grid item >
                <MailOutlineIcon fontSize='large' style={{ color: red[500] }} />
                </Grid>
                <Grid item  >
                 <a  href="mailto:'info@zionsl.com'">info@zionsl.com</a>
                </Grid>
            </Grid>

            <Grid container spacing={1} justify="center">
                <Grid item >
                <WhatsAppIcon fontSize='large' style={{ color: green[800] }} />
                </Grid>
                <Grid item  >
                <a className={classes.PhoneNo} href="tel:0706449844">0706 44 98 44</a>
                </Grid>
            </Grid>
        </div>
    )
};

export default help;