import React, { Component } from 'react';
import linq from "linq";
import {  BarChart,  Bar,  XAxis,  YAxis,  CartesianGrid,  Tooltip,  Legend} from "recharts";

var monthNames = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

class Dashboard extends Component {
  state = {
    saleHistory: []
  }

  componentDidMount() {
    let data=JSON.parse(localStorage.getItem('saleHistory'));
    console.log(data);
    this.setState({
      saleHistory: data
    });
  }
  
  render() {
    return (
      <div>
        <h4>Sales History</h4>
        <BarChart
          width={600}
          height={300}
          data={this.state.saleHistory}
          margin={{
            top: 10,
            right: 30,
            left: 20,
            bottom: 10
          }}
        >

          <CartesianGrid strokeDasharray="3 3" />

          <XAxis dataKey="month" tick={{ fontSize: 10 }} />
          <YAxis />
          <Tooltip />
          {/* <Legend /> */}
          <Bar dataKey="sale" fill="#8884d8" />

        </BarChart>
        </div>
    )
  }
}

export default Dashboard;
