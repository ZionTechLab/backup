import { Component } from 'react'
import axios from 'axios';
import * as Config from '../../Common/Config';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import classes from './Users.module.css';
import EditOutlinedIcon from '@material-ui/icons/EditOutlined';
import Modal from '@material-ui/core/Modal';
import ArrowBackIosOutlinedIcon from '@material-ui/icons/ArrowBackIosOutlined';
import IconButton from '@material-ui/core/IconButton';
import MButton from '@material-ui/core/Button';
import Button from '../../Components/UI/Button/Button';
import Input from '../../Components/UI/Input/Input';
import { checkValidity } from '../../Common/InputValidations';
import linq from "linq";
import Spinner from '../../Components/UI/Spinner/Spinner'
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';

class Users extends Component {
    state = {
        Users: [],
        SalesMen: [],
        open: false,
        loading: false,
        DialogOpen: false,
        isNewMode: false,
        isError: false,
        DialogMessege: '',
        controls: {

            UserId: {
                elementType: 'input',
                elementConfig: {
                    type: 'User Id',
                    placeholder: 'User ID',

                },
                value: '',
                validation: {
                    required: true,
                    minLength: 4,
                    maxLength: 8
                },
                valid: false,
                touched: false,
                readOnly: true
            },
            UserName: {
                elementType: 'input',
                elementConfig: {
                    type: 'User Name',
                    placeholder: 'User Name'
                },
                value: '',
                validation: {
                    required: true,
                    minLength: 5,
                    maxLength: 25
                },
                valid: false,
                touched: false
            },
            email: {
                elementType: 'input',
                elementConfig: {
                    type: 'email',
                    placeholder: 'Email Address'
                },
                value: '',
                validation: {
                    required: true,
                    minLength: 5,
                    isEmail: true
                },
                valid: false,
                touched: false
            },
            mobile: {
                elementType: 'input',
                elementConfig: {
                    type: 'mobile',
                    placeholder: 'Mobile No'
                },
                value: '',
                validation: {
                    required: true,
                    minLength: 10,
                    isPhoneNo: true
                },
                valid: false,
                touched: false
            },
            password: {
                elementType: 'input',
                elementConfig: {
                    type: 'password',
                    placeholder: 'Password'
                },
                value: '',
                validation: {
                    required: true,
                    minLength: 6,
                    maxLength: 20
                },
                valid: false,
                touched: false
            },
            userType: {
                elementType: 'select',
                elementConfig: {
                    type: 'userType',
                    placeholder: 'User Type',
                    options: [{ key: 1, value: 'Admin' }, { key: 2, value: 'Back Office' }, { key: 3, value: 'Sales Men' }]
                },
                value: 3,
                validation: {
                    required: true,
                //    minLength: 10,
               //     isPhoneNo: true
                },
                valid: false,
                touched: false
            },
            SalesMen: {
                elementType: 'select',
                elementConfig: {
                    type: 'SalesMan',
                    placeholder: 'Sales Rep ID',
                //    options: [{ key: '1', value: 'jj' }, { key: '2', value: 'jdj' }]
                },
                value: '0',
                validation: {
                    required: true,
                   // minLength: 10,
                   // isPhoneNo: true
                },
                valid: false,
                touched: false
            },
            Active: {
                elementType: 'switch',
                elementConfig: {
                    type: 'Active',
                    placeholder: 'Active',

                },
                value: '',
                validation: {
                    required: true,
                    minLength: 6,
                    maxLength: 20
                },
                valid: false,
                touched: false,
                displayValue: true
            }
        }
    }

    DialogClose = (event) => {
        this.setState({
            DialogOpen: false,
            isError: false,
            DialogMessege: ''
        });
    };

    inputChangedHandler = (event, controlName) => {
        console.log(event.target.value);
        let updatedControls = {
            ...this.state.controls,
            [controlName]: {
                ...this.state.controls[controlName],
                value: event.target.value,
                valid: checkValidity(event.target.value, this.state.controls[controlName].validation),
                touched: true
            }
        };
        if(controlName=='userType' ){
            if(event.target.value==3){
                console.log('sm');
                 updatedControls['SalesMen'].value='0';
                 updatedControls['SalesMen'].readOnly=false;
            }
            else        {   
                console.log('other');
                updatedControls['SalesMen'].value='0';
            updatedControls['SalesMen'].readOnly=true;
        }   
        }
    
        this.setState({ controls: updatedControls });
    }

    submitHandler = (event) => {
  event.preventDefault();
        this.setState({
            loading: true
        });

        let url = Config.API_URL + 'Admin/Update_User';
        let temp_state = this.state.controls;
        let UserData = {
            user_ID: temp_state["UserId"].value,
            userName: temp_state["UserName"].value,
            email: temp_state["email"].value,
            moible: temp_state["mobile"].value,
            employee_ID: temp_state["SalesMen"].value,
            password: temp_state["password"].value,
            isActive: temp_state["Active"].value,
            userType:Number(temp_state["userType"].value),
            isNewMode: this.state.isNewMode,
        };
        console.log(UserData);
        axios.post(url, UserData)
            .then(response => {
              //    console.log(response);
                if (response.data.isSuccess === true)
                    //   console.log("Succs");

                    this.setState({
                        loading: false,
                        open: false,
                        DialogOpen: true,
                        DialogMessege: 'User Updated'
                    });
                this.RefreshUsers();
            })
            .catch(error => {
              //  console.log(error.response.data.detail);
              //  if() 
            //   console.log(err.errors); 
            //     console.log(err); console.log(JSON.stringify(err))
                this.setState({
                    loading: false,
                    isError: true,
                    DialogMessege: error.response.data.detail
                });
            });
    }
    AddNewUser = (event) => {
        let temp_state = this.state.controls;

        temp_state["UserId"].value = '';
        temp_state["UserId"].readOnly = false;
        temp_state["UserName"].value = '';
        temp_state["email"].value = '';
        temp_state["mobile"].value = '';
        temp_state["SalesMen"].value = '0'; 
               temp_state["SalesMen"].readOnly = false;
        temp_state["password"].value = null;
        temp_state["Active"].value = true;
        temp_state["userType"].value = 3;

        this.setState({
            open: true,
            isNewMode: true,
            controls: temp_state
        });

    };

    handleOpen = (user_ID) => {
        var User = linq.from(this.state.Users).where(p => p.user_ID === user_ID).first();
        let temp_state = this.state.controls;

        temp_state["UserId"].value = User.user_ID;
        temp_state["UserId"].readOnly = true;
        temp_state["UserName"].value = User.userName;
        temp_state["email"].value = User.email;
        temp_state["mobile"].value = User.moible;
        temp_state["SalesMen"].value = User.employee_ID;
        temp_state["SalesMen"].readOnly = User.userType===3 ?false:true;
        temp_state["password"].value = User.password;
        temp_state["Active"].value = User.isActive;
 temp_state["userType"].value = User.userType;

        this.setState({
            open: true,
             isNewMode: false,
            controls: temp_state
        });
        // console.log(user_ID);
    };

    handleClose = () => {
        this.setState({
            open: false
        });
    };

    RefreshUsers() {
        this.setState({
            loading: true
        });

        let url = Config.API_URL + 'Admin/Get_Users';

        axios.get(url)
            .then(response => {
                this.setState({
                    Users: response.data,
                    loading: false
                });
            })
            .catch(err => {
                this.setState({
                    loading: false,
                    isError: true,
                    DialogMessege: err.message
                });
            });
    }

    RefreshSalesMen() {
        this.setState({
            loading: true
        });

        let url_SR = Config.API_URL + 'Admin/Get_SalesMen';

        axios.get(url_SR)
            .then(response => {
                let temp_state = this.state.controls;

                var result = linq.from(response.data)
                    .select(user => ({
                        key: user.selesRep_ID,
                        value: user.selesRepName,
                    })).toArray();
                
                    result= [...result, {key:'0',value:''}];
                    console.log(result);
                temp_state["SalesMen"].elementConfig.options = result;

                this.setState({
                    controls: temp_state,
                    loading: false
                });
            })
            .catch(err => {
                this.setState({
                    loading: false,
                    isError: true,
                    DialogMessege: err.message
                });
            });
    }

    componentDidMount() {
        this.RefreshUsers();
        this.RefreshSalesMen();
    }

    render() {
        const formElementsArray = [];
        for (let key in this.state.controls) {
            formElementsArray.push({
                id: key,
                config: this.state.controls[key]
            });
        }

        let form = formElementsArray.map(formElement => (
            <Input
                key={formElement.id}
                elementType={formElement.config.elementType}
                elementConfig={formElement.config.elementConfig}
                value={formElement.config.value}
                invalid={!formElement.config.valid}
                shouldValidate={formElement.config.validation}
                touched={formElement.config.touched}
                readOnly={formElement.config.readOnly}
                changed={(event) => this.inputChangedHandler(event, formElement.id)} />
        ));
        let myDialog = ''

        if (this.state.DialogOpen || this.state.isError) {
            myDialog = (<Dialog
                open={true}
                onClose={this.DialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title"> {this.state.DialogMessege}</DialogTitle>
                {/* <DialogContent>
                <DialogContentText id="alert-dialog-description">
                   {this.state.DialogMessege}
              </DialogContentText>
            </DialogContent> */}
                <DialogActions>
                    <MButton onClick={this.DialogClose} color="secondary">
                        OK
              </MButton>

                </DialogActions>
            </Dialog>);
        };


        let Page = (
            <div className="Page-Cotaint">
                <Paper >
                    <TableContainer component={Paper}>
                        <Table stickyHeader size="small" aria-label="sticky table" >
                            <TableHead>
                                <TableRow>
                                    <TableCell>User ID</TableCell>
                                    <TableCell>User Name</TableCell>
                                    <TableCell width="15px"></TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {this.state.Users.map((row) => (
                                    <TableRow hover role="checkbox" key={row.item_ID}>
                                        <TableCell component="th" scope="row"> {row.user_ID}</TableCell>
                                        <TableCell align="left" >{row.userName}</TableCell>
                                        <TableCell width="15px" onClick={(event) => this.handleOpen(row.user_ID)}><EditOutlinedIcon /></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    <Modal open={this.state.open} onClose={this.handleClose}>
                        <div className={classes.Moddle_User}>
                            <div className={classes.Moddle_Header}>
                                <IconButton edge="start" color="inherit" aria-label="menu"
                                    onClick={this.handleClose} >
                                    <ArrowBackIosOutlinedIcon />
                                </IconButton>
                                <MButton color="inherit">{this.state.isNewMode ? 'New User' : 'Edit User'}</MButton>
                            </div>
                            <div className={classes.Moddle_Contains}>
                                <form onSubmit={this.submitHandler}>
                                    {form}
                                    <Button btnType="Success">{this.state.isNewMode ? 'Save' : 'Update'}</Button>

                                </form>
                            </div>
                        </div>
                    </Modal>

                </Paper>
            </div>
        );

        if (this.state.loading) {
            Page = <Spinner />
        };



        return (
            <div>
                {Page}
                {myDialog}

                <button className={classes.AddButton} onClick={this.AddNewUser} color="secondary">
                    +
                   {/* <AddIcon style={{ fontSize: 40 }}/> */}
                </button>
            </div>
        );
    }
}

export default Users;