import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as Config from "../../Common/Config";
import axios from "axios";

const GetAllUsers = createAsyncThunk("user/getAll", async (payload) => {
  try {
    let url = Config.API_URL + "Admin/Get_Users";
    const response = await axios.get(url);
    // console.log(response.data);
    return response.data;
  } catch (error) {
    return error;
  }
});

const Update_User = createAsyncThunk("user/Update_User", async (payload) => {
  try {
    let url = Config.API_URL + "Admin/Update_User";
    console.log(payload);
    const response = await axios.post(url, payload);
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error;
  }
});

const userSlice = createSlice({
  name: "user",
  initialState: {
    UpdateUser: { loading: false, isSuccess: false, error: null },
    Users: {
      userData: [],
      loading: false,
      isSuccess: false,
      error: null,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(GetAllUsers.pending, (state) => {
        return {
          ...state,
          Users: { userData: [], loading: true, isSuccess: false, error: null },
        };
      })
      .addCase(GetAllUsers.fulfilled, (state, action) => {
        // console.log(action);
        return {
          ...state,
          Users: {
            userData: action.payload,
            loading: false,
            isSuccess: true,
          },
        };
      })
      .addCase(GetAllUsers.rejected, (state, action) => {
        return {
          ...state,
          Users: {
            userData: action,
            loading: false,
            isSuccess: null,
            error: action,
          },
        };
      })
      .addCase(Update_User.pending, (state) => {
        return {
          ...state,
          UpdateUser: {
            loading: true,
            isSuccess: false,
            error: null,
          },
        };
      })
      .addCase(Update_User.fulfilled, (state, action) => {
        console.log(action);
        return {
          ...state,
          UpdateUser: {
            loading: false,
            isSuccess: action.payload.isSuccess,
            error: action.payload.varOutMsg,
          },
        };
      })
      .addCase(Update_User.rejected, (state, action) => {
        return {
          ...state,
          UpdateUser: {
            loading: false,
            isSuccess: false,
            error: action,
          },
        };
      });
  },
});

export const userReducer = userSlice.reducer;

export { GetAllUsers, Update_User };
