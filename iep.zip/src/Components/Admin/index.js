import React, { useState, useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { GetAllUsers, Update_User } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import CreateOutlinedIcon from "@mui/icons-material/CreateOutlined";
import CheckOutlinedIcon from "@mui/icons-material/CheckOutlined";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { useFormik } from "formik";
import * as yup from "yup";
import TextField from "@mui/material/TextField";
import Checkbox from "@mui/material/Checkbox";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Spinner from "../Spinner/Spinner";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function Admin() {
  const data = useSelector((state) => state.user.Users);
  const UpdateUser = useSelector((state) => state.user.UpdateUser);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(GetAllUsers());
  }, [dispatch]);

  useEffect(() => {
    if (!UpdateUser.loading && !UpdateUser.error) {
      modalClose();
      setShowDialog(true);
      dispatch(GetAllUsers());
    }
  }, [UpdateUser, dispatch]);

  const [ModalStatus, setModalStatus] = useState({
    isEditMode: false,
    isOpen: false,
  });
  const [showDialog, setShowDialog] = useState(false);

  const modalClose = () =>
    setModalStatus({
      isEditMode: false,
      isOpen: false,
    });

  const dialogClose = () => setShowDialog(false);

  const EditUser = (isEditMode, user) => {
    setShowDialog(false);
    setModalStatus({
      isEditMode: isEditMode,
      isOpen: true,
    });

    formik.resetForm({
      values: {
        user_ID: isEditMode ? user.user_ID : "",
        userName: isEditMode ? user.userName : "",
        route_Code: isEditMode ? user.route_Code : "",
        isAdmin: isEditMode ? user.isAdmin : false,
        isActive: isEditMode ? user.isActive : true,
        password: isEditMode ? user.password : "",
        repeatPassword: isEditMode ? user.password : "",
      },
    });
  };

  const validationSchema = yup.object({
    user_ID: yup
      .string("User ID")
      .min(4, "User ID should be of minimum 4 characters length")
      .required("User ID is required"),
    userName: yup
      .string("User Name")
      .min(4, "User Name should be of minimum 4 characters length")
      .required("User Name is required"),
    password: yup
      .string("password")
      .min(5, "Password should be of minimum 5 characters length")
      .required("Password is required"),
    repeatPassword: yup
      .string("Repeat Password")
      .oneOf([yup.ref("password"), null], "Passwords must match")
      .required("Repeat Password is required"),
    route_Code: yup.string("Route").required("Route is required"),
  });

  const formik = useFormik({
    initialValues: {
      user_ID: "",
      userName: "",
      password: "",
      repeatPassword: "",
      route_Code: "",
      isAdmin: false,
      isActive: false,
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      values.isEditMode = ModalStatus.isEditMode;
      dispatch(Update_User(values));
    },
  });

  let Contains = UpdateUser.loading ? (
    <Spinner />
  ) : (
    <div>
      <Box color="error.contrastText" p={2}>
        <Button
          color="primary"
          variant="contained"
          onClick={() => EditUser(false, {})}
        >
          Add User
        </Button>
      </Box>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
          <TableHead>
            <TableRow>
              <TableCell>User ID</TableCell>
              <TableCell>Name</TableCell>
              <TableCell align="center">Admin</TableCell>
              <TableCell align="center">Active</TableCell>
              <TableCell>Routes</TableCell>
              <TableCell></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.userData.map((row) => (
              <TableRow
                key={row.user_ID}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell>{row.user_ID}</TableCell>
                <TableCell>{row.userName}</TableCell>
                <TableCell align="center">
                  {row.isAdmin ? <CheckOutlinedIcon /> : ""}
                </TableCell>
                <TableCell align="center">
                  {row.isActive ? <CheckOutlinedIcon /> : ""}
                </TableCell>
                <TableCell>{row.route_Code}</TableCell>
                <TableCell>
                  <Button onClick={() => EditUser(true, row)}>
                    <CreateOutlinedIcon />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Modal
        open={ModalStatus.isOpen}
        onClose={modalClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Modal
            open={showDialog}
            onClose={dialogClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box sx={style}>
              <Typography id="modal-modal-title" variant="h6" component="h2">
                {UpdateUser.error || "Success"}
              </Typography>
              <Typography
                id="modal-modal-description"
                sx={{ mt: 2 }}
              ></Typography>
            </Box>
          </Modal>

          <Typography id="modal-modal-title" variant="h6" component="h2">
            {ModalStatus.isEditMode ? "Edit" : "Add"} User
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            <form onSubmit={formik.handleSubmit}>
              <Box color="error.contrastText" p={1}>
                <TextField
                  variant="filled"
                  fullWidth
                  id="user_ID"
                  name="user_ID"
                  label="User ID"
                  value={formik.values.user_ID}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.user_ID && Boolean(formik.errors.user_ID)
                  }
                  helperText={formik.touched.user_ID && formik.errors.user_ID}
                  disabled={ModalStatus.isEditMode}
                />
              </Box>
              <Box color="error.contrastText" p={1}>
                <TextField
                  fullWidth
                  variant="filled"
                  id="userName"
                  name="userName"
                  label="Name"
                  value={formik.values.userName}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.userName && Boolean(formik.errors.userName)
                  }
                  helperText={formik.touched.userName && formik.errors.userName}
                />
              </Box>
              <Box color="error.contrastText" p={1}>
                <TextField
                  fullWidth
                  variant="filled"
                  id="password"
                  name="password"
                  label="Password"
                  type="password"
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.password && Boolean(formik.errors.password)
                  }
                  helperText={formik.touched.password && formik.errors.password}
                />
              </Box>

              <Box color="error.contrastText" p={1}>
                <TextField
                  fullWidth
                  variant="filled"
                  id="repeatPassword"
                  name="repeatPassword"
                  label="Repeat Password"
                  type="password"
                  value={formik.values.repeatPassword}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.repeatPassword &&
                    Boolean(formik.errors.repeatPassword)
                  }
                  helperText={
                    formik.touched.repeatPassword &&
                    formik.errors.repeatPassword
                  }
                />
              </Box>
              <Box color="error.contrastText" p={1}>
                <TextField
                  variant="filled"
                  fullWidth
                  id="route_Code"
                  name="route_Code"
                  label="Route"
                  value={formik.values.route_Code}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.route_Code &&
                    Boolean(formik.errors.route_Code)
                  }
                  helperText={
                    formik.touched.route_Code && formik.errors.route_Code
                  }
                />
              </Box>
              <Box color="error.contrastText" p={1}>
                <FormGroup>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.isAdmin}
                        onChange={formik.handleChange}
                        name="isAdmin"
                      />
                    }
                    label="Admin"
                    sx={{
                      ".MuiFormControlLabel-label": { color: "black" },
                    }}
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.isActive}
                        onChange={formik.handleChange}
                        name="isActive"
                      />
                    }
                    label="Active"
                    sx={{
                      ".MuiFormControlLabel-label": { color: "black" },
                    }}
                  />
                </FormGroup>
              </Box>
              <Box color="error.contrastText" p={1}>
                <Button
                  color="primary"
                  variant="contained"
                  fullWidth
                  type="submit"
                >
                  Save
                </Button>
              </Box>
            </form>
          </Typography>
        </Box>
      </Modal>
    </div>
  );

  return <div>{Contains}</div>;
}

export default Admin;
