const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const testController = require("../controllers/testController");
const verifyToken = require("./verifyToken");

router.post("/auth/register", authController.register);
router.post("/auth/login", authController.login);
router.post("/test/test", testController.test);
router.post("/auth/gemba", verifyToken, authController.gemba);

module.exports = router;
