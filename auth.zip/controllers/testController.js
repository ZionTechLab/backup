const jwt = require("jsonwebtoken");
require("dotenv").config();
const bcrypt = require("bcryptjs"); // For password hashing (assuming you're using it)
const Sequelize = require("sequelize");

const sequelize = new Sequelize("ieplus", "sa", "nimda@123", {
  dialect: "mssql",
  host: "89.117.60.18",
});

const test = async (req, res) => {
  try {
    const [results] = await sequelize.query("exec [dbo].[sp_Get_Inventory]", {
      type: Sequelize.QueryTypes.RAW, // Specify query type as RAW
    });
    res.json(results);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).send(Error);
  }
};

module.exports = { test };
