const jwt = require("jsonwebtoken");
require("dotenv").config();

const bcrypt = require("bcryptjs"); // For password hashing (assuming you're using it)

const register = async (req, res) => {
  try {
    const newUser = req.body;
    console.log(req.body);
    if (newUser.username != "test") {
      res.status(500).json({ message: "Invalied User Name or Password " });
    } else {
      const accessToken = jwt.sign(
        { username: newUser.username }, // Use user ID for better security
        process.env.JWT_SECRET,
        { expiresIn: "15m" }
      );
      console.log(accessToken);

      jwt.verify(accessToken, process.env.JWT_SECRET, (err, decoded) => {
        console.log(decoded);
      });

      // Generate a refresh token with a longer expiration (e.g., 1 hour)
      const refreshToken = jwt.sign(
        { userId: newUser._id }, // Use user ID for better security
        process.env.JWT_SECRET + process.env.REFRESH_TOKEN_SECRET, // Concatenate for added security
        { expiresIn: "1h" }
      );

      // Securely store the refresh token in a database or other secure mechanism
      await storeRefreshToken(refreshToken, newUser._id); // Implement secure storage

      res.json({
        accessToken,
        refreshToken,
        AccessTokenExpiration: new Date(Date.now() + 15 * 60 * 1000),
        refreshTokenExpiration: new Date(Date.now() + 60 * 60 * 1000), // Include expiration details (1 hour from now)
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Registration failed" });
  }
};

// Function to securely store the refresh token (implementation details omitted)
const storeRefreshToken = async (token, userId) => {
  // Implement secure storage logic (e.g., database with encryption, separate secrets management service)
};
const gemba = async (req, res) => {
  res.json({
    AccessTokenExpiration: new Date(Date.now() + 15 * 60 * 1000),
    refreshTokenExpiration: new Date(Date.now() + 60 * 60 * 1000), // Include expiration details (1 hour from now)
  });
};

const login = async (req, res) => {
  try {
    // 1. Get username and password from request body
    const { username, password } = req.body;

    console.log(req.body);
    // 2. Validate username and password (presence and format)
    if (!username || !password) {
      return res.status(400).json({ message: "Missing username or password" });
    }
    console.log("d");
    // 3. Find the user by username
    // const user = await User.findOne({ username });

    // 4. Check if user exists
    // if (!user) {
    //   return res.status(401).json({ message: "Invalid credentials" });
    // }

    // 5. Compare password with hashed password (assuming password is hashed)
    // const isMatch = await bcrypt.compare(password, user.password); // Replace with your password comparison logic if not using bcrypt

    // 6. Check password match
    // if (!isMatch) {
    //   return res.status(401).json({ message: "Invalid credentials" });
    // }

    // 7. User login successful, generate JWT token
    const token = jwt.sign({ username: username }, process.env.JWT_SECRET, {
      expiresIn: "30m",
    });

    // 8. Send successful response with token
    res.json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// const login = async (req, res) => {

//   const token = jwt.sign({ username: User.username }, process.env.JWT_SECRET, {
//     expiresIn: "30m",
//   });
//   res.json({ token });
// };

module.exports = { register, login, gemba };
