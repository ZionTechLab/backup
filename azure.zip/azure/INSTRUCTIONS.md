# Azure Cost Report

Fetches monthly Azure costs per subscription and outputs a Markdown table.

## Prerequisites

- Python 3.9+
- Azure CLI **or** a Service Principal with **Cost Management Reader** role on each subscription

## Installation

```powershell
pip install azure-mgmt-costmanagement azure-identity
```

## Configuration

Open `azure_cost_report.py` and edit the `SUBSCRIPTIONS` list near the top:

```python
SUBSCRIPTIONS = [
    {"label": "Dev-OPS",    "id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"},
    {"label": "Pre-Prod",   "id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"},
    # add or remove entries to match your environment
]
```

| Field   | Description                                      |
|---------|--------------------------------------------------|
| `label` | Column header shown in the output table          |
| `id`    | Azure Subscription ID (GUID from the portal)     |

## Usage

### Option 1 — Azure CLI login (simplest)

```powershell
az login
python azure_cost_report.py --start 2025-03-01 --end 2026-03-31
```

### Option 2 — Service Principal

```powershell
python azure_cost_report.py `
  --start 2025-03-01 `
  --end   2026-03-31 `
  --tenant-id     "<TENANT_ID>" `
  --client-id     "<CLIENT_ID>" `
  --client-secret "<CLIENT_SECRET>"
```

### Arguments

| Argument          | Required | Description                                       |
|-------------------|----------|---------------------------------------------------|
| `--start`         | Yes      | First day of the range (YYYY-MM-DD)               |
| `--end`           | Yes      | Last day of the range  (YYYY-MM-DD)               |
| `--tenant-id`     | No       | Azure AD tenant ID (service principal)            |
| `--client-id`     | No       | Service principal application ID                  |
| `--client-secret` | No       | Service principal secret                          |
| `--mode`          | No       | `monthly` (default) or `breakdown`                |
| `--format`        | No       | `md` (default, stdout) or `html`                  |
| `--out`           | No       | Write the report to this file instead of stdout   |
| `--hide-zero`     | No       | Hide all-zero rows/columns (see below)            |

> If `--tenant-id`, `--client-id`, and `--client-secret` are all omitted, the script uses `DefaultAzureCredential` which tries Azure CLI, environment variables, managed identity, and more in order.

### `--hide-zero`

Removes data that rounds to `0.00`:

- **`breakdown`** — drops resource types at `0.00` and any resource group that nets to `0.00`.
- **`monthly`** — drops subscription columns that are `0.00` (or empty) across **every** month.

Grand totals are unaffected (only zero values are removed).

## Modes

### `monthly` (default) — month × subscription table

```powershell
python azure_cost_report.py --start 2025-03-01 --end 2026-03-31 --mode monthly
```

One row per month, one column per subscription, plus a Total column.

### `breakdown` — subscription → resource group → resource type

```powershell
python azure_cost_report.py --start 2026-03-01 --end 2026-03-31 --mode breakdown
```

A separate table per subscription. Rows are grouped by **resource group**
(bold, with subtotal) and broken down by **resource type** underneath, ending
with a per-subscription **Grand Total**. Uses the `CostUSD` metric, falling back
to `Cost` automatically for EA/MCA scopes that reject it.

## Output

Progress messages are written to **stderr**; the report is written to **stdout**
(or to `--out` when given).

Markdown to a file:

```powershell
python azure_cost_report.py --start 2025-03-01 --end 2026-03-31 --mode monthly > report.md
```

Elegant self-contained HTML report (no external assets — opens in any browser,
emails cleanly):

```powershell
# Monthly table
python azure_cost_report.py --start 2026-02-01 --end 2026-04-30   --mode monthly --format html --out monthly.html

# Resource-group / resource breakdown, zeros hidden
python azure_cost_report.py --start 2026-04-01 --end 2026-04-30   --mode breakdown --format html --out breakdown.html --hide-zero

# Resource-group monthly summary — Excel (summary sheet + one detail sheet per month)
python azure_cost_report.py --start 2026-01-01 --end 2026-05-31   --mode rg-monthly --format excel --out rg_monthly1.xlsx
```

### `monthly` example

```
| Month   | Dev-OPS | Pre-Prod | Prod  | DEV/QA | AIIA   | Total    |
|---------|---------|----------|-------|--------|--------|----------|
| 2025-03 |         |          |       |        |        |          |
| 2025-04 | 12.77   |          |       |        |        | 12.77    |
| 2025-05 | 36.39   |          |       |        |        | 36.39    |
```

- Cells are blank when a subscription had zero or no spend that month.
- **Total** sums all subscriptions that had any spend in that month.

### `breakdown` example

```
## Dev Test EA
<!-- subscription: 6b7e7dea-328b-4204-a9dd-de24d8cccbab -->

| Name                                     | Sum of CostUSD |
|------------------------------------------|---------------:|
| **adv-rg-aaia-dev**                      |         156.06 |
|     microsoft.cache/redis                |          16.37 |
|     microsoft.cognitiveservices/accounts |          50.90 |
|     microsoft.signalrservice/signalr     |          62.00 |
| **adv-rg-op-dev**                        |         118.92 |
|     microsoft.sql/servers                |          95.22 |
| **Grand Total**                          |         274.99 |
```

- Resource group rows are **bold** with their subtotal.
- Resource-type rows are indented beneath their resource group.
- Each subscription ends with its own **Grand Total**.

## Permissions

The identity used (user or service principal) needs the **Cost Management Reader** role assigned at the subscription scope for each subscription in the list.

```powershell
# Grant via Azure CLI
az role assignment create \
  --role "Cost Management Reader" \
  --assignee "<CLIENT_ID_or_USER_EMAIL>" \
  --scope "/subscriptions/<SUBSCRIPTION_ID>"
```

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError` | Run `pip install azure-mgmt-costmanagement azure-identity` |
| `AuthenticationError` | Run `az login` or verify service principal credentials |
| `WARNING: could not fetch ...` | Check the subscription ID is correct and the identity has Cost Management Reader |
| All costs are 0 / empty | Verify the date range contains actual spend; cost data can lag by 24–48 h |
