
### Azure Cost – Month on Month

| Month | Environment | Resource Group | Service Type | Cost (USD) |
|------|------------|----------------|--------------|------------|
| Apr 2026 | Dev/Test | adv-rg-aaia-dev | App Services | 25.92 |
| Apr 2026 | Dev/Test | adv-rg-aaia-dev | SignalR | 60.00 |
| Apr 2026 | Dev/Test | adv-rg-op-dev | SQL Server | 9.66 |
| Apr 2026 | Prod | adv-rg-op-prd | App Services | 51.12 |
| Apr 2026 | Prod | adv-rg-op-prd | SQL Server | 4.83 |
| Apr 2026 | Prod | adv-rg-op-shared | SQL Server | 4.83 |
| Apr 2026 | Total | - | - | 254.54 |



### Azure Cost Summary

| Month | Dev/Test (USD) | Prod (USD) | Total (USD) |
|------|---------------|-----------|-------------|
| Apr 2026 | 147.36 | 114.18 | 261.54 |
| Mar 2026 | 147.36 | 114.18 | 261.54 |


### Azure Cost Summary

| Month | adv-rg-aaia-dev (USD) | adv-rg-op-dev (USD) | adv-rg-op-prd (USD) | adv-rg-op-shared (USD) | Total (USD) |
|------|----------------------|---------------------|---------------------|------------------------|-------------|
| Apr 2026 | 85.92 | 9.66 | 55.95 | 4.83 | 156.36 |
| Mar 2026 | - | - | - | - | - |

