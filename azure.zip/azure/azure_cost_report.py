#!/usr/bin/env python3
"""
Azure Cost Report - fetches monthly costs per subscription and formats as a table.
"""

import argparse
import sys
import calendar
from datetime import datetime, date, time as dtime, timezone
from collections import defaultdict
import time
import random

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    _EXCEL_OK = True
except ImportError:
    _EXCEL_OK = False

try:
    from azure.identity import DefaultAzureCredential, ClientSecretCredential, AzureCliCredential
    from azure.mgmt.costmanagement import CostManagementClient
    from azure.mgmt.costmanagement.models import (
        QueryDefinition, QueryTimePeriod, QueryDataset,
        QueryAggregation, QueryGrouping, TimeframeType
    )
except ImportError:
    print("Missing dependencies. Run: pip install azure-mgmt-costmanagement azure-identity")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Configuration — edit subscriptions to match your environment
# ---------------------------------------------------------------------------
SUBSCRIPTIONS = [
    {"label": "Dev Test EA",     "id": "6b7e7dea-328b-4204-a9dd-de24d8cccbab"},
    {"label": "Dev Test RD",    "id": "418e5964-db56-4cbc-a19c-55c6288d583a"},
    {"label": "Prod",        "id": "9fe5f4d2-c6bb-4bb7-b14e-64eac32de703"},
    {"label": "hone",      "id": "16d6ebc7-ca31-4880-b7a2-e016c882d80a", "tenant": "6cdf7cdc-3055-418b-9bcb-d46455e6684b"},
    # {"label": "AIIA",        "id": "YOUR_SUBSCRIPTION_ID_5"},
    # {"label": "DEV/QA (2)",  "id": "YOUR_SUBSCRIPTION_ID_6"},
    # {"label": "AIIA (2)",    "id": "YOUR_SUBSCRIPTION_ID_7"},
    # {"label": "DEV/QA (3)",  "id": "YOUR_SUBSCRIPTION_ID_8"},
]
# ---------------------------------------------------------------------------


def get_credential(args):
    # Legacy signature kept for backward compatibility; prefer get_credential_for(args, tenant)
    if args.tenant_id and args.client_id and args.client_secret:
        return ClientSecretCredential(args.tenant_id, args.client_id, args.client_secret)
    return DefaultAzureCredential()


def get_credential_for(args, tenant: str | None = None):
    """Return a credential. If service principal args are supplied, use the provided tenant (or global)."""
    if args.client_id and args.client_secret:
        tid = tenant or args.tenant_id
        if not tid:
            print("Service principal credentials provided but no tenant ID available.", file=sys.stderr)
            print("Use --tenant-id or add 'tenant' to the subscription config.", file=sys.stderr)
            sys.exit(1)
        return ClientSecretCredential(tid, args.client_id, args.client_secret)
    # az login auth: if this subscription lives in another tenant, target it
    # explicitly via the Azure CLI (requires `az login --tenant <id>` once).
    if tenant:
        return AzureCliCredential(tenant_id=tenant)
    return DefaultAzureCredential()


def _run_query_with_retry(client, scope: str, query: QueryDefinition, subscription_id: str):
    """Execute a Cost Management query with 429 backoff and tenant-mismatch hints.

    Returns the SDK result object, or None on a non-retryable failure.
    """
    max_retries = 6
    attempt = 0
    while True:
        try:
            return client.query.usage(scope=scope, parameters=query)
        except Exception as exc:
            msg = str(exc)
            try:
                status = getattr(exc, "status_code", None) or getattr(getattr(exc, "response", None), "status_code", None)
            except Exception:
                status = None

            # Throttling
            if status == 429 or "Too many requests" in msg or "(429)" in msg:
                if attempt < max_retries:
                    wait = (2 ** attempt) + random.random()
                    print(f"    Throttled (429). Retrying in {wait:.1f}s...", file=sys.stderr)
                    time.sleep(wait)
                    attempt += 1
                    continue
                print(f"  ERROR: max retries reached for {subscription_id}", file=sys.stderr)
                return None

            # Tenant mismatch (common when using a token from a different tenant)
            if "InvalidAuthenticationTokenTenant" in msg or "wrong issuer" in msg or "must match the tenant" in msg:
                print(f"  AUTH ERROR: token tenant mismatch for {subscription_id}.", file=sys.stderr)
                print("  Hint: authenticate to the subscription's tenant, or provide a service principal", file=sys.stderr)
                print("  with the correct tenant via --tenant-id/--client-id/--client-secret, or add a", file=sys.stderr)
                print("  'tenant' field to the subscription entry in the script.", file=sys.stderr)
                return None

            print(f"  WARNING: could not fetch {subscription_id}: {exc}", file=sys.stderr)
            return None


def fetch_monthly_costs(credential, subscription_id: str, start: date, end: date) -> dict[str, float]:
    """Returns {YYYY-MM: cost} for the given subscription and date range.

    The function will retry on HTTP 429 throttling and surface helpful hints for
    tenant/token mismatch errors.
    """
    # Create a client per-credential so different subscriptions can use different tenants.
    client = CostManagementClient(credential)
    scope = f"/subscriptions/{subscription_id}"
    query = QueryDefinition(
        type="ActualCost",
        timeframe=TimeframeType.CUSTOM,
        time_period=QueryTimePeriod(
            from_property=datetime.combine(start, dtime.min, tzinfo=timezone.utc),
            to=datetime.combine(end, dtime.min, tzinfo=timezone.utc),
        ),
        dataset=QueryDataset(
            granularity="Monthly",
            aggregation={"totalCost": QueryAggregation(name="Cost", function="Sum")},
        ),
    )

    result = _run_query_with_retry(client, scope, query, subscription_id)
    if result is None:
        return {}

    monthly: dict[str, float] = {}
    # result.rows: list of [cost, currency, billingMonth] or similar columns
    # Map column names to indices
    col_names = [c.name for c in result.columns]
    cost_idx = next((i for i, c in enumerate(col_names) if c.lower() == "cost"), 0)
    date_idx = next((i for i, c in enumerate(col_names) if "billingmonth" in c.lower() or "usagedate" in c.lower()), -1)

    for row in result.rows:
        cost = float(row[cost_idx])
        if date_idx >= 0:
            raw_date = str(row[date_idx])
            # API returns YYYYMMDD or YYYY-MM-DD; normalise to YYYY-MM
            month_key = f"{raw_date[:4]}-{raw_date[4:6]}" if len(raw_date) == 8 else raw_date[:7]
        else:
            month_key = "unknown"
        monthly[month_key] = monthly.get(month_key, 0.0) + cost

    return monthly


def fetch_breakdown(credential, subscription_id: str, start: date, end: date,
                    cost_metric: str = "CostUSD") -> dict[str, dict[str, float]]:
    """Returns {resource_group: {resource_type: cost}} for the period.

    Grouped by ResourceGroupName then ResourceType, matching the
    subscription -> resource group -> resource layout.
    """
    client = CostManagementClient(credential)
    scope = f"/subscriptions/{subscription_id}"

    def build_query(metric: str) -> QueryDefinition:
        return QueryDefinition(
            type="ActualCost",
            timeframe=TimeframeType.CUSTOM,
            time_period=QueryTimePeriod(
                from_property=datetime.combine(start, datetime.min.time()),
                to=datetime.combine(end, datetime.min.time()),
            ),
            dataset=QueryDataset(
                granularity="None",
                aggregation={"totalCost": QueryAggregation(name=metric, function="Sum")},
                grouping=[
                    QueryGrouping(type="Dimension", name="ResourceGroupName"),
                    QueryGrouping(type="Dimension", name="ResourceType"),
                ],
            ),
        )

    result = _run_query_with_retry(client, scope, build_query(cost_metric), subscription_id)
    # Some EA/MCA scopes reject CostUSD; fall back to Cost.
    if result is None and cost_metric != "Cost":
        print(f"    Retrying {subscription_id} with 'Cost' metric...", file=sys.stderr)
        result = _run_query_with_retry(client, scope, build_query("Cost"), subscription_id)
    if result is None:
        return {}

    col_names = [c.name for c in result.columns]
    cost_idx = next((i for i, c in enumerate(col_names) if "cost" in c.lower()), 0)
    rg_idx = next((i for i, c in enumerate(col_names) if c.lower() == "resourcegroupname"), -1)
    rt_idx = next((i for i, c in enumerate(col_names) if c.lower() == "resourcetype"), -1)

    breakdown: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for row in result.rows:
        cost = float(row[cost_idx])
        rg = str(row[rg_idx]) if rg_idx >= 0 and row[rg_idx] else "(no resource group)"
        rt = str(row[rt_idx]) if rt_idx >= 0 and row[rt_idx] else "(unspecified)"
        breakdown[rg][rt] += cost

    return {rg: dict(types) for rg, types in breakdown.items()}


def print_breakdown(label: str, subscription_id: str,
                    breakdown: dict[str, dict[str, float]]):
    """Print a subscription -> resource group -> resource type table."""
    name_w = 52
    print()
    print(f"## {label}")
    print(f"<!-- subscription: {subscription_id} -->")
    print()
    print(f"| {'Name'.ljust(name_w)} | Sum of CostUSD |")
    print(f"|{'-' * (name_w + 2)}|---------------:|")

    grand_total = 0.0
    for rg in sorted(breakdown):
        types = breakdown[rg]
        rg_total = sum(types.values())
        grand_total += rg_total
        print(f"| **{rg.ljust(name_w - 4)}** | {rg_total:>14.2f} |")
        for rt in sorted(types):
            cost = types[rt]
            indented = ("    " + rt).ljust(name_w)
            print(f"| {indented} | {cost:>14.2f} |")

    print(f"| **{'Grand Total'.ljust(name_w - 4)}** | {grand_total:>14.2f} |")


def fetch_rg_monthly(credential, subscription_id: str, start: date, end: date,
                     cost_metric: str = "CostUSD") -> dict[str, dict[str, float]]:
    """Returns {resource_group: {YYYY-MM: cost}} for the period."""
    client = CostManagementClient(credential)
    scope = f"/subscriptions/{subscription_id}"

    def build_query(metric: str) -> QueryDefinition:
        return QueryDefinition(
            type="ActualCost",
            timeframe=TimeframeType.CUSTOM,
            time_period=QueryTimePeriod(
                from_property=datetime.combine(start, dtime.min, tzinfo=timezone.utc),
                to=datetime.combine(end, dtime.min, tzinfo=timezone.utc),
            ),
            dataset=QueryDataset(
                granularity="Monthly",
                aggregation={"totalCost": QueryAggregation(name=metric, function="Sum")},
                grouping=[
                    QueryGrouping(type="Dimension", name="ResourceGroupName"),
                ],
            ),
        )

    result = _run_query_with_retry(client, scope, build_query(cost_metric), subscription_id)
    if result is None and cost_metric != "Cost":
        print(f"    Retrying {subscription_id} with 'Cost' metric...", file=sys.stderr)
        result = _run_query_with_retry(client, scope, build_query("Cost"), subscription_id)
    if result is None:
        return {}

    col_names = [c.name for c in result.columns]
    cost_idx = next((i for i, c in enumerate(col_names) if "cost" in c.lower()), 0)
    rg_idx   = next((i for i, c in enumerate(col_names) if c.lower() == "resourcegroupname"), -1)
    date_idx = next((i for i, c in enumerate(col_names)
                     if "billingmonth" in c.lower() or "usagedate" in c.lower()), -1)

    data: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for row in result.rows:
        cost = float(row[cost_idx])
        rg   = str(row[rg_idx]) if rg_idx >= 0 and row[rg_idx] else "(no resource group)"
        if date_idx >= 0:
            raw = str(row[date_idx])
            month_key = f"{raw[:4]}-{raw[4:6]}" if len(raw) == 8 else raw[:7]
        else:
            month_key = "unknown"
        data[rg][month_key] += cost

    return {rg: dict(months) for rg, months in data.items()}


def filter_breakdown(bd: dict[str, dict[str, float]],
                     hide_zero: bool) -> dict[str, dict[str, float]]:
    """Drop resource types that round to 0.00 and resource groups that net to 0.00."""
    if not hide_zero:
        return bd
    filtered: dict[str, dict[str, float]] = {}
    for rg, types in bd.items():
        kept = {rt: c for rt, c in types.items() if round(c, 2) != 0.0}
        if kept and round(sum(kept.values()), 2) != 0.0:
            filtered[rg] = kept
    return filtered


def filter_monthly_labels(data: dict[str, dict[str, float]],
                          labels: list[str], hide_zero: bool) -> list[str]:
    """Drop subscription columns whose every month is missing or rounds to 0.00."""
    if not hide_zero:
        return labels
    kept = []
    for lbl in labels:
        vals = data.get(lbl, {})
        if any(v is not None and round(v, 2) != 0.0 for v in vals.values()):
            kept.append(lbl)
    return kept


def build_month_sequence(start: date, end: date) -> list[str]:
    months = []
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        months.append(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            m, y = 1, y + 1
    return months


def format_cell(value: float | None) -> str:
    if value is None:
        return ""
    return f"{value:.2f}"


def print_markdown_table(months: list[str], data: dict[str, dict[str, float]], labels: list[str]):
    col_w = [max(len(lbl), 8) for lbl in labels]
    month_w = 7

    def row_cells(month: str) -> list[str]:
        cells = []
        for lbl in labels:
            v = data[lbl].get(month)
            cells.append(format_cell(v))
        return cells

    def total_cell(month: str) -> str:
        total = sum(v for lbl in labels for v in [data[lbl].get(month)] if v is not None)
        has_any = any(data[lbl].get(month) is not None for lbl in labels)
        return format_cell(total) if has_any else ""

    # Header
    header = ["Month"] + labels + ["Total"]
    widths = [month_w] + col_w + [8]
    header_row = "| " + " | ".join(h.ljust(w) for h, w in zip(header, widths)) + " |"
    sep_row   = "|-" + "-|-".join("-" * w for w in widths) + "-|"
    print(header_row)
    print(sep_row)

    for month in months:
        cells = row_cells(month)
        tot   = total_cell(month)
        row_vals = [month] + cells + [tot]
        print("| " + " | ".join(v.ljust(w) for v, w in zip(row_vals, widths)) + " |")


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------
HTML_CSS = """
:root {
  --bg: #f4f6f8;
  --card: #ffffff;
  --ink: #1f2933;
  --muted: #66788a;
  --line: #e3e8ee;
  --accent: #0a6cff;
  --accent-soft: #eaf2ff;
  --group: #f0f4f9;
  --total: #0b3d6b;
  --zebra: #fbfcfd;
}
* { box-sizing: border-box; }
body {
  margin: 0; padding: 40px 20px;
  background: var(--bg); color: var(--ink);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-size: 14px; line-height: 1.5;
}
.wrap { max-width: 1100px; margin: 0 auto; }
header.report {
  background: linear-gradient(135deg, #0b3d6b 0%, #0a6cff 100%);
  color: #fff; border-radius: 14px; padding: 28px 32px;
  box-shadow: 0 10px 30px rgba(11,61,107,.18);
}
header.report h1 { margin: 0 0 6px; font-size: 22px; font-weight: 650; letter-spacing: .2px; }
header.report .meta { font-size: 13px; opacity: .85; }
header.report .meta span { margin-right: 22px; }
.card {
  background: var(--card); border: 1px solid var(--line);
  border-radius: 12px; margin-top: 24px; overflow: hidden;
  box-shadow: 0 1px 3px rgba(16,24,40,.04);
}
.card h2 {
  margin: 0; padding: 16px 22px; font-size: 15px; font-weight: 600;
  border-bottom: 1px solid var(--line); display: flex;
  justify-content: space-between; align-items: baseline; gap: 16px;
}
.card h2 .sub { font-size: 12px; font-weight: 400; color: var(--muted); }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 10px 16px; text-align: left; }
th { font-size: 11px; text-transform: uppercase; letter-spacing: .6px;
     color: var(--muted); background: var(--group); border-bottom: 1px solid var(--line); }
td { border-bottom: 1px solid var(--line); }
td.num, th.num { text-align: right; font-variant-numeric: tabular-nums;
                 font-feature-settings: "tnum"; white-space: nowrap; }
tbody tr:nth-child(even) { background: var(--zebra); }
tbody tr:hover { background: var(--accent-soft); }
tr.group td { font-weight: 650; background: var(--group); }
tr.group:hover td { background: var(--group); }
td.indent { padding-left: 36px; color: var(--muted); }
tr.total td, tfoot td {
  font-weight: 700; color: #fff; background: var(--total);
  border-bottom: none;
}
tr.total:hover td, tfoot tr:hover td { background: var(--total); }
.empty { color: #c2cdd6; }
footer.report { text-align: center; color: var(--muted);
                font-size: 12px; margin-top: 28px; }
"""


def _esc(s) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _money(v: float | None) -> str:
    if v is None:
        return '<span class="empty">&mdash;</span>'
    return f"{v:,.2f}"


def html_document(title: str, period: str, generated: str, body: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_esc(title)}</title>
<style>{HTML_CSS}</style>
</head>
<body>
<div class="wrap">
  <header class="report">
    <h1>{_esc(title)}</h1>
    <div class="meta">
      <span>Period: <strong>{_esc(period)}</strong></span>
      <span>Currency: <strong>USD</strong></span>
      <span>Generated: {_esc(generated)}</span>
    </div>
  </header>
{body}
  <footer class="report">Azure Cost Management &middot; figures in USD</footer>
</div>
</body>
</html>"""


def monthly_html(months: list[str], data: dict[str, dict[str, float]], labels: list[str]) -> str:
    head = "".join(f'<th class="num">{_esc(l)}</th>' for l in labels)
    rows = []
    col_totals = {l: 0.0 for l in labels}
    grand = 0.0
    for month in months:
        present = [data[l].get(month) for l in labels]
        has_any = any(v is not None for v in present)
        month_total = sum(v for v in present if v is not None)
        if has_any:
            grand += month_total
        cells = []
        for l in labels:
            v = data[l].get(month)
            if v is not None:
                col_totals[l] += v
            cells.append(f'<td class="num">{_money(v)}</td>')
        tot = _money(month_total) if has_any else '<span class="empty">&mdash;</span>'
        rows.append(f'<tr><td>{_esc(month)}</td>{"".join(cells)}'
                    f'<td class="num">{tot}</td></tr>')
    foot_cells = "".join(f'<td class="num">{_money(col_totals[l])}</td>' for l in labels)
    body_rows = "\n      ".join(rows)
    return f"""  <div class="card">
    <h2>Monthly Cost by Subscription</h2>
    <table>
      <thead><tr><th>Month</th>{head}<th class="num">Total</th></tr></thead>
      <tbody>
      {body_rows}
      </tbody>
      <tfoot><tr><td>Total</td>{foot_cells}<td class="num">{_money(grand)}</td></tr></tfoot>
    </table>
  </div>"""


def breakdown_html(results: list[dict]) -> str:
    cards = []
    for r in results:
        bd: dict[str, dict[str, float]] = r["breakdown"]
        rows = []
        grand = 0.0
        for rg in sorted(bd):
            types = bd[rg]
            rg_total = sum(types.values())
            grand += rg_total
            rows.append(f'<tr class="group"><td>{_esc(rg)}</td>'
                        f'<td class="num">{_money(rg_total)}</td></tr>')
            for rt in sorted(types):
                rows.append(f'<tr><td class="indent">{_esc(rt)}</td>'
                            f'<td class="num">{_money(types[rt])}</td></tr>')
        if not rows:
            rows.append('<tr><td colspan="2" class="empty">No cost data for this period</td></tr>')
        body_rows = "\n      ".join(rows)
        cards.append(f"""  <div class="card">
    <h2>{_esc(r["label"])}<span class="sub">{_esc(r["id"])}</span></h2>
    <table>
      <thead><tr><th>Resource group / type</th><th class="num">Sum of CostUSD</th></tr></thead>
      <tbody>
      {body_rows}
      </tbody>
      <tfoot><tr class="total"><td>Grand Total</td>
        <td class="num">{_money(grand)}</td></tr></tfoot>
    </table>
  </div>""")
    return "\n".join(cards)


# ---------------------------------------------------------------------------
# Excel rendering
# ---------------------------------------------------------------------------
_DARK_BLUE  = "0B3D6B"
_MID_BLUE   = "0A6CFF"
_LIGHT_BLUE = "EAF2FF"
_HEADER_FG  = "FFFFFF"
_GROUP_BG   = "F0F4F9"
_TOTAL_BG   = "0B3D6B"
_BORDER_CLR = "E3E8EE"


def _xl_border():
    s = Side(style="thin", color=_BORDER_CLR)
    return Border(left=s, right=s, top=s, bottom=s)


def _xl_header_style():
    return {
        "font":      Font(bold=True, color=_HEADER_FG, size=10),
        "fill":      PatternFill("solid", fgColor=_DARK_BLUE),
        "alignment": Alignment(horizontal="center", vertical="center", wrap_text=True),
        "border":    _xl_border(),
    }


def _xl_total_style():
    return {
        "font":      Font(bold=True, color=_HEADER_FG, size=10),
        "fill":      PatternFill("solid", fgColor=_TOTAL_BG),
        "alignment": Alignment(horizontal="right"),
        "border":    _xl_border(),
    }


def _apply(cell, **styles):
    for k, v in styles.items():
        setattr(cell, k, v)


def _add_month_detail_sheet(wb, month: str,
                             sub_data: dict[str, dict[str, dict[str, float]]],
                             hide_zero: bool):
    """Add one sheet for a month: subscription → resource group → resource type."""
    hdr = _xl_header_style()
    tot = _xl_total_style()
    num_fmt = "#,##0.00"

    label = datetime.strptime(month, "%Y-%m").strftime("%b %Y")
    ws = wb.create_sheet(title=label)

    # Title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
    tc = ws.cell(row=1, column=1, value=f"Cost Detail  |  {label}")
    _apply(tc, font=Font(bold=True, color=_HEADER_FG, size=12),
           fill=PatternFill("solid", fgColor=_MID_BLUE),
           alignment=Alignment(horizontal="center", vertical="center"))
    ws.row_dimensions[1].height = 24

    # Column headers
    for col, val in [(1, "Subscription / Resource Group / Resource"), (2, "Cost (USD)")]:
        c = ws.cell(row=2, column=col, value=val)
        _apply(c, **hdr)
    ws.row_dimensions[2].height = 20

    ri = 3
    grand = 0.0
    for sub_label in sorted(sub_data):
        bd = sub_data[sub_label]
        if hide_zero:
            bd = filter_breakdown(bd, hide_zero=True)
        if not bd:
            continue

        sub_total = sum(sum(types.values()) for types in bd.values())
        if hide_zero and round(sub_total, 2) == 0.0:
            continue
        grand += sub_total

        # Subscription header row
        sc = ws.cell(row=ri, column=1, value=sub_label)
        _apply(sc, font=Font(bold=True, color=_HEADER_FG, size=10),
               fill=PatternFill("solid", fgColor=_DARK_BLUE), border=_xl_border())
        sv = ws.cell(row=ri, column=2, value=round(sub_total, 2))
        sv.number_format = num_fmt
        _apply(sv, font=Font(bold=True, color=_HEADER_FG, size=10),
               fill=PatternFill("solid", fgColor=_DARK_BLUE),
               alignment=Alignment(horizontal="right"), border=_xl_border())
        ri += 1

        for rg in sorted(bd):
            rg_total = sum(bd[rg].values())
            if hide_zero and round(rg_total, 2) == 0.0:
                continue

            # Resource group row
            rc = ws.cell(row=ri, column=1, value=f"  {rg}")
            _apply(rc, font=Font(bold=True, size=10),
                   fill=PatternFill("solid", fgColor=_GROUP_BG), border=_xl_border())
            rv = ws.cell(row=ri, column=2, value=round(rg_total, 2))
            rv.number_format = num_fmt
            _apply(rv, font=Font(bold=True, size=10),
                   fill=PatternFill("solid", fgColor=_GROUP_BG),
                   alignment=Alignment(horizontal="right"), border=_xl_border())
            ri += 1

            for rt in sorted(bd[rg]):
                cost = bd[rg][rt]
                if hide_zero and round(cost, 2) == 0.0:
                    continue
                rtc = ws.cell(row=ri, column=1, value=f"      {rt}")
                _apply(rtc, border=_xl_border())
                rtv = ws.cell(row=ri, column=2, value=round(cost, 2))
                rtv.number_format = num_fmt
                _apply(rtv, alignment=Alignment(horizontal="right"), border=_xl_border())
                ri += 1

    # Grand total
    gc = ws.cell(row=ri, column=1, value="Grand Total")
    _apply(gc, **tot)
    gv = ws.cell(row=ri, column=2, value=round(grand, 2))
    gv.number_format = num_fmt
    _apply(gv, **tot)

    ws.column_dimensions["A"].width = 58
    ws.column_dimensions["B"].width = 16
    ws.freeze_panes = "A3"


def write_excel_rg_monthly(months: list[str],
                            rg_data: dict[str, dict[str, float]],
                            rg_names: list[str],
                            out_path: str,
                            period: str,
                            sub_names: list[str] | None = None,
                            monthly_detail: dict | None = None,
                            hide_zero: bool = False,
                            rg_to_sub: dict[str, str] | None = None):
    """Write a months × resource-group summary sheet plus per-month detail sheets."""
    if not _EXCEL_OK:
        print("ERROR: openpyxl not installed. Run: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Summary"

    hdr = _xl_header_style()
    tot = _xl_total_style()
    num_fmt = "#,##0.00"
    total_col = len(rg_names) + 2

    # Row 1: Title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_col)
    title_cell = ws.cell(row=1, column=1, value=f"Azure Cost by Resource Group  |  {period}")
    _apply(title_cell,
           font=Font(bold=True, color=_HEADER_FG, size=12),
           fill=PatternFill("solid", fgColor=_MID_BLUE),
           alignment=Alignment(horizontal="center", vertical="center"))
    ws.row_dimensions[1].height = 24

    # Row 2: Subscription grouped headers (merged cells spanning their RG columns).
    # "Month" and "Total" cells in row 2 are merged with row 3 so they span both rows.
    if rg_to_sub:
        # Merge Month label across rows 2-3
        ws.merge_cells(start_row=2, start_column=1, end_row=3, end_column=1)
        _apply(ws.cell(row=2, column=1, value="Month"), **hdr)

        # Build contiguous groups: [(sub_label, start_ci, end_ci), ...]
        groups: list[list] = []
        for ci, rg in enumerate(rg_names, start=2):
            sub = rg_to_sub.get(rg, "(unknown)")
            if groups and groups[-1][0] == sub:
                groups[-1][2] = ci
            else:
                groups.append([sub, ci, ci])

        # Alternating colours so adjacent subscriptions are visually distinct
        sub_colours = ["1A5276", "1F618D", "2471A3", "2980B9"]
        for gi, (sub_lbl, sc_ci, ec_ci) in enumerate(groups):
            colour = sub_colours[gi % len(sub_colours)]
            if sc_ci != ec_ci:
                ws.merge_cells(start_row=2, start_column=sc_ci, end_row=2, end_column=ec_ci)
            c = ws.cell(row=2, column=sc_ci, value=sub_lbl)
            _apply(c, font=Font(bold=True, color=_HEADER_FG, size=10),
                   fill=PatternFill("solid", fgColor=colour),
                   alignment=Alignment(horizontal="center", vertical="center"))

        # Merge Total label across rows 2-3
        ws.merge_cells(start_row=2, start_column=total_col, end_row=3, end_column=total_col)
        _apply(ws.cell(row=2, column=total_col, value="Total (USD)"), **hdr)

        ws.row_dimensions[2].height = 18

        # Row 3: RG names only (Month and Total already set above)
        for ci, rg in enumerate(rg_names, start=2):
            c = ws.cell(row=3, column=ci, value=rg)
            _apply(c, **hdr)
        ws.row_dimensions[3].height = 32
    else:
        # Fallback: flat subscription list in row 2, RG headers in row 3
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=total_col)
        sub_text = "Subscriptions: " + ", ".join(sub_names) if sub_names else ""
        sc = ws.cell(row=2, column=1, value=sub_text)
        _apply(sc, font=Font(italic=True, color="FFFFFF", size=10),
               fill=PatternFill("solid", fgColor="1A5276"),
               alignment=Alignment(horizontal="left", vertical="center", indent=1))
        ws.row_dimensions[2].height = 18

        ws.cell(row=3, column=1, value="Month")
        _apply(ws.cell(row=3, column=1), **hdr)
        for ci, rg in enumerate(rg_names, start=2):
            c = ws.cell(row=3, column=ci, value=rg)
            _apply(c, **hdr)
        tc = ws.cell(row=3, column=total_col, value="Total (USD)")
        _apply(tc, **hdr)
        ws.row_dimensions[3].height = 32

    # Data rows start at row 4
    for ri, month in enumerate(months, start=4):
        zebra_bg = "FBFCFD" if ri % 2 == 0 else "FFFFFF"
        mc = ws.cell(row=ri, column=1, value=month)
        _apply(mc, font=Font(size=10), fill=PatternFill("solid", fgColor=zebra_bg),
               border=_xl_border())

        row_total = 0.0
        for ci, rg in enumerate(rg_names, start=2):
            v = rg_data.get(rg, {}).get(month)
            cell = ws.cell(row=ri, column=ci, value=round(v, 2) if v is not None else None)
            cell.number_format = num_fmt
            _apply(cell, fill=PatternFill("solid", fgColor=zebra_bg),
                   alignment=Alignment(horizontal="right"), border=_xl_border())
            if v is not None:
                row_total += v

        tc = ws.cell(row=ri, column=total_col, value=round(row_total, 2))
        tc.number_format = num_fmt
        _apply(tc, font=Font(bold=True, size=10),
               fill=PatternFill("solid", fgColor=zebra_bg),
               alignment=Alignment(horizontal="right"), border=_xl_border())

    # Grand total row
    gr = len(months) + 4
    gc = ws.cell(row=gr, column=1, value="Grand Total")
    _apply(gc, **tot)
    grand = 0.0
    for ci, rg in enumerate(rg_names, start=2):
        col_total = sum(v for m in months for v in [rg_data.get(rg, {}).get(m)] if v is not None)
        grand += col_total
        c = ws.cell(row=gr, column=ci, value=round(col_total, 2))
        c.number_format = num_fmt
        _apply(c, **tot)
    gtc = ws.cell(row=gr, column=total_col, value=round(grand, 2))
    gtc.number_format = num_fmt
    _apply(gtc, **tot)

    # Column widths
    ws.column_dimensions[get_column_letter(1)].width = 12
    for ci in range(2, total_col + 1):
        ws.column_dimensions[get_column_letter(ci)].width = max(
            18, len(rg_names[ci - 2]) + 2 if ci <= len(rg_names) + 1 else 14
        )
    ws.freeze_panes = "B4"

    # Per-month detail sheets
    if monthly_detail:
        for month in months:
            _add_month_detail_sheet(wb, month, monthly_detail.get(month, {}), hide_zero)

    wb.save(out_path)
    print(f"Excel report written to {out_path}", file=sys.stderr)


def write_excel_breakdown(results: list[dict], out_path: str, period: str):
    """Write a per-subscription breakdown Excel workbook (one sheet per subscription)."""
    if not _EXCEL_OK:
        print("ERROR: openpyxl not installed. Run: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    hdr = _xl_header_style()
    tot = _xl_total_style()
    num_fmt = "#,##0.00"

    for r in results:
        label: str = r["label"]
        bd: dict[str, dict[str, float]] = r["breakdown"]
        ws = wb.create_sheet(title=label[:31])

        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
        tc = ws.cell(row=1, column=1, value=f"{label}  |  {period}")
        _apply(tc, font=Font(bold=True, color=_HEADER_FG, size=12),
               fill=PatternFill("solid", fgColor=_MID_BLUE),
               alignment=Alignment(horizontal="center", vertical="center"))
        ws.row_dimensions[1].height = 24

        for col, hval in enumerate(["Resource Group / Type", "Cost (USD)"], start=1):
            c = ws.cell(row=2, column=col, value=hval)
            _apply(c, **hdr)
        ws.row_dimensions[2].height = 20

        ri = 3
        grand = 0.0
        for rg in sorted(bd):
            rg_total = sum(bd[rg].values())
            grand += rg_total
            rg_cell = ws.cell(row=ri, column=1, value=rg)
            _apply(rg_cell, font=Font(bold=True, size=10),
                   fill=PatternFill("solid", fgColor=_GROUP_BG),
                   border=_xl_border())
            cv = ws.cell(row=ri, column=2, value=round(rg_total, 2))
            cv.number_format = num_fmt
            _apply(cv, font=Font(bold=True, size=10),
                   fill=PatternFill("solid", fgColor=_GROUP_BG),
                   alignment=Alignment(horizontal="right"), border=_xl_border())
            ri += 1
            for rt in sorted(bd[rg]):
                rc = ws.cell(row=ri, column=1, value=f"    {rt}")
                _apply(rc, border=_xl_border())
                vc = ws.cell(row=ri, column=2, value=round(bd[rg][rt], 2))
                vc.number_format = num_fmt
                _apply(vc, alignment=Alignment(horizontal="right"), border=_xl_border())
                ri += 1

        gc = ws.cell(row=ri, column=1, value="Grand Total")
        _apply(gc, **tot)
        gvc = ws.cell(row=ri, column=2, value=round(grand, 2))
        gvc.number_format = num_fmt
        _apply(gvc, **tot)

        ws.column_dimensions["A"].width = 55
        ws.column_dimensions["B"].width = 16
        ws.freeze_panes = "A3"

    wb.save(out_path)
    print(f"Excel report written to {out_path}", file=sys.stderr)


def write_output(text: str, out_path: str | None):
    if out_path:
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(text)
        print(f"Report written to {out_path}", file=sys.stderr)
    else:
        print(text)


def main():
    parser = argparse.ArgumentParser(description="Azure monthly cost report")
    parser.add_argument("--start", required=True, help="Start date YYYY-MM-DD (first day of month)")
    parser.add_argument("--end",   required=True, help="End date   YYYY-MM-DD (last day of month)")
    parser.add_argument("--tenant-id",     default=None, help="Azure tenant ID (for service principal auth)")
    parser.add_argument("--client-id",     default=None, help="Service principal client ID")
    parser.add_argument("--client-secret", default=None, help="Service principal client secret")
    parser.add_argument("--mode", choices=["monthly", "breakdown", "rg-monthly"], default="monthly",
                        help="monthly: month x subscription table; "
                             "breakdown: subscription -> resource group -> resource type; "
                             "rg-monthly: month x resource-group table (excel recommended)")
    parser.add_argument("--format", choices=["md", "html", "excel"], default="md",
                        help="md: Markdown to stdout (default); html: HTML report; "
                             "excel: Excel workbook (requires openpyxl)")
    parser.add_argument("--out", default=None,
                        help="Write report to this file instead of stdout")
    parser.add_argument("--hide-zero", action="store_true",
                        help="Hide all-zero data: breakdown drops 0.00 resource "
                             "types and resource groups; monthly drops subscription "
                             "columns that are 0.00 across every month")
    args = parser.parse_args()

    start = date.fromisoformat(args.start)
    end   = date.fromisoformat(args.end)

    period = f"{start.isoformat()} to {end.isoformat()}"
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    print(f"Fetching Azure costs ({args.mode}) from {start} to {end}...", file=sys.stderr)

    if args.mode == "breakdown":
        results = []
        for sub in SUBSCRIPTIONS:
            print(f"  Querying: {sub['label']} ({sub['id']})...", file=sys.stderr)
            cred = get_credential_for(args, tenant=sub.get("tenant"))
            breakdown = fetch_breakdown(cred, sub["id"], start, end)
            breakdown = filter_breakdown(breakdown, args.hide_zero)
            results.append({"label": sub["label"], "id": sub["id"], "breakdown": breakdown})
            time.sleep(1.0 + random.random() * 0.5)

        if args.format == "html":
            html = html_document("Azure Cost Breakdown", period, generated,
                                 breakdown_html(results))
            write_output(html, args.out)
        elif args.format == "excel":
            out = args.out or "breakdown.xlsx"
            write_excel_breakdown(results, out, period)
        else:
            for r in results:
                print_breakdown(r["label"], r["id"], r["breakdown"])
        return

    if args.mode == "rg-monthly":
        months = build_month_sequence(start, end)

        # Fetch per-month, per-subscription breakdown (RG + resource type).
        # From this we derive both the summary RG data and the detail sheets.
        monthly_detail: dict[str, dict[str, dict[str, dict[str, float]]]] = {}
        rg_data: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))

        for month in months:
            m_year, m_mon = int(month[:4]), int(month[5:7])
            m_start = date(m_year, m_mon, 1)
            m_end   = date(m_year, m_mon, calendar.monthrange(m_year, m_mon)[1])
            monthly_detail[month] = {}
            for sub in SUBSCRIPTIONS:
                print(f"  Querying {sub['label']} for {month}...", file=sys.stderr)
                cred = get_credential_for(args, tenant=sub.get("tenant"))
                bd = fetch_breakdown(cred, sub["id"], m_start, m_end)
                monthly_detail[month][sub["label"]] = bd
                for rg, types in bd.items():
                    rg_data[rg][month] += sum(types.values())
                time.sleep(1.0 + random.random() * 0.5)

        # Build rg_to_sub: assign each RG to the subscription with the highest total cost for it
        rg_to_sub: dict[str, str] = {}
        rg_sub_totals: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
        for month_data in monthly_detail.values():
            for sub_label, bd in month_data.items():
                for rg, types in bd.items():
                    rg_sub_totals[rg][sub_label] += sum(types.values())
        for rg, sub_costs in rg_sub_totals.items():
            rg_to_sub[rg] = max(sub_costs, key=sub_costs.__getitem__)

        sub_names = [s["label"] for s in SUBSCRIPTIONS]

        # Sort RGs grouped by subscription (preserving subscription order from config)
        sub_order = {s["label"]: i for i, s in enumerate(SUBSCRIPTIONS)}
        rg_names = sorted(
            rg_data.keys(),
            key=lambda rg: (sub_order.get(rg_to_sub.get(rg, ""), 999), rg)
        )
        if args.hide_zero:
            rg_names = [rg for rg in rg_names
                        if any(round(rg_data[rg].get(m, 0), 2) != 0.0 for m in months)]

        if args.format == "excel":
            out = args.out or "rg_monthly.xlsx"
            write_excel_rg_monthly(months, dict(rg_data), rg_names, out, period,
                                   sub_names=sub_names,
                                   monthly_detail=monthly_detail,
                                   hide_zero=True,
                                   rg_to_sub=rg_to_sub)
        else:
            md_data = {rg: rg_data[rg] for rg in rg_names}
            print()
            print_markdown_table(months, md_data, rg_names)
        return

    data: dict[str, dict[str, float]] = {}
    labels = [s["label"] for s in SUBSCRIPTIONS]

    for sub in SUBSCRIPTIONS:
        print(f"  Querying: {sub['label']} ({sub['id']})...", file=sys.stderr)
        # Allow per-subscription tenant override: add "tenant" to subscription dict if needed.
        sub_tenant = sub.get("tenant")
        cred = get_credential_for(args, tenant=sub_tenant)
        data[sub["label"]] = fetch_monthly_costs(cred, sub["id"], start, end)
        # Small pause between queries to reduce risk of throttling
        time.sleep(1.0 + random.random() * 0.5)

    months = build_month_sequence(start, end)
    labels = filter_monthly_labels(data, labels, args.hide_zero)

    if args.format == "html":
        html = html_document("Azure Monthly Cost Report", period, generated,
                             monthly_html(months, data, labels))
        write_output(html, args.out)
    elif args.format == "excel":
        # Wrap monthly data as breakdown-style for Excel (one sheet per subscription)
        results = [{"label": lbl, "id": next(s["id"] for s in SUBSCRIPTIONS if s["label"] == lbl),
                    "breakdown": {"(monthly total)": {m: data[lbl][m]
                                                      for m in months if m in data[lbl]}}}
                   for lbl in labels]
        out = args.out or "monthly.xlsx"
        write_excel_breakdown(results, out, period)
    else:
        print()
        print_markdown_table(months, data, labels)


if __name__ == "__main__":
    main()
