import React, { useState, useEffect } from "react";
import styles from "./InsertRecord.module.css";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import FormLabel from "@mui/material/FormLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import IconButton from "@mui/material/IconButton";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import Button from "@mui/material/Button";
import FormControl from "@mui/material/FormControl";
import { useFormik } from "formik";
import * as yup from "yup";
import axios from "axios";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 600,
  bgcolor: "background.paper",
  boxShadow: 25,
};

const validationSchema = yup.object({
  UnlocCode: yup
    .string()
    .min(1, "Enter a valid UnlocCode")
    .max(3, "Maximum characters 3")
    .required("UnlocCode is required"),

  UnlocName: yup
    .string()
    .min(1, "Enter a valid Location Name")
    .required("Location Name is required"),
});

function InsertRecord(props) {
  // console.log("ModalData.rowData.SeaPort:", ModalData.rowData.SeaPort);{ ModalData, onClose }
  let formik = useFormik({
    initialValues: {
      Country: props.ModalData.rowData ? props.ModalData.rowData.CountryC : "",
      UnlocCode: props.ModalData.rowData
        ? props.ModalData.rowData.UnlocCode
        : "",
      UnlocName: props.ModalData.rowData
        ? props.ModalData.rowData.UnlocName
        : "",
      SeaPort: props.ModalData.rowData ? props.ModalData.rowData.SeaPort : "",
      AirPort: props.ModalData.rowData ? props.ModalData.rowData.AirPort : "",
      Active: props.ModalData.rowData ? props.ModalData.rowData.Active : "",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      sendData(values);
      handleClose();
      // onClick={handleClose}
      // console.log("Form data submitted:", values);
      // formik.setFieldValue("SeaPort", false);
      // formik.setFieldValue("AirPort", false);
      // formik.setFieldValue("Active", false);
      // setSelectedCountry("");
      // formik.setFieldValue("CountryName", "");

      // formik.resetForm();
    },
  });

  // This is for the select option
  const [selectedCountry, setSelectedCountry] = useState("");
  // const [options, setoptions] = useState([]);

  const handleSelectChange = (e) => {
    const selectedOption = e.target.value;
    formik.setFieldValue("CountryName", selectedOption);
    const selectedCountry = props.CountryData.find(
      (option) => option.CountryN === selectedOption
    );

    setSelectedCountry(selectedCountry.Country);
  };

  const handleClose = () => {
    props.onClose(false);
  };

  //The Api for the country select option
  // useEffect(() => {
  //   axios
  //     .get("https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Country")
  //     .then((res) => {
  //       // console.log(res);
  //       const data = res.data.ReturnValue.CountryUi || [];
  //       setoptions(data);
  //       // console.log(data);
  //     })
  //     .catch((error) => {
  //       console.error("Error fetching data:", error);
  //     });
  // }, []);

  // The Api to send data
  const sendData = async (data) => {
    data.Country = selectedCountry;
    // console.log(selectedCountry);
    try {
      await axios.post(
        "https://edoc-uat.advantis.lk/FFApi/Masters/Save_Location",
        data
      );
      // console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <Modal
        open={props.ModalData.isDisplayModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <form onSubmit={formik.handleSubmit}>
          <Box sx={style} color="error.contrastText" p={1}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className={styles.row0}>
                <p className={styles.heading}>
                  {props.ModalData.isNewMode === false
                    ? "Edit Location Data"
                    : "Add New Location"}
                </p>

                <div className={styles.icon}>
                  <IconButton onClick={handleClose} sx={{ marginLeft: "100" }}>
                    <CancelIcon sx={{ color: "white" }} />
                  </IconButton>
                </div>
              </div>

              <div className={styles.row1}>
                <div className={styles.col1}>
                  <FormLabel>Country : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="CountryC"
                    name="CountryC"
                    label="Code"
                    variant="standard"
                    size="small"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={selectedCountry}
                    sx={{ width: "130px", marginRight: "10px", marginTop: -1 }}
                  />

                  <FormControl variant="standard">
                    {/* <InputLabel
                      id="demo-simple-select-required-label"
                      sx={{
                        marginTop: selectedCountry ? "-10px" : "0",
                        transition: "margin 0.2s",
                      }}>
                      Country
                    </InputLabel> */}
                    <Select
                      id="demo-simple-select-required"
                      name="CountryName"
                      placeholder="Select Country Name"
                      variant="standard"
                      size="small"
                      sx={{ height: "30px", width: "190px", marginTop: "8px" }}
                      value={formik.values.CountryName}
                      onBlur={formik.handleBlur}
                      onChange={handleSelectChange}
                    >
                      {/* <MenuItem value="">Select Country Name</MenuItem> */}
                      {props.CountryData.map((option, index) => (
                        <MenuItem key={index} value={option.CountryN}>
                          {option.CountryN}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </div>
              </div>

              <div className={styles.row2}>
                <div className={styles.col1}>
                  <FormLabel>UN Loc Code / Name : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="filled-basic"
                    name="UnlocCode"
                    variant="standard"
                    label="UN Loc Code"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.UnlocCode}
                    sx={{ width: "130px", marginRight: "10px" }}
                    error={
                      formik.touched.UnlocCode &&
                      Boolean(formik.errors.UnlocCode)
                    }
                    helperText={
                      formik.touched.UnlocCode && formik.errors.UnlocCode
                    }
                  />

                  <TextField
                    id="filled-basic"
                    name="UnlocName"
                    variant="standard"
                    label="Location Name"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.UnlocName}
                    sx={{ width: "200px", marginRight: "5px" }}
                    error={
                      formik.touched.UnlocName &&
                      Boolean(formik.errors.UnlocName)
                    }
                    helperText={
                      formik.touched.UnlocName && formik.errors.UnlocName
                    }
                  />
                </div>
              </div>

              <div className={styles.row3}>
                <div className={styles.col2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="SeaPort"
                        onChange={(e) => {
                          formik.setFieldValue(
                            "SeaPort",
                            e.target.checked ? "Y" : ""
                          );
                        }}
                        checked={formik.values.SeaPort === "Y"}
                      />
                    }
                    label="Sea Port"
                    value="Y"
                    sx={{ color: "gray", marginRight: 4.5 }}
                  />

                  <FormControlLabel
                    control={
                      <Checkbox
                        name="AirPort"
                        onChange={(e) => {
                          if (e.target.checked) {
                            formik.setFieldValue("AirPort", "Y");
                          }
                        }}
                      />
                    }
                    label="Air Port"
                    sx={{ color: "gray" }}
                  />
                </div>
              </div>

              <div className={styles.row4}>
                <div className={styles.col2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="Active"
                        onChange={(e) => {
                          if (e.target.checked) {
                            formik.setFieldValue("Active", "Y");
                          }
                        }}
                      />
                    }
                    label="Active"
                    sx={{ color: "gray", marginLeft: -2, marginRight: 4.5 }}
                  />

                  <Button
                    variant="contained"
                    color="success"
                    fontSize="medium"
                    type="submit"
                    startIcon={<SaveIcon />}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </Typography>
          </Box>
        </form>
      </Modal>
    </div>
  );
}

export default InsertRecord;
