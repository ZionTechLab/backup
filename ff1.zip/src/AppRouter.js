// Routes.js
import React from "react";
import Drawer from "./Components/Drawer/index.js";
import Spinner from "./Components/Spinner/Spinner.js";
import { useSelector } from "react-redux";
import Location from "./Pages/Locations/Location.js";
import Commodity from "./Pages/Commodity/Commodity.js";
import Vessel from "./Pages/Vessels/Vessel.js";
import Package from "./Pages/Packs/Package.js";
import { BrowserRouter as Router, Route, Link, Routes } from "react-router-dom";
// import "./styles.css";
const AppRouter = () => {
  const authData = useSelector((state) => state.auth);

  return (
    <Router>
      {/* <div className="aa">
        <Drawer />{" "}
        {(() => {
          switch (authData.ActiveForm) {
            case "/":
              return "Welcome";
            case "Admin":
              return <Link to="Admin">Admina</Link>;
            // return "admin";
            case "Inventory":
              return "item";
            case "Outstanding":
              return "customers";
            case "Location":
              return "Location";
            case "Commodity":
              return <Commodity />;
            case "Packages":
              return <Package />;
            case "Vessel":
              return <Vessel />;
            case "Vessel2":
              return "hiii";
            case "dd":
              return "eeee";
            default:
              return "404";
          }
        })()}
      </div> */}

      <div>
        <div class="drawer" id="drawer">
          <a
            href="javascript:void(0)"
            class="close-btn"
            onclick="closeDrawer()"
          >
            &times;
          </a>

          <ul class="tree">
            <li>
              <details open>
                <summary class="l1">Giant planets</summary>
                <ul>
                  <li>
                    <details open>
                      <summary class="l2">Gas giants</summary>
                      <ul>
                        <a href="ew" onclick="closeDrawer()">
                          Jupiter
                        </a>
                        <a href="ew" onclick="closeDrawer()">
                          Saturn
                        </a>
                      </ul>
                    </details>
                  </li>
                  <li>
                    <details open>
                      <summary class="l2">Ice giants</summary>
                      <ul>
                        <a href="ew" onclick="closeDrawer()">
                          Home
                        </a>
                        <a href="ew" onclick="closeDrawer()">
                          Neptune
                        </a>
                      </ul>
                    </details>
                  </li>
                </ul>
              </details>
            </li>
            <a href="aaa" onclick="closeDrawer()">
              Neptune
            </a>
          </ul>
        </div>
        {/* <ul>
          <li>
            <a href="ew" onclick="closeDrawer()">
              Jupiter
            </a>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="Admin">Admin</Link>
          </li>
          <li>
            <Link to="Location">Location</Link>
          </li>
          <li>
            <Link to="page2">Page 2</Link>
          </li>
          <li>
            <Link to="page3">Page 3</Link>nn
          </li>
        </ul> */}
      </div>
      <Routes>
        <Route exact path="/" element={<h1>Welcome</h1>} />{" "}
        <Route exact path="Admin" element={<h1>Admin</h1>} />
        <Route exact path="Location" element={<Location />} />
        {/* <Route exact path="page2" element={<Page2 />} />
        <Route exact path="page3" element={<Page3 />} /> */}
        <Route exact path="/*" element={<h1>not found</h1>} />
      </Routes>
    </Router>
    // <div className="aa">
    //   <Drawer />

    //   {(() => {
    //     switch (authData.ActiveForm) {
    //       case "Home":
    //         return "Welcome";
    //       case "Admin":
    //         return "admin";
    //       case "Inventory":
    //         return "item";
    //       case "Outstanding":
    //         return "customers";
    //       case "Location":
    //         return <Location />;
    //       case "Commodity":
    //         return <Commodity />;
    //       case "Packages":
    //         return <Package />;
    //       case "Vessel":
    //         return <Vessel />;
    //       case "Vessel2":
    //         return "hiii";
    //       default:
    //         return "404";
    //     }
    //   })()}
    // </div>
  );
};

export default AppRouter;
