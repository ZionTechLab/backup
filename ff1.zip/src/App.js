import "./App.css";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import AppBar from "./Components/AppBar";
import LoadingPage from "./Components/Login/LoadingPage";

function App() {
  const dispatch = useDispatch();
  const authData = useSelector((state) => state);
  const aa = useSelector((state) => state);

  let contains = <AppBar />;

  // contains = <LoadingPage />;
  return <div>{contains}</div>;
}

export default App;
