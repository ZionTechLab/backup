import axios from 'axios';

export const fetchPackageData = async () => {
    const response = await axios.get(
        "https://edoc-uat.advantis.lk/FFApi/Masters/getUI_PackTypes"    
    );
    return response;
};