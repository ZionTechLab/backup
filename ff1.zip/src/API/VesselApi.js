import axios from 'axios';

export const fetchProviderData = async () => {
    const response = await axios.get(
        "https://edoc-uat.advantis.lk/FFApi/Masters/getUI_VesselData"    
    );
    return response;
};

export const fetchVesselData = async () => {
    const response = await axios.get(
        "https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Vessels"    
    );
    return response;
};