import axios from 'axios';

export const fetchCommodityData = async () => {
        const response = await axios.get(
            //"https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Commodity"
            "http://localhost:3000/api/commodity/commodityData"
        );
       // console.log(response);
        return response;
        
};