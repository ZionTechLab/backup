import axios from 'axios';

export const fetchCountryData = async () => {
    // try {
        const response1 = await axios.get(
        "https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Country"
        );
        return response1;
    // } catch (error) {
    //     throw new Error(error.message);
    // }
};

export const fetchLocationData = async () => {
    // try {
        const response = await axios.get(
            "https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Location"
        );
        return response;
    // } catch (error) {
    //     throw new Error(error.message);
    // }
};