import { configureStore } from "@reduxjs/toolkit";
import { songsReducer, addSong, removeSong } from "./slices/songsSlice";
import { sakeReducer, addSake, removeSake } from "./slices/sakeSlice";
import {
  authReducer,
  setAuthStatus,
  loggin,
  init,
  setActiveForm,
} from "./slices/authSlice";
import { inventoryReducer, getInventory } from "./slices/inventorySlice";
import { counterReducer, incrementAsync } from "./slices/mastersSlice";
import { dataReducer, getLocations, saveLocations } from "./slices/dataSlice";
import { getCommodity,commodityReducer, saveCommodity } from "./slices/commoditySlice";
import { packsReducer, getPackages,savePackages } from "./slices/packsSlice";
import { vesselReducer, getVessels,saveVessels } from "./slices/vesselSlice";
import { reset } from "./actions";

const store = configureStore({
  reducer: {
    songs: songsReducer,
    sake: sakeReducer,
    auth: authReducer,
    inventory: inventoryReducer,
    counter: counterReducer,
    data: dataReducer,
    commodity:commodityReducer,
    packs:packsReducer,
    vessel:vesselReducer,

  },
});

export {
  store,
  loggin,
  init,
  setAuthStatus,
  addSong,
  removeSong,
  addSake,
  removeSake,
  reset,
  setActiveForm,
  getInventory,
  incrementAsync,
  getLocations,
  saveLocations,
  getCommodity,
  saveCommodity,
  getPackages,
  savePackages,
  getVessels,
  saveVessels,
};
