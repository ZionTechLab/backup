// import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// import { fetchCountryData, fetchLocationData } from "../../API/LocationApi";
// import axios from "axios";

// const getLocations = createAsyncThunk("data/getLocations", async () => {
//   try {
//     const response1 = await fetchCountryData();
//     let locations = {
//       loading: false,
//       isSuccess: response1.data.IsSuccess,
//       error: response1.data.ErrorDetails,
//       countryData: response1.data.ReturnValue.CountryUi,
//     };
// console.log(locations);
//     if (response1.data.IsSuccess == true) {
//       try {
//         const response = await fetchLocationData();
//         locations = {
//           ...locations,
//           isSuccess: response.data.IsSuccess,
//           error: response1.data.ErrorDetails,
//           locationData: response.data.ReturnValue,
//         };

//         return locations;
//       } catch (error) {
//         throw new Error(error.message);
//       }
//     }
//   } catch (error) {
//     throw new Error(error.message);
//   }
// });

// const login = createAsyncThunk("auth/login", async ({ formik, additionalData }, thunkAPI) => {
//     try {
//       // console.log("Data entered:", formik);
//       // console.log("Additional data:", additionalData);

//       const postData = { ...formik, unloco: additionalData };

//       const response = await axios.post(
//         "https://edoc-uat.advantis.lk/FFApi/Masters/Save_Location",
//         postData
//       );
//       let saveData = {
//         isSuccess: response.data.IsSuccess,
//         error: response.data.ErrorDetails,
//         locationData: response.data.ReturnValue,
//       };

//       //console.log(postData);
//       return saveData;
//     } catch (error) {
//       return thunkAPI.rejectWithValue(error.message);
//     }
//   }
// );

// const dataSlice = createSlice({
//   name: "data",
//   initialState: {
//     locations: {
//       locationData: null,
//       countryData: null,
//       //loading: false,
//       isSuccess: false,
//       error: null,
//     },
//   },
//   reducers: {},
//   extraReducers: (builder) => {
//     builder
//       .addCase(getLocations.pending, (state) => {
//         state.locations = {
//           loading: true,
//           isSuccess: false,
//           error: null,
//           locationData: [],
//           countryData: [],
//         };
//       })
//       .addCase(getLocations.fulfilled, (state, action) => {
//         state.locations = action.payload;
//       })
//       .addCase(getLocations.rejected, (state, action) => {
//         console.log('yy')
//         state.saveData = {
//           loading: false,
//           isSuccess: false,
//           error: action.error.message,
//           locationData: [],
//           countryData: [],
//         };
//       })
//       .addCase(saveLocations.pending, (state) => {
//         state.saveData = {
//           loading: true,
//           isSuccess: false,
//           error: null,
//         };
//       })
//       .addCase(saveLocations.fulfilled, (state, action) => {
//         state.saveData = action.payload;
//         state.saveData.isSuccess = true;
//       })
//       .addCase(saveLocations.rejected, (state, action) => {
//         state.saveData = {
//           loading: false,
//           isSuccess: false,
//           error: action.error.message,
//         };
//       });
//   },
// });

// export const dataReducer = dataSlice.reducer;
// export { getLocations, saveLocations };
// // import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// // import * as Config from "../../Common/Config";
// // import axios from "axios";

// // export const logginAsync = createAsyncThunk(
// //   "auth/logginAsync",
// //   async (payload) => {
// //     let url = Config.API_URL + "Inventory/Login";
// //     const response = await axios.post(url, payload);
// //     console.log(response.data);
// //     return {
// //       isAuthOK: response.data.isSuccess,
// //       user_id: response.data.isSuccess === true ? payload.user_id : "",
// //       err: response.data.strMessage,
// //     };
// //   }
// // );

// // export const initAsync = createAsyncThunk("auth/initAsync", async (payload) => {
// //   console.log(payload);
// //   let url = Config.API_URL + "Inventory/initialize";
// //   const response = await axios.post(url, payload);
// //   console.log(response.data);
// //   return response.data;
// // });

// // const authSlice = createSlice({
// //   name: "auth",
// //   initialState: {
// //     ActiveForm: "",
// //     isAuthOK: false,
// //     isInitOK: false,
// //     user_id: "",
// //     err: "",
// //     route: "",
// //   },
// //   reducers: {
// //     initAsync,
// //     setActiveForm(state, action) {
// //       console.log("aa");
// //       return { ...state, ActiveForm: action.payload };
// //     },
// //   },
// //   extraReducers: (builder) => {
// //     builder
// //       .addCase(logginAsync.fulfilled, (state, action) => {
// //         return {
// //           ...state,
// //           isAuthOK: action.payload.isAuthOK,
// //           user_id: action.payload.user_id,
// //           err: action.payload.err,
// //           ActiveForm: action.payload.isAuthOK == true ? "Home" : "",
// //         };
// //       })
// //       .addCase(logginAsync.rejected, (state, action) => {
// //         return {
// //           ...state,
// //           isAuthOK: false,
// //           user_id: "",
// //           err: action.error.message,
// //         };
// //       })
// //       .addCase(initAsync.fulfilled, (state, action) => {
// //         localStorage.setItem("items", JSON.stringify(action.payload.items));
// //         localStorage.setItem(
// //           "customer",
// //           JSON.stringify(action.payload.customer)
// //         );
// //         localStorage.setItem(
// //           "customerOutstanding",
// //           JSON.stringify(action.payload.customerOutstanding)
// //         );
// //         localStorage.setItem("route", action.payload.route);
// //         localStorage.setItem("userType", action.payload.userType);
// //         localStorage.setItem(
// //           "saleHistory",
// //           JSON.stringify(action.payload.saleHistory)
// //         );
// //         localStorage.setItem(
// //           "itemPricing",
// //           JSON.stringify(action.payload.itemPricing)
// //         );
// //         return { ...state, isInitOK: true, route: action.payload.route };
// //       })
// //       .addCase(initAsync.rejected, (state, action) => {
// //         return { ...state, isInitOK: false };
// //       });
// //   },
// // });

// // export const { setAuthStatus, setActiveForm } = authSlice.actions;
// // export const authReducer = authSlice.reducer;

// // export const loggin = (payload) => (dispatch) => {
// //   dispatch(logginAsync(payload));
// // };
// // export const init = (payload) => (dispatch) => {
// //   dispatch(initAsync(payload));
// // };
