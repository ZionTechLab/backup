import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchCommodityData } from '../../API/CommodityApi';
import axios from "axios";

const getCommodity = createAsyncThunk("commodity/getCommodity", async () => {
  try {
    const response = await fetchCommodityData();
    let commodity = {
      isSuccess: response.data.IsSuccess,
      error: response.data.ErrorDetails,
      commodityData: response.data.ReturnValue,
    };
    //console.log(commodity.commodityData);
    return commodity;

  } catch (error) {
    throw new Error(error.message);
  }

});

const saveCommodity = createAsyncThunk("commodity/saveCommodity", async (formikValues) => {
  try {
    const response = await axios.post(
      "https://edoc-uat.advantis.lk/FFApi/Masters/Save_Commodity",
      formikValues
    );
    const saveData = {
      isSuccess: response.data.IsSuccess,
      error: response.data.ErrorDetails,
      commodityData: response.data.ReturnValue,
    };
    return saveData;
  } catch (error) {

    throw new Error(error.message);
  }
});

const commoditySlice = createSlice({
  name: "commodity",
  initialState: {
    commodity: {
      commodityData: null,
      loading: false,
      isSuccess: false,
      error: null,
    },
    saveData: {
      loading: false,
      isSuccess: false,
      error: null,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getCommodity.pending, (state) => {
        state.commodity = {
          loading: true,
          isSuccess: false,
          error: null,
          commodityData: [],
        };
      })
      .addCase(getCommodity.fulfilled, (state, action) => {
        state.commodity = action.payload;
      })
      .addCase(getCommodity.rejected, (state, action) => {
        state.commodity = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
          commodityData: [],
        };
      });
    builder
      .addCase(saveCommodity.pending, (state) => {
        state.saveData = {
          loading: true,
          isSuccess: false,
          error: null,
        };
      })
      .addCase(saveCommodity.fulfilled, (state, action) => {
        state.saveData = action.payload;
      })
      .addCase(saveCommodity.rejected, (state, action) => {
        state.saveData = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
        };
      });
  },
});


export const commodityReducer = commoditySlice.reducer;
export { getCommodity, saveCommodity };





