import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchCountryData, fetchLocationData } from "../../API/LocationApi";
import axios from "axios";

const getLocations = createAsyncThunk("data/getLocations", async () => {
  try {
    const response1 = await fetchCountryData();
    let locations = {
      loading: false,
      isSuccess: response1.data.IsSuccess,
      error: response1.data.ErrorDetails,
      countryData: response1.data.ReturnValue.CountryUi,
    };
console.log(locations);
    if (response1.data.IsSuccess == true) {
      try {
        const response = await fetchLocationData();
        locations = {
          ...locations,
          isSuccess: response.data.IsSuccess,
          error: response1.data.ErrorDetails,
          locationData: response.data.ReturnValue,
        };

        return locations;
      } catch (error) {
        throw new Error(error.message);
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
});

const saveLocations = createAsyncThunk(
  "data/saveLocation",
  async ({ formik, additionalData }, thunkAPI) => {
    try {
      // console.log("Data entered:", formik);
      // console.log("Additional data:", additionalData);

      const postData = { ...formik, unloco: additionalData };

      const response = await axios.post(
        "https://edoc-uat.advantis.lk/FFApi/Masters/Save_Location",
        postData
      );
      let saveData = {
        isSuccess: response.data.IsSuccess,
        error: response.data.ErrorDetails,
        locationData: response.data.ReturnValue,
      };

      //console.log(postData);
      return saveData;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

const dataSlice = createSlice({
  name: "data",
  initialState: {
    locations: {
      locationData: null,
      countryData: null,
      //loading: false,
      isSuccess: false,
      error: null,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getLocations.pending, (state) => {
        state.locations = {
          loading: true,
          isSuccess: false,
          error: null,
          locationData: [],
          countryData: [],
        };
      })
      .addCase(getLocations.fulfilled, (state, action) => {
        state.locations = action.payload;
      })
      .addCase(getLocations.rejected, (state, action) => {
        console.log('yy')
        state.saveData = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
          locationData: [],
          countryData: [],
        };
      })
      .addCase(saveLocations.pending, (state) => {
        state.saveData = {
          loading: true,
          isSuccess: false,
          error: null,
        };
      })
      .addCase(saveLocations.fulfilled, (state, action) => {
        state.saveData = action.payload;
        state.saveData.isSuccess = true;
      })
      .addCase(saveLocations.rejected, (state, action) => {
        state.saveData = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
        };
      });
  },
});

export const dataReducer = dataSlice.reducer;
export { getLocations, saveLocations };
