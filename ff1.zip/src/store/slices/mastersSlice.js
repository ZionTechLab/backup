import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const counterSlice = createSlice({
  name: "counter",
  initialState: { value: null, status: "idle" },
  reducers: {
    decrement: (state) => {
      return { ...state, value: state.value - 1 };
    },
    incrementAsync: (state) => {
      console.log("s");
      state.status = "loading";
      return state; // don't modify state directly
    },
  },
});

// This can be a separate thunk or action creator
export const fetchCount = () => async (dispatch) => {
  dispatch(incrementAsync());
  try {
    const url = "https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Country";
    const response = await axios.get(url);
    dispatch(counterSlice.actions.increment(response.data.value)); // Update state with action
  } catch (error) {
    console.error("Error fetching data:", error);
    dispatch(counterSlice.actions.decrement()); // Handle error (optional)
  }
};

export const { incrementAsync, decrement } = counterSlice.actions;
export const counterReducer = counterSlice.reducer;
