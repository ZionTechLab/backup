import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchPackageData } from '../../API/PacksApi';
import axios from "axios";


const getPackages = createAsyncThunk("packs/getPackages", async () => {
 
      try {
        const response = await fetchPackageData();
        let packages = {
         // ...packages,
          isSuccess: response.data.IsSuccess,
          error: response.data.ErrorDetails,
          packageData: response.data.ReturnValue,
        };

        return packages;
      } catch (error) {
        throw new Error(error.message);
      }
    

});

const savePackages = createAsyncThunk("packs/saveCommodity", async (formikValues) => {
  try {
    const response = await axios.post(
      "https://edoc-uat.advantis.lk/FFApi/Masters/Save_PackTypes",
      formikValues
    );
    const saveData = {
      isSuccess: response.data.IsSuccess,
      error: response.data.ErrorDetails,
      packageData: response.data.ReturnValue,
    };
    return saveData;
  } catch (error) {

    throw new Error(error.message);
  }
});


const packsSlice = createSlice({
  name: "packs",
  initialState: {
    packages: {
      packageData: null,
      loading: false,
      isSuccess: false,
      error: null,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getPackages.pending, (state) => {
        state.packages = {
          loading: true,
          isSuccess: false,
          error: null,
          packageData: [],
        };
      })
      .addCase(getPackages.fulfilled, (state, action) => {
        state.packages = action.payload;
      })
      .addCase(getPackages.rejected, (state, action) => {
        state.packages = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
          packageData: [],
        };
      })
      .addCase(savePackages.pending, (state) => {
        state.saveData = {
          loading: true,
          isSuccess: false,
          error: null,
        };
      })
      .addCase(savePackages.fulfilled, (state, action) => {
        state.saveData = action.payload;
        state.saveData = {
          isSuccess: true,
        };
      })
      .addCase(savePackages.rejected, (state, action) => {
        state.saveData = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
        };
      });    
  },
});

export const packsReducer = packsSlice.reducer;
export { getPackages,savePackages };
