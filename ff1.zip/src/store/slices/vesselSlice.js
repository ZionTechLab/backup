import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchVesselData, fetchProviderData } from "../../API/VesselApi";
import axios from "axios";

const getVessels = createAsyncThunk("vessel/getVessels", async () => {
  try {
    const response1 = await fetchProviderData();
    let vessels = {
      loading: false,
      isSuccess: response1.data.IsSuccess,
      error: response1.data.ErrorDetails,
      countryData: response1.data.ReturnValue.CountryUi,
      providerData: response1.data.ReturnValue.ProviderUi,
    };

    if (response1.data.IsSuccess == true) {
      try {
        const response = await fetchVesselData();
        vessels = {
          ...vessels,
          isSuccess: response.data.IsSuccess,
          error: response.data.ErrorDetails,
          vesselData: response.data.ReturnValue,
        };

        return vessels;
      } catch (error) {
        throw new Error(error.message);
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
});

const saveVessels = createAsyncThunk("vessel/saveCommodsaveVesselsity", async (formikValues) => {
  try {
    const response = await axios.post(
      "https://edoc-uat.advantis.lk/FFApi/Masters/Save_Vessels",
      formikValues
    );
    const saveData = {
      isSuccess: response.data.IsSuccess,
      error: response.data.ErrorDetails,
      commodityData: response.data.ReturnValue,
    };
    return saveData;
  } catch (error) {

    throw new Error(error.message);
  }
});


const vesselSlice = createSlice({
  name: "vessel",
  initialState: {
    vessels: {
      vesselData: null,
      providerData: null,
      countryData: null,
      isSuccess: false,
      error: null,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getVessels.pending, (state) => {
        state.vessels = {
          loading: true,
          isSuccess: false,
          error: null,
          vesselData: [],
          countryData: [],
          providerData: [],
        };
      })
      .addCase(getVessels.fulfilled, (state, action) => {
        state.vessels = action.payload;
      })
      .addCase(getVessels.rejected, (state, action) => {
        state.vessels = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
          vesselData: [],
          providerData: [],
          countryData: [],
        };
      })
      .addCase(saveVessels.pending, (state) => {
        state.saveData = {
          loading: true,
          isSuccess: false,
          error: null,
        };
      })
      .addCase(saveVessels.fulfilled, (state, action) => {
        state.saveData = action.payload;
        state.saveData = {
          isSuccess: true,
        };
      })
      .addCase(saveVessels.rejected, (state, action) => {
        state.saveData = {
          loading: false,
          isSuccess: false,
          error: action.error.message,
        };
      });
  },
});

export const vesselReducer = vesselSlice.reducer;
export { getVessels,saveVessels };
