import { useState } from 'react';
import axios from 'axios';






// API to load data to DataGrid
// export async function getVesselData() {
//   const [vesselData, setVesselData] = useState([]);
//   try {
//     const response = await axios.get('https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Vessels');
//     setVesselData(response.data.ReturnValue);
//     return vesselData;
//   } 
//   catch (error) {
//     console.error(error);
//     throw error; 
//   }
// }

// API to load data to Country and Provider
export async function getCountryProvider() {
  try {
    const res = await axios
      .get('https://edoc-uat.advantis.lk/FFApi/Masters/getUI_VesselData');
    const data1 = (res.data.ReturnValue.CountryUi || [] );
    const data2 = (res.data.ReturnValue.ProviderUi || [] );
    return [data1,data2];
  } catch (error) {
    console.error(error);
    throw error; 
  }
}

// API to Save Data to Database
export async function sendData(data) {
  try {
    console.log("api",data);
    await axios.post(
      "https://edoc-uat.advantis.lk/FFApi/Masters/Save_Vessels",
      data
    );
  } catch (error) {
    console.error(error);
    throw error;
  }
}





