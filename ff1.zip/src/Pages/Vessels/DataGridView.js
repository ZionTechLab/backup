import * as React from "react";
// import {useEffect, useState} from "react";
// import axios from "axios";
import Box from "@mui/material/Box";
import { DataGrid } from "@mui/x-data-grid";
import IconButton from "@mui/material/IconButton";
import DriveFileRenameOutlineTwoToneIcon from "@mui/icons-material/DriveFileRenameOutlineTwoTone";
import "./DataGridView.css";

function DataGridView(props) {

  const columns = [
    {
      field: "VesselCode",
      headerName: "Vessel Code",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Vessel",
      headerName: "Vessel Name",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "RegCountry",
      headerName: "Country",
      flex: 0.6,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "ShpProvider",
      headerName: "Provider",
      flex: 0.6,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "TonNet",
      headerName: "Tonnage W.",
      flex: 0.8,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "TonGross",
      headerName: "Tonnage Gross.",
      minWidth:'200px',
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "MasterName",
      headerName: "Master Name",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Remarks",
      headerName: "Remarks",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      headerName: "",
      width: 70,
      field: "Action",
      headerClassName: "super-app-theme--header sticky-header",
      position: "sticky",

      renderCell: (params) => (
        <IconButton onClick={() =>  props.onEditClick(params.row)}>
          <DriveFileRenameOutlineTwoToneIcon sx={{ color: "#FFC436" }} />
        </IconButton>
      ),
    },
  ];

  return (
    <Box
      sx={{
        width: "100%",
        "& .super-app-theme--header": {
          backgroundColor: "rgb(20, 80, 163)",
          fontSize: 18,
          color: "white",
          fontFamily: "verdana",
        },
        "& .action-header": {
          position: "sticky",
          top: 0,
        },

        "& .MuiDataGrid-renderingZone": {
          "& .MuiDataGrid-row": {
            "&:nth-child(2n)": {
              backgroundColor: "rgb(20, 80, 163)",
            },
          },
        },
      }}>

      <DataGrid
        sx={{
          boxShadow: 10,
          borderColor: "primary.light",
          "& .MuiDataGrid-cell:hover": {
            color: "primary.main",
          },
        }}
        rows={props.getVesselData || []}
        columns={columns}
        getRowId={(row) => row.VesselCode}
        rowHeight={25}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 20,
            },
          },
        }}
        pageSizeOptions={[20]}
        disableRowSelectionOnClick
      />

    </Box>
  );
}

export default DataGridView;