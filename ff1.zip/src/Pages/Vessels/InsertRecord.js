import React, { useState, useEffect } from "react";
// import axios from "axios";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import FormLabel from "@mui/material/FormLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import IconButton from "@mui/material/IconButton";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import Button from "@mui/material/Button";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useFormik } from "formik";
import * as yup from "yup";
import styles from "./InsertRecord.module.css";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 500,
  bgcolor: "background.paper",
  boxShadow: 25,
};


function InsertRecord( props ) {

  const [selectedCountry, setSelectedCountry] = useState("");
  const handleSelectChangeCountry = (e,VesselCode, vessel, tonNet, tonGross, masterName, remarks) => {
    const selectedOption = e.target.value;
    formik.setFieldValue("CountryName", selectedOption);
    const selectedCountry = props.options.CountryData.find(
      (option) => option.CountryN === selectedOption
    );
    setSelectedCountry(selectedCountry.Country);
  //   formik.setFieldValue('RegCountry', selectedCountry.Country);
  //   formik.setFieldValue('ShpProvider', selectedProvider.AgncyCode);


  // formik.setFieldValue('VesselCode', VesselCode);
  // formik.setFieldValue('Vessel', vessel);
  // formik.setFieldValue('TonNet', tonNet);
  // formik.setFieldValue('TonGross', tonGross);
  // formik.setFieldValue('MasterName', masterName);
  // formik.setFieldValue('Remarks', remarks);
    
  }

  // handleSelectChangeCountry(
  //    // The event parameter
  //   formik.values.VesselCode,
  //   formik.values.Vessel, // Vessel value
  //   formik.values.TonNet, // TonNet value
  //   formik.values.TonGross, // TonGross value
  //   formik.values.MasterName, // MasterName value
  //   formik.values.Remarks // Remarks value
  // );

  const [selectedProvider, setSelectedProvider] = useState("");
  const handleSelectChangeProvider = (e,VesselCode, vessel, tonNet, tonGross, masterName, remarks) => {
    const selectedOption = e.target.value;
    formik.setFieldValue("ProviderName", selectedOption);
    const selectedProvider = props.options.ProviderData.find(
      (option) => option.AgncyName === selectedOption
    );
    setSelectedProvider(selectedProvider.AgncyCode);
//     formik.setFieldValue('RegCountry', selectedCountry.Country);
//     formik.setFieldValue('ShpProvider', selectedProvider.AgncyCode);

//  formik.setFieldValue('VesselCode', VesselCode);
//   formik.setFieldValue('Vessel', vessel);
//   formik.setFieldValue('TonNet', tonNet);
//   formik.setFieldValue('TonGross', tonGross);
//   formik.setFieldValue('MasterName', masterName);
//   formik.setFieldValue('Remarks', remarks);
  }

  // handleSelectChangeProvider(
  //    // The event parameter
  //   formik.values.VesselCode,
  //   formik.values.Vessel, // Vessel value
  //   formik.values.TonNet, // TonNet value
  //   formik.values.TonGross, // TonGross value
  //   formik.values.MasterName, // MasterName value
  //   formik.values.Remarks // Remarks value
  // );
 
  useEffect(() => {
    if (props.ModalData.isDisplayModal) {
      if (props.ModalData.rowData) {
        setSelectedCountry(props.ModalData.rowData.RegCountry || "");
        setSelectedProvider(props.ModalData.rowData.ShpProvider || "");
      } else {
        setSelectedCountry("");
        setSelectedProvider("");
      }
    }
  },[props.ModalData.isDisplayModal, props.ModalData.rowData] );
  
  

  const validationSchema = yup.object({
    VesselCode: yup
      .string("Enter Vessel Code")
      .max(5, "Maximum 5 Characters")
      .required("Vessel Code is required"),
  
    Vessel: yup
      .string("Enter Vessel")
      .max(35, "Maximum 35 Characters")
    .required("Vessel is required"),
  
    TonNet: yup
      .number("Enter Ton Weight"),
  
    TonGross: yup
      .number("Enter Gross Weight"),
  
    MasterName: yup
      .string("Enter MasterName")
      .min(1, "Enter a valid MasterName"),
  
    Remarks: yup
      .string("Enter Remarks")
      .max(50, "Maximum 50 Characters"),
  });


  const formik = useFormik({




    
    initialValues: {
      
      // RegCountry: props.ModalData.rowData ? props.ModalData.rowData.RegCountry: "",
      // ShpProvider: props.ModalData.rowData ? props.ModalData.rowData.ShpProvider: "",
      VesselCode: props.ModalData.rowData ? props.ModalData.rowData.VesselCode: '',
      Vessel: props.ModalData.rowData ? props.ModalData.rowData.Vessel: '',
      // VesselCode: '',
      // Vessel: '',
      RegCountry: props.ModalData.rowData
      ? selectedCountry
      : selectedCountry,
  
    ShpProvider: props.ModalData.rowData
      ?  selectedProvider
      : selectedProvider,
      
      TonNet: props.ModalData.rowData ? props.ModalData.rowData.TonNet: "",
      TonGross:  props.ModalData.rowData ? props.ModalData.rowData.TonGross: "",
      MasterName: props.ModalData.rowData ? props.ModalData.rowData.MasterName: "",
      Remarks: props.ModalData.rowData ? props.ModalData.rowData.Remarks: "",

   
      Active: "",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
   
      props.sendData(values);
      props.onClose(false);
    },
  });

  const handleClose = () => {
    props.onClose(false);
  };

  return (
    
    <div>
      
      <Modal
        open={props.ModalData.isDisplayModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description">

        <form onSubmit={formik.handleSubmit}>

          <Box sx={style} color="error.contrastText" p={1}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className={styles.row0}>
                <p className={styles.heading}>
                  {props.ModalData.isNewMode == false
                    ? "Edit Vessel Data"
                    : "Add New Vessel"}
                </p>

                <div className={styles.icon}>
                  <IconButton onClick={handleClose} sx={{ marginLeft: "100" }}>
                    <CancelIcon sx={{ color: "white" }} />
                  </IconButton>
                </div>
              </div>

              <div className={styles.row1}>
              <div className={styles.col1}>
                  <FormLabel>Vessel Code/Name : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    className={styles.shrtTxtFld}
                    id="filled-basic1"
                    name="VesselCode"
                    label="Code"
                    variant="standard"
                    size="small"
                    
                    onChange={formik.handleChange}
                   
                    onBlur={formik.handleBlur}
                    value={formik.values.VesselCode}
                    sx={{ marginRight: "10px" }}
                    error={formik.touched.VesselCode && Boolean(formik.errors.VesselCode)}
                    helperText={formik.touched.VesselCode && formik.errors.VesselCode}
                    disabled={!props.ModalData.isNewMode}
                  />

                  <TextField
                    id="filled-basic"
                    name="Vessel"
                    label="Vessel"
                    variant="standard"
                    size="small"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.Vessel}
                    error={formik.touched.Vessel && Boolean(formik.errors.Vessel)}
                    helperText={formik.touched.Vessel && formik.errors.Vessel}
                  />
                </div>
              </div>

              <div className={styles.row2}>
                <div className={styles.col1}>
                  <FormLabel>Country : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    className={styles.shrtTxtFld}
                    id="filled-basic"
                    name="RegCountry"
                    variant="standard"
                    label="Code"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={selectedCountry}
                    sx={{ marginRight: "10px" }}
                    error={formik.touched.RegCountry && Boolean(formik.errors.RegCountry)}
                    helperText={formik.touched.RegCountry && formik.errors.RegCountry}
                  />

                  <FormControl variant="standard">
                    <InputLabel
                      id="demo-simple-select-required-label"
                      sx={{ tansition: "margin 0.2s" }}>
                      Name
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-required-label"
                      id="demo-simple-select-required"
                      variant="standard"
                      size="small"
                      name="CountryName"
                      sx={{ height: "30px", width: "190px", marginTop: 1 }}
                      // value={formData.selectedOption}
                      onClick={props.handleSelectClick}
                      onBlur={formik.handleBlur}
                      onChange={handleSelectChangeCountry}
                      >
                        
                      {props.options.CountryData.map((option, index) => (
                        <MenuItem key={index} value={option.CountryN}>
                          {option.CountryN}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </div>
              </div>

              <div className={styles.row3}>
              <div className={styles.col1}>
                  <FormLabel>Provider Name : </FormLabel>
                </div>
                <div className={styles.col2}>
                  <TextField
                    className={styles.shrtTxtFld}
                    id="filled-basic"
                    name="ShpProvider"
                    variant="standard"
                    label="Code"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={selectedProvider}
                    sx={{ marginRight: "10px" }}
                    error={formik.touched.ShpProvider && Boolean(formik.errors.ShpProvider)}
                    helperText={formik.touched.ShpProvider && formik.errors.ShpProvider}
                  />

                  <FormControl variant="standard">
                    <InputLabel
                      id="demo-simple-select-required-label"
                      sx={{ transition: "margin 0.2s" }}>
                      Name
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-required-label"
                      id="demo-simple-select-required"
                      name="ProviderName"
                      variant="standard"
                      size="small"
                      sx={{ height: "30px", width: "190px", marginTop: 1 }}
                      onClick={props.handleSelectClick}
                      onBlur={formik.handleBlur}
                      onChange={handleSelectChangeProvider}
                      >
                      {props.options.ProviderData.map((option, index) => (
                        <MenuItem key={index} value={option.AgncyName}>
                          {option.AgncyName}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </div>
              </div>

              <div className={styles.row4}>
                <div className={styles.col1}>
                  <FormLabel>Tonnage W. : </FormLabel>
                </div>
                <div className={styles.col2}>
                  <TextField
                    className={styles.shrtTxtFld}
                    id="filled-basic"
                    name="TonNet"
                    variant="standard"
                    label="Weight"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.TonNet}
                    sx={{ marginRight: "10px" }}
                    error={formik.touched.TonNet && Boolean(formik.errors.TonNet)}
                    helperText={formik.touched.TonNet && formik.errors.TonNet}
                  />

                  <FormLabel sx={{ marginTop: 3 }}>Gross W. : </FormLabel>

                  <TextField
                    className={styles.shrtTxtFld}
                    id="filled-basic"
                    name="TonGross"
                    variant="standard"
                    label="Weight"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.TonGross}
                    error={formik.touched.TonGross && Boolean(formik.errors.TonGross)}
                    helperText={formik.touched.TonGross && formik.errors.TonGross}
                  />
                </div>
              </div>

              <div className={styles.row5}>
                <div className={styles.col1}>
                  <FormLabel>Master Name : </FormLabel>
                </div>
                <div className={styles.col2}>
                  <TextField
                    className={styles.longTxtFld}
                    id="filled-basic"
                    name="MasterName"
                    variant="standard"
                    label="Name"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.MasterName}
                    sx={{ paddingRight: "20px" }}
                    error={formik.touched.MasterName && Boolean(formik.errors.MasterName)}
                    helperText={formik.touched.MasterName && formik.errors.MasterName}
                  />
                </div>
              </div>

              <div className={styles.row6}>
                <div className={styles.col1}>
                  <FormLabel>Remarkss : </FormLabel>
                </div>
                <div className={styles.col2}>
                  <TextField
                    className={styles.longTxtFld}
                    id="filled-basic"
                    name="Remarks"
                    variant="standard"
                    label="Remarks"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.Remarks}
                    sx={{ paddingRight: "20px" }}
                    error={formik.touched.Remarks && Boolean(formik.errors.Remarks)}
                    helperText={formik.touched.Remarks && formik.errors.Remarks}
                  />
                </div>
              </div>

              <div className={styles.row7}>
                <div className={styles.col1}></div>
                <div className={styles.col2}>
                  <FormControlLabel control={<Checkbox 
                   name="Active"
                   checked={formik.values.Active = "Y"} 
                  //  onChange={(e) => {
                  //    const newValue = e.target.checked ? "Y" : "";
                  //    formik.setFieldValue("Active", newValue);
                  //  }}
                 />
               }
                 label="Active" />
                </div>
              </div>

              <div className={styles.row8}>
                <div className={styles.col1}></div>
                <div className={styles.col2}>
                  <Button
                    variant="contained"
                    color="success"
                    fontSize="medium"
                    type="submit"
                    startIcon={<SaveIcon />}>
                    Save
                  </Button>
                </div>
              </div>
            </Typography>
          </Box>
        </form>
      </Modal>
    </div>
  );
}

export default InsertRecord;
