import React, { useState, useEffect } from "react";
import DataGridView from "../../Components/DataGridView";
import { ColomnType } from "../../Components/DataGridView/enum";
import style from "./Vessel.module.css";
import Modal from "../../Components/Modal";
import ErrorPage from "../../Components/ErrorPage/ErrorPage";
import * as Yup from "yup";
import {
  TextField,
  Select,
  CheckBox,
  FormControl,
} from "../../Components/FormControls";
import { Button } from "../../Components/FormControls/Button";
import { useFormik } from "formik";
import { store, getVessels, saveVessels } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import { New, Save } from "../../Components/Icons";
import LoadingPage from "../../Components/ErrorPage/Loading";

function Vessel() {
  const columns = [
    {
      field: "VesselCode",
      headerName: "Vessel Code",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Vessel",
      headerName: "Vessel Name",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "RegCountry",
      //field: "Country",
      headerName: "Country",
      flex: 0.6,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "ShpProvider",
      //field: "AgncyCode",
      headerName: "Provider",
      flex: 0.6,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "TonNet",
      headerName: "Tonnage W.",
      flex: 0.8,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "TonGross",
      headerName: "Tonnage Gross.",
      minWidth: "200px",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "MasterName",
      headerName: "Master Name",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Remarks",
      headerName: "Remarks",
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Active",
      headerName: "Active",
      width: 30,
      ColomnType: ColomnType.YESNO,
    },
    {
      width: 30,
      ColomnType: ColomnType.EDITBUTTON,
    },
  ];

  const data = useSelector((state) => state.vessel);
  const dispatch = useDispatch();

  const [selectedRow, setSelectedRow] = useState({});
  const [ModalStatus, setModalStatus] = useState({
    isopen: false,
    isEditMode: false,
  });

  const handleClickOpen = (isEditMode) => {
    formik.resetForm();
    setModalStatus({ isopen: true, isEditMode: isEditMode });
  };

  const handleClose = () =>
    setModalStatus({ isopen: false, isEditMode: false });
  useEffect(() => {
    store.dispatch(getVessels());
  }, []);

  const validationSchema = Yup.object().shape({
    // <<<<<<< HEAD
    //     PkgType: Yup.string()
    //       .min(1, "Enter a valid UnlocCode")
    //       .max(3, "Maximum characters 3")
    //       .required("UnlocCode is required"),
    //     PkgTypeN: Yup.string()
    //       .min(1, "Enter a valid Location Name")
    //       .max(50, "Location Name is required")
    //       .required("Location Name is required"),
    // =======
    // PkgType: Yup.string()
    //   .min(1, "Enter a valid UnlocCode")
    //   .max(3, "Maximum characters 3")
    //   .required("UnlocCode is required"),

    VesselCode: Yup.string("Enter Vessel Code")
      .max(5, "Maximum 5 Characters")
      .required("Vessel Code is required"),

    Vessel: Yup.string("Enter Vessel")
      .max(35, "Maximum 35 Characters")
      .required("Vessel is required"),

    TonNet: Yup.number("Enter Ton Weight"),

    TonGross: Yup.number("Enter Gross Weight"),

    MasterName: Yup.string("Enter MasterName").min(
      1,
      "Enter a valid MasterName"
    ),

    Remarks: Yup.string("Enter Remarks").max(50, "Maximum 50 Characters"),
  });

  let formik = useFormik({
    initialValues: {
      VesselCode: ModalStatus.isEditMode ? selectedRow.VesselCode : "",
      Vessel: ModalStatus.isEditMode ? selectedRow.Vessel : "",
      Country: ModalStatus.isEditMode ? selectedRow.Country : "AF",
      AgncyCode: ModalStatus.isEditMode ? selectedRow.AgncyCode : 101,
      TonNet: ModalStatus.isEditMode ? selectedRow.TonNet : "",
      TonGross: ModalStatus.isEditMode ? selectedRow.TonGross : "",
      MasterName: ModalStatus.isEditMode ? selectedRow.MasterName : "",
      Remarks: ModalStatus.isEditMode ? selectedRow.Remarks : "",
      Active: ModalStatus.isEditMode ? selectedRow.Active : "Y",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      console.log(values);
      console.log("adee", values.AgncyCode);
      dispatch(saveVessels(values))
        .then(() => {
          handleClose();
          dispatch(getVessels());
        })
        .catch((error) => {
          console.error("Error saving location:", error);
        });
    },
  });

  const handleEditClick = (row) => {
    setSelectedRow(row);
    setModalStatus({
      isopen: true,
      isEditMode: true,
    });
  };

  let modal = ModalStatus.isopen ? (
    <Modal
      handleClose={() => handleClose()}
      title={ModalStatus.isEditMode ? "Edit Vessel" : "Add New Vessel"}
    >
      <div>
        <form onSubmit={formik.handleSubmit}>
          <TextField
            id="VesselCode"
            Caption="Vessel Code"
            value={selectedRow.VesselCode || ""}
            Binding={formik}
          />

          <TextField
            id="Vessel"
            Caption="Vessel Name"
            value={selectedRow.Vessel || ""}
            Binding={formik}
          />
          <Select
            id="Country"
            Caption="Country"
            dataCode="Country"
            dataName="CountryN"
            data={data.vessels.countryData}
            value={selectedRow.Country || ""}
            Binding={formik}
          />

          <Select
            id="AgncyCode"
            Caption="Provider Name"
            dataCode="AgncyCode"
            dataName="AgncyName"
            data={data.vessels.providerData}
            value={selectedRow.AgncyCode || ""}
            Binding={formik}
          />
          <TextField
            id="TonNet"
            Caption="Tonnage Weight"
            value={selectedRow.TonNet || ""}
            Binding={formik}
          />
          <TextField
            id="TonGross"
            Caption="Gross Weight"
            value={selectedRow.TonGross || ""}
            Binding={formik}
          />
          <TextField
            id="MasterName"
            Caption="Master Name"
            value={selectedRow.MasterName || ""}
            Binding={formik}
          />
          <TextField
            id="Remarks"
            Caption="Remarks"
            value={selectedRow.Remarks || ""}
            Binding={formik}
          />
          <FormControl>
            <CheckBox id="Active" Caption="Active" Binding={formik} />
          </FormControl>
          <FormControl>
            <Button type="button">
              <Save /> Save
            </Button>
          </FormControl>
        </form>
      </div>
    </Modal>
  ) : (
    ""
  );

  let page;
  if (data.vessels.loading) page = <LoadingPage />;
  else if (!data.vessels.isSuccess)
    page = <ErrorPage messege="Vessel details Loading Failed" />;
  else
    page = (
      <div className={style.container}>
        <div className={style.page}>
          <div className={style.col1}>Vessels Details</div>
          <div>
            <div>
              <Button BtnStyle="Add" onClick={() => handleClickOpen(false)}>
                <New /> <p>Add</p>
              </Button>
              {modal}
            </div>
          </div>
        </div>
        <div className={style.dataGrid}>
          <DataGridView
            columns={columns}
            Binding={data.vessels.vesselData}
            onEditClick={handleEditClick}
          />
        </div>
      </div>
    );
  return <div> {page}</div>;
}

export default Vessel;
