import React, { useState, useEffect } from "react";
import DataGridView from "../../Components/DataGridView";
import { ColomnType } from "../../Components/DataGridView/enum";
import style from "./Commodity.module.css";
import Modal from "../../Components/Modal";
import ErrorPage from "../../Components/ErrorPage/ErrorPage";
import * as Yup from "yup";
import {
  TextField,
  CheckBox,
  FormControl,
} from "../../Components/FormControls";
import { Button } from "../../Components/FormControls/Button";
import { useFormik } from "formik";
import { store, getCommodity, saveCommodity } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import { New, Save } from "../../Components/Icons";
import LoadingPage from "../../Components/ErrorPage/Loading";

function Commodity() {
  const columns = [
    {
      id: 1,
      field: "CommodityType",
      headerName: "Commodity Code",
      minWidth: 110,
      flex: 0.7,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "CommodityTypeN",
      headerName: "Commodity Name",
      minWidth: 120,
      flex: 1.5,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Active",
      headerName: "Active",
      width: 30,
      ColomnType: ColomnType.YESNO,
    },
    {
      width: 30,
      ColomnType: ColomnType.EDITBUTTON,
    },
  ];

  const data = useSelector((state) => state.commodity);
  const dispatch = useDispatch();

  const [selectedRow, setSelectedRow] = useState({});
  const [ModalStatus, setModalStatus] = useState({
    isopen: false,
    isEditMode: false,
  });

  const handleClickOpen = (isEditMode) => {
    formik.resetForm();
    setModalStatus({ isopen: true, isEditMode: isEditMode });
  };

  const handleClose = () =>
    setModalStatus({ isopen: false, isEditMode: false });
  useEffect(() => {
    store.dispatch(getCommodity());
  }, []);

  const validationSchema = Yup.object().shape({
    CommodityType: Yup.string()
      .min(1, "Enter a valid Commodity Type")
      .max(3, "Maximum characters 3")
      .required("Commodity Type is required"),
    CommodityTypeN: Yup.string()
      .min(1, "Enter a valid Commodity Name")
      .max(50, "Commodity Name is required")
      .required("Commodity Name is required"),
  });

  let formik = useFormik({
    initialValues: {
      CommodityType: ModalStatus.isEditMode ? selectedRow.CommodityType : "",
      CommodityTypeN: ModalStatus.isEditMode ? selectedRow.CommodityTypeN : "",
      Active: ModalStatus.isEditMode ? selectedRow.Active : "Y",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      dispatch(saveCommodity({ formik: values }));
      handleClose();

      // dispatch(saveCommodity(values))
      //   .then(() => {
      //     handleClose();
      //     dispatch(getCommodity());
      //   })
      //   .catch((error) => {
      //     console.error("Error saving location:", error);
      //   });
    },
  });

  const handleEditClick = (row) => {
    setSelectedRow(row);
    setModalStatus({
      isopen: true,
      isEditMode: true,
    });
  };

  let modal = ModalStatus.isopen ? (
    <Modal
      handleClose={() => handleClose()}
      title={ModalStatus.isEditMode ? "Edit Commodity" : "Add New Commodity"}
    >
      <div>
        <form onSubmit={formik.handleSubmit}>
          <TextField
            id="CommodityType"
            Caption="Commodity Code"
            value={selectedRow.CommodityType || ""}
            Binding={formik}
          />
          <TextField
            id="CommodityTypeN"
            Caption="Commodity Name"
            value={selectedRow.CommodityTypeN || ""}
            Binding={formik}
          />
          <FormControl>
            <CheckBox id="Active" Caption="Active" Binding={formik} />
          </FormControl>
          <FormControl>
            <Button type="button">
              <Save /> Save
            </Button>
          </FormControl>
        </form>
      </div>
    </Modal>
  ) : (
    ""
  );

  let page;
  if (data.commodity.loading) page = <LoadingPage />;
  else if (!data.commodity.isSuccess)
    page = <ErrorPage messege="Commodity details Loading Failed" />;
  else
    page = (
      <div className={style.container}>
        <div className={style.page}>
          <div className={style.col1}>Commodity Details</div>
          <div>
            <div>
              <Button BtnStyle="Add" onClick={() => handleClickOpen(false)}>
                <New /> <p>Add</p>
              </Button>
              {modal}
            </div>
          </div>
        </div>
        <div className={style.dataGrid}>
          <DataGridView
            columns={columns}
            Binding={data.commodity.commodityData}
            onEditClick={handleEditClick}
          />
        </div>
      </div>
    );
  return <div> {page}</div>;
}

export default Commodity;
