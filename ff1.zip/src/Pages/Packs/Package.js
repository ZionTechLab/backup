import React, { useState, useEffect } from "react";
import DataGridView from "../../Components/DataGridView";
import { ColomnType } from "../../Components/DataGridView/enum";
import style from "./Package.module.css";
import Modal from "../../Components/Modal";
import ErrorPage from "../../Components/ErrorPage/ErrorPage";
import * as Yup from "yup";
import {
  TextField,
  Select,
  CheckBox,
  FormControl,
} from "../../Components/FormControls";
import { Button } from "../../Components/FormControls/Button";
import { useFormik } from "formik";
import { store, getPackages,savePackages } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import { New, Save } from "../../Components/Icons";
import LoadingPage from "../../Components/ErrorPage/Loading";

function Package() {
  const columns = [
    {
      id: 1,
      field: "SNo",
      headerName: "SNo",
      minWidth: 110,
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "PkgType",
      headerName: "Package Code",
      minWidth: 120,
      flex: 0.3,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "PkgTypeN",
      headerName: "Package Name",
      minWidth: 140,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Active",
      headerName: "Active",
      width: 30,
      ColomnType: ColomnType.YESNO,
    },
    {
      width: 30,
      ColomnType: ColomnType.EDITBUTTON,
    },
  ];

  const data = useSelector((state) => state.packs);
  const dispatch = useDispatch();

  const [selectedRow, setSelectedRow] = useState({});
  const [ModalStatus, setModalStatus] = useState({
    isopen: false,
    isEditMode: false,
  });

  const handleClickOpen = (isEditMode) => {
    formik.resetForm();
    setModalStatus({ isopen: true, isEditMode: isEditMode });
  };

  const handleClose = () =>
    setModalStatus({ isopen: false, isEditMode: false });
  useEffect(() => {
    store.dispatch(getPackages());
  }, []);

  const validationSchema = Yup.object().shape({
    PkgType: Yup.string()
      .min(1, "Enter a valid UnlocCode")
      .max(3, "Maximum characters 3")
      .required("UnlocCode is required"),
    PkgTypeN: Yup.string()
      .min(1, "Enter a valid Location Name")
      .max(50, "Location Name is required")
      .required("Location Name is required"),
  });

  let formik = useFormik({
    initialValues: {
      PkgType: ModalStatus.isEditMode ? selectedRow.PkgType : "",
      PkgTypeN: ModalStatus.isEditMode ? selectedRow.PkgTypeN : "",
      Active: ModalStatus.isEditMode ? selectedRow.Active : "",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      dispatch(savePackages(values))
      .then(() => {
          handleClose(); 
          dispatch(getPackages()); 
        })
          .catch((error) => {
           console.error("Error saving location:", error);
        });
    },

  });

  const handleEditClick = (row) => {
    setSelectedRow(row);
    setModalStatus({
      isopen: true,
      isEditMode: true,
    });
  };

  let modal = ModalStatus.isopen ? (
    <Modal
      handleClose={() => handleClose()}
      title={ModalStatus.isEditMode ? "Edit Package" : "Add New Package"}
    >
      <div>
        <form onSubmit={formik.handleSubmit}>
          <TextField
            id="PkgType"
            Caption="Package Code"
            value={selectedRow.PkgType || ""}
            Binding={formik}
          />
          <TextField
            id="PkgTypeN"
            Caption="Package Name"
            value={selectedRow.PkgTypeN || ""}
            Binding={formik}
          />
          <FormControl>
            <CheckBox id="Active" Caption="Active" Binding={formik} />
          </FormControl>
          <FormControl>
            <Button type="button">
              <Save /> Save
            </Button>
          </FormControl>
        </form>
      </div>
    </Modal>
  ) : (
    ""
  );

  let page;
  if (data.packages.loading) page = <LoadingPage />;
  else if (!data.packages.isSuccess)
    page = <ErrorPage messege="Package details Loading Faild" />;
  else
    page = (
      <div className={style.container}>
        <div className={style.page}>
          <div className={style.col1}>Packages Details</div>
          <div>
            <div>
              <Button BtnStyle="Add" onClick={() => handleClickOpen(false)}>
                <New /> <p>Add</p>
              </Button>
              {modal}
            </div>
          </div>
        </div>
        <div className={style.dataGrid}>
          <DataGridView
            columns={columns}
            Binding={data.packages.packageData}
            onEditClick={handleEditClick}
          />
        </div>
      </div>
    );
  return <div> {page}</div>;
}

export default Package;
