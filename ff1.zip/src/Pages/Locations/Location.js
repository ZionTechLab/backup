import React, { useState, useEffect } from "react";
import DataGridView from "../../Components/DataGridView";
import style from "./Location.module.css";
import Modal from "../../Components/Modal";
import ErrorPage from "../../Components/ErrorPage/ErrorPage";
import * as Yup from "yup";
import {
  TextField,
  Select,
  CheckBox,
  FormControl,
} from "../../Components/FormControls";
import { SaveButton, AddButton } from "../../Components/FormControls/Button";
import { useFormik } from "formik";
import { store, getLocations, saveLocations } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import { columns } from "./tableDeffenetion";
import LoadingPage from "../../Components/ErrorPage/Loading";

function Location() {
  const data = useSelector((state) => state.data);
  const dispatch = useDispatch();

  const [selectedRow, setSelectedRow] = useState({});
  const [ModalStatus, setModalStatus] = useState({
    isopen: false,
    isEditMode: false,
  });

  const handleClickOpen = (isEditMode) => {
    formik.resetForm();
    setModalStatus({ isopen: true, isEditMode: isEditMode });
  };

  const handleClose = () =>
    setModalStatus({ isopen: false, isEditMode: false });
  useEffect(() => {
    store.dispatch(getLocations());
  }, []);

  const validationSchema = Yup.object().shape({
    UnlocCode: Yup.string()
      .max(3, "Maximum characters 3")
      .required("UnlocCode is required"),
    UnlocName: Yup.string()
      .max(50, "Location Name is required")
      .required("Location Name is required"),
  });

  let formik = useFormik({
    initialValues: {
      // <<<<<<< HEAD
      //       UnlocCode: ModalStatus.isEditMode ? selectedRow.UnlocCode : " ",
      //       UnlocName: ModalStatus.isEditMode ? selectedRow.UnlocName : " ",
      //       Country: ModalStatus.isEditMode ? selectedRow.Country : "LK",
      //       SeaPort: ModalStatus.isEditMode ? selectedRow.SeaPort : " ",
      //       AirPort: ModalStatus.isEditMode ? selectedRow.AirPort : " ",
      //       Active: ModalStatus.isEditMode ? selectedRow.Active : " ",
      // =======
      UnlocCode: ModalStatus.isEditMode ? selectedRow.UnlocCode : "",
      UnlocName: ModalStatus.isEditMode ? selectedRow.UnlocName : "",
      Country: ModalStatus.isEditMode ? selectedRow.Country : "AF",
      SeaPort: ModalStatus.isEditMode ? selectedRow.SeaPort : "",
      AirPort: ModalStatus.isEditMode ? selectedRow.AirPort : "",
      Active: ModalStatus.isEditMode ? selectedRow.Active : "Y",
      // >>>>>>> dce9f8fb908bfd2fbf74bb706cba2a420de111fd
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      const combinedData = `${values.Country}${values.UnlocCode}`;
      dispatch(saveLocations({ formik: values, additionalData: combinedData }))
        .then(() => {
          handleClose();
          dispatch(getLocations());
        })
        .catch((error) => {
          console.error("Error saving location:", error);
        });
    },
  });

  const handleEditClick = (row) => {
    setSelectedRow(row);
    setModalStatus({
      isopen: true,
      isEditMode: true,
    });
  };

  let modal = ModalStatus.isopen ? (
    <Modal
      handleClose={() => handleClose()}
      title={ModalStatus.isEditMode ? "Edit Location" : "Add New Location"}
    >
      <div>
        <form onSubmit={formik.handleSubmit}>
          <Select
            id="Country"
            Caption="Country"
            dataCode="Country"
            dataName="CountryN"
            data={data.locations.countryData}
            value={selectedRow.Country || ""}
            Binding={formik}
          />
          <TextField
            id="UnlocCode"
            Caption="UN Location Code"
            value={selectedRow.UnlocCode || ""}
            Binding={formik}
          />
          <TextField
            id="UnlocName"
            Caption="UN Location Name"
            value={selectedRow.UnlocName || ""}
            Binding={formik}
          />
          <FormControl>
            <CheckBox id="SeaPort" Caption="Sea Port" Binding={formik} />
            <CheckBox id="AirPort" Caption="Air Port" Binding={formik} />
            <CheckBox id="Active" Caption="Active" Binding={formik} />
          </FormControl>
          <FormControl>
            <SaveButton />
          </FormControl>
        </form>
      </div>
    </Modal>
  ) : (
    ""
  );

  let page;
  if (data.locations.loading) page = <LoadingPage />;
  else if (!data.locations.isSuccess){
    page = <ErrorPage messege="Location details Loading Failed" />;
  }
    
  else
    page = (
      <div className={style.container}>
        <div className={style.page}>
          <div className={style.col1}>Location Details</div>
          <div>
            <div>
              <AddButton onClick={() => handleClickOpen(false)} />
              {modal}
            </div>
          </div>
        </div>
        <div className={style.dataGrid}>
          <DataGridView
            columns={columns}
            Binding={data.locations.locationData}
            onEditClick={handleEditClick}
          />
        </div>
      </div>
    );
  return <div> {page}</div>;
}

export default Location;
