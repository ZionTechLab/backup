import { ColomnType } from "../../Components/DataGridView/enum";

export const columns = [
  {
    id: 1,
    field: "Country",
    headerName: "Country",
    minWidth: 110,
    flex: 1,
    headerClassName: "super-app-theme--header",
  },
  {
    field: "UnloCo",
    headerName: "UnLocCo",
    minWidth: 120,
    flex: 0.3,
    headerClassName: "super-app-theme--header",
  },
  {
    field: "UnlocCode",
    headerName: "UNLocCode",
    minWidth: 140,
    headerClassName: "super-app-theme--header",
  },
  {
    field: "UnlocName",
    headerName: "Location Name",
    minWidth: 180,
    flex: 1.6,
    headerClassName: "super-app-theme--header",
  },
  {
    field: "SeaPort",
    headerName: "Sea Port",
    width: 30,
    ColomnType: ColomnType.YESNO,
  },
  {
    field: "AirPort",
    headerName: "Air Port",
    width: 30,
    ColomnType: ColomnType.YESNO,
  },
  {
    field: "Active",
    headerName: "Active",
    width: 30,
    ColomnType: ColomnType.YESNO,
  },
  {
    width: 30,
    ColomnType: ColomnType.EDITBUTTON,
  },
];
