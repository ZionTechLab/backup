import React from "react";
import { useState } from "react";
import classes from "./AppBar.module.css";
import Drawer from "../Drawer";
import { BrowserRouter as Router, Route, Link, Routes } from "react-router-dom";
import Location from "../../Pages/Locations/Location.js";
import Vessels from "../../Pages/Vessels/Vessel.js";
import Commodity from "../../Pages/Commodity/Commodity.js";
import Packages from "../../Pages/Packs/Package.js";

const AppBar = (props) => {
  const [state, setState] = useState({ isOpen: false });

  const toggleDrawer = (status) => {
    console.log(state);
    setState({ ...state, isOpen: status === true ? !state.isOpen : false });
  };

  const AppBar = (
    <div>
      <div className={classes.appbar}>
        <div className={classes.menubtn} onClick={() => toggleDrawer(true)}>
          &#9776;
        </div>
        <div>
          {/* <a href="#">Logo</a>
          <a href="#">Home</a>
          <a href="#">About</a>
          <a href="#">Services</a>
          <a href="#">Contact</a> */}
        </div>
      </div>
      <Drawer isOpen={state.isOpen} closeDrawer={() => toggleDrawer(false)} />
    </div>
  );

  return (
    <div>
      <Router>
        {AppBar}

        <Routes>
          <Route exact path="/" element={<h1>Welcome</h1>} />{" "}
          <Route exact path="Admin" element={<h1>Admin</h1>} />
          <Route exact path="Location" element={<Location />} />
          <Route exact path="Vessel" element={<Vessels />} />
          <Route exact path="Commodity" element={<Commodity />} />
          <Route exact path="Packages" element={<Packages />} />
          {/* <Route exact path="page2" element={<Page2 />} />
        <Route exact path="page3" element={<Page3 />} /> */}
          <Route exact path="/*" element={<h1>not found</h1>} />
        </Routes>
      </Router>
    </div>
  );
};

export default AppBar;
