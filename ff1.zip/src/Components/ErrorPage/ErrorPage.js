// import "./App.css";
import React, { useEffect, useState } from "react";
import style from "./LoadingPage.css";

function App(props) {
  return <div className="Loading">{props.messege}</div>;
}

export default App;
