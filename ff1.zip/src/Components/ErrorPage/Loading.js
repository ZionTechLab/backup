import React, { useEffect, useState } from "react";
import { New, Save, Loading } from "../Icons";
import style from "./LoadingPage.css";

function LoadingPage(props) {
  return (
    <div className="Loading">
      <div>
        <Loading />
      </div>
    </div>
  );
}

export default LoadingPage;
