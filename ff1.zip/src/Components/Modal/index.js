import React, { useState } from "react";
import style from "./Modal.css";
import { Close } from "../Icons";

const Modal = (props) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3> {props.title}</h3>
          <Close className="BtnClose" onClick={() => props.handleClose()} />
        </div>
        <div className="modal-body">{props.children}</div>
      </div>
    </div>
  );
};
export default Modal;
