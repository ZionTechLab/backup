export const ColomnType = {
  EDITBUTTON: 1,
  YESNO: 2,
  TEXT: 3,
  INT: 4,
  DECIMAL: 5,
};
