import React, { useState, useEffect } from "react";
import "./DataGridView.css";
import { MdiFileDocumentEditOutline, Tick } from "../Icons";
import { ColomnType } from "./enum";

let grid = "";

function DataGridView(props) {
  useEffect(() => {}, props.Binding);

  const handleEditClick = (row) => {
    props.onEditClick(row);
  };  

  const handleRightClick = (event) => {

    const tableData = getTableData(event.currentTarget); 
    const tsvData = tableData.map((row) => row.join("\t")).join("\n"); // Convert table to TSV

    navigator.clipboard
      .writeText(tsvData)
      .then(() => console.log("Copied table as TSV!"))
      .catch((err) => console.error("Failed to copy:", err));

     
    // ... existing code to prevent default context menu

    // console.log(event.currentTarget);
    // const target = event.currentTarget;
    // const textToCopy = target.textContent || target.value; // Get text content or value

    // if (!navigator.clipboard) {
    //   return; // Clipboard API not supported
    // }

    // navigator.clipboard.write(textToCopy).then(
    //   () => {
    //     console.log("Copied to clipboard!");
    //   },
    //   (err) => {
    //     console.error("Failed to copy:", err);
    //   }
    // );

    // event.preventDefault(); // Prevent default context menu
    // // Your custom right-click logic here (e.g., display a custom menu)
  };

  function getTableData(element) {
    const rows = element.querySelectorAll("tr");
    const data = [];
    rows.forEach((row) => {
      const rowData = [];
      const cells = row.querySelectorAll("td, th");
      cells.forEach((cell) => rowData.push(cell.textContent));
      data.push(rowData);
    });
    return data;
  }

  const switchField = (column, row) => {
    switch (column.ColomnType) {
      case ColomnType.EDITBUTTON:
        return (
          <td
            onClick={() => handleEditClick(row)}
            key={column.id}
            style={{ textAlign: "center" }}
          >
            <MdiFileDocumentEditOutline />
          </td>
        );
      case ColomnType.YESNO:
        return (
          <td key={column.id} style={{ textAlign: "center" }}>
             {row[column.field] === 'Y' ? <Tick /> : ''}
          </td>
        );
      default:
        return <td key={column.id}>{row[column.field]}</td>;
    }
  };

  grid =
    props.Binding != [] && props.Binding != null ? (
      <div>
        <table onContextMenu={handleRightClick}>
          <thead>
            <tr>
              {props.columns.map((column) => (
                <th
                  key={column.id}
                  style={{
                    width: column.width,
                  }}
                >
                  {column.headerName}{" "}
                </th>
              ))}
            </tr>
            {props.Binding.map((row) => (
              <tr>{props.columns.map((column) => switchField(column, row))}</tr>
            ))}
          </thead>
        </table>
      </div>
    ) : (
      ""
    );

  return <div>{grid}</div>;
}

export default DataGridView;
