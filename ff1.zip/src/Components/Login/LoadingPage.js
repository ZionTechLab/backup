import React, { useEffect, useState } from 'react';
import classes from "./LoadingPage.module.css";
import LoginPage from './LoginPage';
//import Content from './Content';

function LoadingPage() {
  const [displayPage, setdisplayPage] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setdisplayPage(true);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      {displayPage ? <LoginPage /> : <Content />}
    </div>
  );
}

function Content() {
  return (
    <div className={classes.container}>
      <div className={classes.top}>
        <img className={classes.Logo} alt="" src={"/Resourses/Logo-512.png"} />
      </div>
    </div>
  );
}

export default LoadingPage;