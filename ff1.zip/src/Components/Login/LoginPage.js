import React, { useEffect, useState } from "react";
import classes from "./LoginPage.module.css";
import { TextField, FormControl } from "../FormControls";
import { useFormik } from "formik";
import * as Yup from "yup";
import { Save } from "../../Components/Icons";
import { Button } from "../../Components/FormControls/Button";

function LoginPage() {
  const validationSchema = Yup.object().shape({
    UnlocCode: Yup.string()
      .max(3, "Maximum characters 3")
      .required("UnlocCode is required"),
    UnlocName: Yup.string()
      .max(50, "Location Name is required")
      .required("Location Name is required"),
  });

  let formik = useFormik({
    initialValues: {
      UnlocCode: " ",
      UnlocName: " ",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      //   dispatch(saveLocations({ formik: values, additionalData: combinedData }));
      handleClose();
    },
  });

  const handleClose = () => {};
  // setModalStatus({ isopen: false, isEditMode: false });

  return (
    <div className={classes.container}>
      <div className={classes.top}>
        <img className={classes.Logo} alt="" src={"/Resourses/Logo-512.png"} />
      </div>
      <div className={classes.Auth}>
        <form onSubmit={formik.handleSubmit}>
          <TextField
            className={classes.Field}
            id="Username"
            Caption="Username"
            // value={selectedRow.UnlocCode || ""}
            Binding={formik}
          />
          <TextField
            id="Password"
            Caption="Password"
            // value={selectedRow.UnlocName || ""}
            Binding={formik}
          />

          <FormControl>{/* <SaveButton /> */}</FormControl>
        </form>
      </div>
    </div>
  );
}

export default LoginPage;
