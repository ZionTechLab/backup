import React from "react";

let Yellow = "#1982C4";

export {
  MaterialSymbolsLightNearMeRounded,
  MdiFileDocumentEditOutline,
  New,
  Save,
};
