import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import Inventory2OutlinedIcon from "@mui/icons-material/Inventory2Outlined";
import InventoryOutlinedIcon from "@mui/icons-material/InventoryOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";

export const MenuItems = [
  [<HomeOutlinedIcon />, "Home"],
  [<AdminPanelSettingsIcon />, "Admin"],
  [<Inventory2OutlinedIcon />, "Inventory"],
  [<InventoryOutlinedIcon />, "Outstanding"],
  [<HelpOutlineOutlinedIcon />, "Location"],
  [<HelpOutlineOutlinedIcon />, "Vessel"],
  [<HelpOutlineOutlinedIcon />, "Vessel2"],
  [<HelpOutlineOutlinedIcon />, "Help"],
  [<HelpOutlineOutlinedIcon />, "test"],
  [<HelpOutlineOutlinedIcon />, "Commodity"],
  [<HelpOutlineOutlinedIcon />, "Package"],
];
