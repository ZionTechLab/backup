import DataGridView from "./DataGridView";
import InsertRecord from "./InsertRecord";

import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";

import style from "./Location.module.css";
import axios from "axios";
//import { useState } from "react";
import React, { useState, useEffect } from "react";

import * as Config from "../../Common/Config";

function Location() {
  const [ModalData, setModalData] = useState({
    isDisplayModal: false,
    rowData: [],
  });
  const [options, setoptions] = useState([]);

  useEffect(() => {
    axios
      .get(Config.API_URL + "Masters/getUI_Country")
      .then((res) => {
        // console.log(res);
        const data = res.data.ReturnValue.CountryUi || [];
        setoptions(data);
        // console.log(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  return (
    <div className={style.container}>
      <div className={style.page}>
        <div className={style.col1}>Location Details</div>

        <div className={style.col2}>
          <Button
            variant="contained"
            onClick={() => {
              setModalData({ isDisplayModal: true, rowData: [] });
            }}
            sx={{ backgroundColor: "#191D88" }}
            fontSize="medium"
            startIcon={<AddIcon />}
          >
            New
          </Button>

          <InsertRecord
            ModalData={ModalData}
            CountryData={options}
            onClose={() => setModalData({ isDisplayModal: false, rowData: [] })}
          />
        </div>
      </div>

      <div className={style.dataGrid}>
        <DataGridView
          onEditClick={(row) =>
            setModalData({ isDisplayModal: true, rowData: row })
          }
        />
      </div>
    </div>
  );
}

export default Location;
