import * as React from "react";
import "./DataGridView.css";
import Box from "@mui/material/Box";
import { DataGrid } from "@mui/x-data-grid";
import IconButton from "@mui/material/IconButton";
import DriveFileRenameOutlineTwoToneIcon from "@mui/icons-material/DriveFileRenameOutlineTwoTone";
import axios from "axios";
import  { useEffect, useState } from "react";

const getRowId = (row) => row.UnlocCode;

function DataGridView(props) {

  const columns = [
    {
      field: "Country",
      headerName: "Country",
      minWidth: 110,
      flex: 1,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "UnloCo",
      headerName: "Un LocCode",
      minWidth: 120,
      flex: 0.3,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "UnlocCode",
      headerName: "UN Location",
      minWidth: 140,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "UnlocName",
      headerName: "Location Name",
      minWidth: 180,
      flex: 1.6,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "SeaPort",
      headerName: "SeaPort",
      width: 90,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "AirPort",
      headerName: "AirPort",
      width: 90,
      headerClassName: "super-app-theme--header",
    },
    {
      headerName: "",
      width: 70,

      field: "Action",
      headerClassName: "super-app-theme--header sticky-header",
      position: "sticky",

      renderCell: (params) => (
        <IconButton onClick={() =>  props.onEditClick(params.row)}>
          <DriveFileRenameOutlineTwoToneIcon sx={{ color: "#FFC436" }} />
        </IconButton>
      ),
    },
  ];

  // const rows = [
  //   {
  //     id: 1,
  //     Country: "USA",
  //     UnLocCode: "USNYC",
  //     UNLocation: "New York City",
  //     LocationName: "JFK Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 2,
  //     Country: "Canada",
  //     UnLocCode: "CAONT",
  //     UNLocation: "Ontario",
  //     LocationName: "Toronto Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 3,
  //     Country: "UK",
  //     UnLocCode: "GBLON",
  //     UNLocation: "London",
  //     LocationName: "Heathrow Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 4,
  //     Country: "Australia",
  //     UnLocCode: "AUSYD",
  //     UNLocation: "Sydney",
  //     LocationName: "Sydney Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 5,
  //     Country: "Germany",
  //     UnLocCode: "DEBER",
  //     UNLocation: "Berlin",
  //     LocationName: "Berlin Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 6,
  //     Country: "China",
  //     UnLocCode: "CNBJP",
  //     UNLocation: "Beijing",
  //     LocationName: "Beijing Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 7,
  //     Country: "Brazil",
  //     UnLocCode: "BRSAO",
  //     UNLocation: "Sao Paulo",
  //     LocationName: "Sao Paulo Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 8,
  //     Country: "India",
  //     UnLocCode: "INDEL",
  //     UNLocation: "Delhi",
  //     LocationName: "Delhi Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 9,
  //     Country: "Japan",
  //     UnLocCode: "JPTKO",
  //     UNLocation: "Tokyo",
  //     LocationName: "Narita Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 10,
  //     Country: "France",
  //     UnLocCode: "FRPAR",
  //     UNLocation: "Paris",
  //     LocationName: "Charles de Gaulle Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 11,
  //     Country: "USA",
  //     UnLocCode: "USNYC",
  //     UNLocation: "New York City",
  //     LocationName: "JFK Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 12,
  //     Country: "Canada",
  //     UnLocCode: "CAONT",
  //     UNLocation: "Ontario",
  //     LocationName: "Toronto Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 13,
  //     Country: "UK",
  //     UnLocCode: "GBLON",
  //     UNLocation: "London",
  //     LocationName: "Heathrow Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 14,
  //     Country: "Australia",
  //     UnLocCode: "AUSYD",
  //     UNLocation: "Sydney",
  //     LocationName: "Sydney Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 15,
  //     Country: "Germany",
  //     UnLocCode: "DEBER",
  //     UNLocation: "Berlin",
  //     LocationName: "Berlin Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 16,
  //     Country: "China",
  //     UnLocCode: "CNBJP",
  //     UNLocation: "Beijing",
  //     LocationName: "Beijing Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 17,
  //     Country: "Brazil",
  //     UnLocCode: "BRSAO",
  //     UNLocation: "Sao Paulo",
  //     LocationName: "Sao Paulo Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 18,
  //     Country: "India",
  //     UnLocCode: "INDEL",
  //     UNLocation: "Delhi",
  //     LocationName: "Delhi Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  //   {
  //     id: 19,
  //     Country: "Japan",
  //     UnLocCode: "JPTKO",
  //     UNLocation: "Tokyo",
  //     LocationName: "Narita Airport",
  //     SeaPort: "Y",
  //     AirPort: "N",
  //   },
  //   {
  //     id: 20,
  //     Country: "France",
  //     UnLocCode: "FRPAR",
  //     UNLocation: "Paris",
  //     LocationName: "Charles de Gaulle Airport",
  //     SeaPort: "N",
  //     AirPort: "Y",
  //   },
  // ];

  const [rows, setRows] = useState([]);

  useEffect(() => {
   
    axios.get("https://edoc-uat.advantis.lk/FFApi/Masters/getUI_Location") 
      .then((res) => { // wait till the response come from API and then execute the function inside the brackets
        console.log(res);
        const data = res.data.ReturnValue || [];
        // const cleanedData = data.map((item) => ({
        //   Country: item.Country.trim(),
        //   UnloCo: item.UnloCo.trim(),
        //   UnlocCode: item.UnlocCode.trim(),
        //   SeaPort: item.SeaPort.trim(),
        //   AirPort: item.AirPort.trim(),
        //   UnlocName: item.UnlocName.trim(),
        //   Active: item.Active.trim(),
        //   USM_ID: item.USM_ID,
        //   USM_DATE: item.USM_DATE,
        //   editClick: item.editClick,
        // }));
        setRows(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
    });
  }, []);

  

  return (

    
    <Box
    
      sx={{
        width: "100%",
        "& .super-app-theme--header": {
          backgroundColor: "rgb(20, 80, 163)",
          fontSize: 18,
          color: "white",
          fontFamily: "verdana",
        },
        "& .action-header": {
          position: "sticky",
          top: 0,
        },

        "& .MuiDataGrid-renderingZone": {
          "& .MuiDataGrid-row": {
            "&:nth-child(2n)": {
              backgroundColor: "rgb(20, 80, 163)",
            },
          },
        },
      }}>


      <DataGrid 
        sx={{
          boxShadow: 10,
          borderColor: "primary.light",
          "& .MuiDataGrid-cell:hover": {
            color: "primary.main",
          },
        }}
        rows={rows}
        columns={columns}
        getRowId={(row) => row.UnlocCode} 
        rowHeight={25}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 15,
            },
          },
        }}
        pageSizeOptions={[15]}
        disableRowSelectionOnClick
      />

    </Box>
  );
}

export default DataGridView;