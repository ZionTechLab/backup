import React, { useState, useEffect } from "react";
import styles from "./InsertRecord.module.css";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import FormLabel from "@mui/material/FormLabel";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import IconButton from "@mui/material/IconButton";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import Button from "@mui/material/Button";
import { useFormik } from "formik";
import * as yup from "yup";
import axios from "axios";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 600,
  bgcolor: "background.paper",
  boxShadow: 25,
};

const validationSchema = yup.object({
  PkgType: yup
    .string("Enter your Package Code")
    // .min(5, "Enter a valid User ID")
    //  .email("Enter a valid User ID")
    .required("Package Type is required"),
  PkgTypeN: yup
    .string("Enter your Package Name")
    // .min(5, "Enter a valid User ID")
    //  .email("Enter a valid User ID")
    .required("Package Name is required"),
});
//rowData, isOpen
function InsertRecord({ ModalData, onClose }) {
  let formik = useFormik({
    initialValues: {
      PkgType: ModalData.rowData.PkgType,
      PkgTypeN: ModalData.rowData.PkgTypeN,
      Active: "",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,

    onSubmit: async (values) => {
      try {
        // Make an API call to save the data
        const response = await saveToDatabase(values);
    
        // Update the local data (ModalData.rowData) with the edited values
        ModalData.rowData.PkgTypeN = values.PkgTypeN;
        ModalData.rowData.Active = values.Active;
    
        // Close the modal or update the grid as needed
        handleClose();
      } catch (error) {
        console.error("Error saving data : ", error);
      }
    }

  });

  // const [formData, setFormData] = useState({});

  useEffect(() => {
    console.log(ModalData);
    formik.resetForm();
  }, [ModalData.rowData]);

  const handleClose = () => {
    onClose(false);
  };

  // const handleChange = (e) => {
  //   formik.handleChange(e);
  //   // console.log('Form Data:', formik.values);
  // };


  // The Api to send data
  const saveToDatabase = async (data) => {
    try {
      await axios.post("https://edoc-uat.advantis.lk/FFApi/Masters/Save_PackTypes", data);
      // console.log("Data saved : ", response.data);
    } catch (error) {
      console.error("Error saving data : ", error);
    }
  };

  return (
    <div>
      <Modal
        open={ModalData.isDisplayModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <form onSubmit={formik.handleSubmit}>
          <Box sx={style} color="error.contrastText" p={1}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className={styles.row0}>
                <p className={styles.heading}>
                  {ModalData.isNewMode === false
                    ? "Edit Package Details"
                    : " Add a New Package "}
                </p>

                <div className={styles.icon}>
                  <IconButton onClick={handleClose} sx={{ marginLeft: "100" }}>
                    <CancelIcon sx={{ color: "white" }} />
                  </IconButton>
                </div>
              </div>

              <div className={styles.row1}>
                <div className={styles.col1}>
                  <FormLabel>Pack Code : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="PkgType"
                    name="PkgType"
                    label=""
                    variant="outlined"
                    // size="small"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.PkgType}
                    sx={{ width: "130px", marginRight: "10px", marginTop: -1 }}
                    error={
                      formik.touched.PkgType && Boolean(formik.errors.PkgType)
                    }
                    helperText={formik.touched.PkgType && formik.errors.PkgType}
                    disabled={!ModalData.isNewMode}
                  /> 
                </div>
              </div>

              <div className={styles.row2}>
                <div className={styles.col1}>
                  <FormLabel>Pack Name : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="PkgTypeN"
                    name="PkgTypeN"
                    variant="outlined"
                    
                    label=""
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.PkgTypeN}
                    sx={{ width: "500px", marginRight: "10px" }}
                    error={
                      formik.touched.PkgTypeN &&
                      Boolean(formik.errors.PkgTypeN)
                    }
                    helperText={formik.error}
                    //{formik.touched.UNLocation && formik.errors.UNLocation}
                  />
                </div>
              </div>

              <div className={styles.row4}>
                <div className={styles.col2}>
                  <FormControlLabel
                    control={<Checkbox defaultChecked/>}
                    label="Active"
                    sx={{ color: "gray", marginLeft: -2, marginRight: 4.5 }}
                  />

                  <Button
                    // onClick={handleSubmit}
                    variant="contained"
                    color="success"
                    fontSize="medium"
                    type="submit"
                    startIcon={<SaveIcon />}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </Typography>
          </Box>
        </form>
      </Modal>
    </div>
  );
}

export default InsertRecord;
