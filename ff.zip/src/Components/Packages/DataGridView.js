import * as React from "react";
import "./DataGridView.css";
import Box from "@mui/material/Box";
import { DataGrid } from "@mui/x-data-grid";
import IconButton from "@mui/material/IconButton";
import DriveFileRenameOutlineTwoToneIcon from "@mui/icons-material/DriveFileRenameOutlineTwoTone";
import { useEffect, useState } from "react";
import axios from "axios";

// const getRowId = (row) => row.PkgType;

function DataGridView(props) {

  const columns = [
    {
      field: "SNo" ,
      headerName: "S No",
      minWidth: 180,
      flex: 0.5,
      headerClassName: "super-app-theme--header",
      hide: true,
    },
    {
      field: "PkgType",
      headerName: "Pkg Type",
      minWidth: 110,
      flex: 0.5,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "PkgTypeN",
      headerName: "Package Name",
      minWidth: 120,
      flex: 0.5,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "Active",
      headerName: "Active",
      minWidth: 140,
      flex: 0.2,
      headerClassName: "super-app-theme--header",
    },
    {
      headerName: "",
      width: 70,

      field: "Action",
      headerClassName: "super-app-theme--header sticky-header",
      position: "sticky",

      renderCell: (params) => (
        <IconButton onClick={() =>  props.onEditClick(params.row)}>
          <DriveFileRenameOutlineTwoToneIcon sx={{ color: "#FFC436" }} />
        </IconButton>
      ),
    },
  ];

  const [rows, setRows] = useState([]);

  useEffect(() => {

    axios.get("https://edoc-uat.advantis.lk/FFApi/Masters/getUI_PackTypes")

      .then((res) => { // wait till the response come from API and then execute the function inside the brackets

        console.log(res);

        const data = res.data.ReturnValue || [];

        // const cleanedData = data.map((item) => ({

        //   SNo: item.SNo.trim(),

        //   PkgType: item.PkgType.trim(),

        //   PkgTypeN: item.PkgTypeN.trim(),

        //   Active: item.Active.trim(),

        //   editClick: item.editClick,

        // }));

        setRows(data);

      })

      .catch((error) => {

        console.error("Error fetching data:", error);

    });

  }, []);


  return (
    <Box
      sx={{
        width: "100%",
        "& .super-app-theme--header": {
          backgroundColor: "rgb(20, 80, 163)",
          fontSize: 18,
          color: "white",
          fontFamily: "verdana",
        },
        "& .action-header": {
          position: "sticky",
          top: 0,
        },

        "& .MuiDataGrid-renderingZone": {
          "& .MuiDataGrid-row": {
            "&:nth-child(2n)": {
              backgroundColor: "rgb(20, 80, 163)",
            },
          },
        },
      }}>

      <DataGrid
        sx={{
          boxShadow: 10,
          borderColor: "primary.light",
          "& .MuiDataGrid-cell:hover": {
            color: "primary.main",
          },
        }}
        rows={rows}
        columns={columns}
        getRowId={(rows) => rows.SNo}
        rowHeight={25}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 15,
            },
          },
        }}
        pageSizeOptions={[15]}
        disableRowSelectionOnClick
      />

    </Box>
  );
}

export default DataGridView;