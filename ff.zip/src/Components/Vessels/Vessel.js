import { useEffect } from "react";
// import axios from "axios";
import DataGridView from "./DataGridView";
import InsertRecord from "./InsertRecord";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
// import { useFormikContext } from 'formik';
import style from "./Vessel.module.css";
import { getVesselData,getCountryProvider,sendData} from './API';
import React, { useState } from 'react';


function Vessel() {
  // const formik = useFormikContext();
  
  const [ModalData, setModalData] = useState({
    isDisplayModal: false,
    isNewMode: false,
    rowData: [],
  });

  // API to load data to DataGrid
  const [dbData, setDbData] =useState([]);
  useEffect(() => {
    //getVesselData()
  }, []);
  

  // API to load data to Country and Provider
  const [options, setOptions] = useState({ CountryData: [], ProviderData: [] });
  const fetchData = () => {
    getCountryProvider()
      .then(([data1, data2]) => {
        setOptions({ CountryData: data1, ProviderData: data2 });
      })
      .catch(error => {
        console.error(error);
      });
  };

  useEffect(() => {
    // Load data when the component mounts
    fetchData();
  }, []); // Empty dependency array to ensure data is loaded only once

  const handleSelectClick = () => {
    // Fetch data when the Select is clicked
    fetchData();
  };
  
  // API to Save Data
  const handleSendData = async (values) => {
    try {
      await sendData(values);
     // const updatedData = await getVesselData();
      //setDbData(updatedData);

    } catch (error) {
      console.error(error);

    }
  };

 
  return (
    <div className={style.container}>
      <div className={style.page}>
        <div className={style.col1}>Vessels Details</div>

        <div className={style.col2}>
          <Button
            variant="contained"
            onClick={() => {
              setModalData({
                isDisplayModal: true,
                isNewMode: true,
                rowData: [],
              });
            }}
            sx={{ backgroundColor: "#191D88" }}
            fontSize="medium"
            startIcon={<AddIcon />}
          >
            New
          </Button>

          {ModalData.isDisplayModal && (
          <InsertRecord
            ModalData={ModalData}
            options={options} handleSelectClick={handleSelectClick}
            sendData={handleSendData}
            onClose={() =>
              setModalData({
                isDisplayModal: false,
                isNewMode: false,
                rowData: [],
              })
            }
          />
          )}
        </div>
      </div>

      <div className={style.dataGrid}>
        <DataGridView
          getVesselData
          onEditClick={(row) =>
            setModalData({
              isDisplayModal: true,
              isNewMode: false,
              rowData: row,
            })
          }
        />
      </div>

{/* <DataGridView dbData={dbData} onEditClick={handleEditClick} /> */}



    </div>
  );
}

export default Vessel;
