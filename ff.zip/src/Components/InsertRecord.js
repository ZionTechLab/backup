import React, { useState, useEffect } from "react";
import styles from "./InsertRecord.module.css";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import FormLabel from "@mui/material/FormLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import IconButton from "@mui/material/IconButton";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import Button from "@mui/material/Button";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useFormik } from "formik";
import * as yup from "yup";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 600,
  bgcolor: "background.paper",
  boxShadow: 25,
};

const validationSchema = yup.object({
  email2: yup
    .string("Enter your User ID")
    .min(5, "Enter a valid User ID")
    //  .email("Enter a valid User ID")
    .required("User ID is required"),
  Country: yup
    .string("Enter your User ID")
    .min(5, "Enter a valid User ID")
    //  .email("Enter a valid User ID")
    .required("User ID is required"),

  UNLocation: yup
    .string()
    .min(1, "Enter a valid UNLocation")
    .max(15, "ade wadi bn")
    .required("UNLocation is required"),

  LocationName: yup
    .string()
    .min(1, "Enter a valid LocationName")
    .max(15, "ade wadi bn")
    .required("LocationName is required"),
});
//rowData, isOpen
function InsertRecord({ ModalData, onClose }) {
  let formik = useFormik({
    initialValues: {
      email2: "",
      Country: ModalData.rowData.Country,
      UnLocCode: "ss",
      UNLocation: "",
      LocationName: "",
      SeaPort: "",
      AirPort: "",
      selectedOption: "",
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      // Handle form submission here, e.g., send data to the server
      console.log("Form data submitted:", values);
    },
  });

  // const [formData, setFormData] = useState({});

  useEffect(() => {
    console.log(ModalData);
    formik.resetForm();
  }, [ModalData.rowData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    // setFormData({
    //   ...formData,
    //   [name]: value,
    // });
    // console.log("Form Data:", formData);
  };

  const options = ["Canada", "Japan", "Africa"];

  const handleSelectChange = (e) => {
    // setFormData({
    //   ...formData,
    //   selectedOption: e.target.value,
    // });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    formik
      .validateForm()
      .then(() => {
        console.log("Form data to be submitted:", formik.values);
        onClose();
      })
      .catch((errors) => {
        // Handle validation errors here if needed
      });

    console.log("Touched:", formik.touched.Country);
    console.log("Errors:", formik.errors.Country);

    onClose();
  };

  const handleClose = () => {
    onClose(false);
  };

  // const handleChange = (e) => {
  //   formik.handleChange(e);
  //   // console.log('Form Data:', formik.values);
  // };

  return (
    <div>
      <Modal
        open={ModalData.isDisplayModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <form onSubmit={formik.handleSubmit}>
          <Box sx={style} color="error.contrastText" p={1}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className={styles.row0}>
                <p className={styles.heading}>
                  {ModalData.isNewMode == false
                    ? "Edit Location Data"
                    : "Add New Location"}
                </p>

                <div className={styles.icon}>
                  <IconButton onClick={handleClose} sx={{ marginLeft: "100" }}>
                    <CancelIcon sx={{ color: "white" }} />
                  </IconButton>
                </div>
              </div>

              <div className={styles.row1}>
                <div className={styles.col1}>
                  <FormLabel>Country : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="Country"
                    name="Country"
                    label="Country"
                    variant="standard"
                    size="small"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.Country}
                    sx={{ width: "130px", marginRight: "10px", marginTop: -1 }}
                    error={
                      formik.touched.Country && Boolean(formik.errors.Country)
                    }
                    helperText={formik.touched.Country && formik.errors.Country}
                  />

                  <FormControl variant="standard">
                    <InputLabel
                      id="demo-simple-select-required-label"
                      sx={{
                        //   marginTop: selectedOption ? "-10px" : "0", // Adjust the top margin as needed

                        transition: "margin 0.2s", // Add a transition for smooth animation
                      }}
                    >
                      Temp
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-required-label"
                      id="demo-simple-select-required"
                      // value={age}
                      variant="standard"
                      size="small"
                      label="Temp"
                      sx={{ height: "30px", width: "190px", marginTop: 1 }}
                      // value={formData.selectedOption}
                      onBlur={formik.handleBlur}
                      onChange={handleSelectChange}
                    >
                      {options.map((option, index) => (
                        <MenuItem key={index} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </div>
              </div>

              <div className={styles.row2}>
                <div className={styles.col1}>
                  <FormLabel>UN Loc Code / Name : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="filled-basic"
                    name="UNLocation"
                    variant="standard"
                    label="UN Location"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.UNLocation}
                    sx={{ width: "130px", marginRight: "10px" }}
                    error={
                      formik.touched.UNLocation &&
                      Boolean(formik.errors.UNLocation)
                    }
                    helperText={formik.error}
                    //{formik.touched.UNLocation && formik.errors.UNLocation}
                  />

                  <TextField
                    id="filled-basic"
                    name="LocationName"
                    variant="standard"
                    label="Location Name"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.LocationName}
                    sx={{ width: "200px", marginRight: "5px" }}
                    error={
                      formik.touched.LocationName &&
                      Boolean(formik.errors.LocationName)
                    }
                    helperText={
                      formik.touched.LocationName && formik.errors.LocationName
                    }
                  />
                </div>
              </div>

              <div className={styles.row3}>
                <div className={styles.col2}>
                  <FormControlLabel
                    control={<Checkbox />}
                    label="Sea Port"
                    sx={{ color: "gray", marginRight: 4.5 }}
                  />

                  <FormControlLabel
                    control={<Checkbox />}
                    label="Air Port"
                    sx={{ color: "gray" }}
                  />
                </div>
              </div>

              <div className={styles.row4}>
                <div className={styles.col2}>
                  <FormControlLabel
                    control={<Checkbox />}
                    label="Active"
                    sx={{ color: "gray", marginLeft: -2, marginRight: 4.5 }}
                  />

                  <Button
                    // onClick={handleSubmit}
                    variant="contained"
                    color="success"
                    fontSize="medium"
                    type="submit"
                    startIcon={<SaveIcon />}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </Typography>
          </Box>
        </form>
      </Modal>
    </div>
  );
}

export default InsertRecord;
