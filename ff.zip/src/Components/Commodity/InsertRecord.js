import React, { useState, useEffect } from "react";
import styles from "./InsertRecord.module.css";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import FormLabel from "@mui/material/FormLabel";
// import Select from "@mui/material/Select";
// import MenuItem from "@mui/material/MenuItem";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import IconButton from "@mui/material/IconButton";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import Button from "@mui/material/Button";
// import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useFormik } from "formik";
import * as yup from "yup";
import DataGridView from "./DataGridView";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 600,
  bgcolor: "background.paper",
  boxShadow: 25,
};

const validationSchema = yup.object({
  CommodityType: yup
    .string("Enter your Commodity Code")
    // .min(5, "Enter a valid User ID")
    // .email("Enter a valid User ID")
    .required("Commodity Code is required"),
  CommodityTypeN: yup
    .string("Enter your Commodity Name")
    // .min(5, "Enter a valid User ID")
    // .email("Enter a valid User ID")
    .required("Commodity Name is required"),

});
//rowData, isOpen
function InsertRecord({ ModalData, onClose }) {
  let formik = useFormik({
    initialValues: {
      CommodityType: ModalData.rowData.CommodityType,
      CommodityTypeN: ModalData.rowData.CommodityTypeN, 
      
    },
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      // Handle form submission here, e.g., send data to the server
      console.log("Form data submitted:", values);
    },
  });


  useEffect(() => {
    console.log(ModalData);
    formik.resetForm();
  }, [ModalData.rowData]);


  const handleClose = () => {
    onClose(false);
  };

  // const handleChange = (e) => {
  //   formik.handleChange(e);
  //   // console.log('Form Data:', formik.values);
  // };

  return (
    <div>
      
      <Modal
        open={ModalData.isDisplayModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <form onSubmit={formik.handleSubmit}>
          <Box sx={style} color="error.contrastText" p={1}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className={styles.row0}>
                <p className={styles.heading}>
                  {ModalData.isNewMode === false
                    ? "Edit Commodity Details"
                    : "Add a new commodity"}
                </p>

                <div className={styles.icon}>
                  <IconButton onClick={handleClose} sx={{ marginLeft: "100" }}>
                    <CancelIcon sx={{ color: "white" }} />
                  </IconButton>
                </div>
              </div>

              <div className={styles.row1}>
                <div className={styles.col1}>
                  <FormLabel>C. Code : </FormLabel>
                </div>
                
                <div className={styles.col2}>
                  <TextField
                    id="CommodityType"
                    name="CommodityType"
                    label=""
                    variant="outlined"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.CommodityType}
                    sx={{ width: "130px", marginRight: "10px", marginTop: -1 }}
                    error={
                      formik.touched.CommodityType && Boolean(formik.errors.CommodityType)
                    }
                    helperText={formik.touched.CommodityType && formik.errors.CommodityType}
                  /> 
                </div>
              </div>

              <div className={styles.row2}>
                <div className={styles.col1}>
                  <FormLabel>Commodity : </FormLabel>
                </div>

                <div className={styles.col2}>
                  <TextField
                    id="CommodityTypeN"
                    name="CommodityTypeN"
                    variant="outlined"
                    
                    label=""
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.CommodityTypeN}
                    sx={{ width: "500px", marginRight: "10px" }}
                    error={
                      formik.touched.CommodityTypeN &&
                      Boolean(formik.errors.CommodityTypeN)
                    }
                    helperText={formik.error}
                    // {formik.touched.CommodityTypeN && formik.errors.CommodityTypeN}
                  /> 
                </div>
              </div>

              <div className={styles.row4}>
                <div className={styles.col2}>
                  <FormControlLabel
                    control={<Checkbox defaultChecked/>}
                    label="Active"
                    sx={{ color: "gray", marginLeft: -2, marginRight: 4.5 }}
                  />

                  <Button
                    // onClick={handleSubmit}
                    variant="contained"
                    color="success"
                    fontSize="medium"
                    type="submit"
                    startIcon={<SaveIcon />}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </Typography>
          </Box>
        </form>
      </Modal>
    </div>
  );
}

export default InsertRecord;

