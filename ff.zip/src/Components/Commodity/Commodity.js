import { useState } from "react";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
import DataGridView from "./DataGridView";
import InsertRecord from "./InsertRecord";
import style from "./Commodity.module.css";

function Commodity() {
  const [ModalData, setModalData] = useState({
    isDisplayModal: false,
    isNewMode: false,
    rowData: [],
  });

  return (
    <div className={style.container}>
      <div className={style.page}>
        <div className={style.col1}>Commodity Details</div>

        <div className={style.col2}>
          <Button
            variant="contained"
            onClick={() => {
              setModalData({
                isDisplayModal: true,
                isNewMode: true,
                rowData: [],
              });
            }}
            sx={{ backgroundColor: "#191D88" }}
            fontSize="medium"
            startIcon={<AddIcon />}
          >
            New
          </Button>

          <InsertRecord
            ModalData={ModalData}
            onClose={() =>
              setModalData({
                isDisplayModal: false,
                isNewMode: false,
                rowData: [],
              }) 
            }
           
          />
        </div>
      </div>

      <div className={style.dataGrid}>
        <DataGridView
          onEditClick={(row) =>{
            console.log(row);
            setModalData({
              isDisplayModal: true,
              isNewMode: false,
              rowData: row,
            })}
          }
        />
      </div>
    </div>
  );
}

export default Commodity;
