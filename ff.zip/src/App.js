import "./App.css";
//import Test from "./Components/item2";
import React, { useState, useEffect } from "react";
//import Item from "./Components/Inventory";
//import RouteWiseCustomers from "./Components/Customer/Customer2";
import Drawer from "./Components/Drawer";
import Spinner from "./Components/Spinner/Spinner";
import { useDispatch, useSelector } from "react-redux";
import { setAuthStatus, init } from "./store";
// import classes from "./Components/Drawer/Drawer.module.css";
import Location from "./Components/Locations/Location.js"
import Commodity from './Components/Commodity/DataGridView';

function App() {
  const dispatch = useDispatch();

  const authData = useSelector((state) => {
    return state.auth;
  });

  // const [count, setCount] = React.useState(1);
  // const [isInit, setStatus] = useState(false);

  useEffect(() => {
    console.log("Use effect - Auth data changed");

    if (authData.isAuthOK == true && authData.isInitOK == false) {
      //   console.log(authData);

      dispatch(
        init({
          user_id: authData.user_id,
        })
      );
    }
    // console.log(authData);
  }, [authData.isAuthOK, authData.isInitOK]);

  let contains = "";
  // if (authData.isAuthOK == false) contains = "login";
  //else if (authData.isAuthOK == true && authData.isInitOK == false)
  //  contains = <Spinner />;
  // else if (authData.isAuthOK == true && authData.isInitOK == true) {
  contains = (
    <div className="aa">
      {/* //className={classes.Container} */}
      <Drawer />

      {(() => {
        switch (authData.ActiveForm) {
          case "Home":
            return "Welcome";
          case "Admin":
            return "admin";
          case "Inventory":
            return "item";
          case "Outstanding":
            return "customers";
          case "Location":
            return <Location />;
          case "Commodity":
            return <Commodity />;
          
          
          default:
            return "404";
        }
      })()}
    </div>
  );
  // }

  return <div>{contains}</div>;
}

export default App;

// import DataGridView from "./Components/DataGridView";
// import InsertRecord from "./Components/InsertRecord";

// import AddIcon from "@mui/icons-material/Add";
// import Button from "@mui/material/Button";

// import style from "./App.module.css";

// import { useState } from "react";

// function App() {
//   const [ModalData, setModalData] = useState({
//     isDisplayModal: false,
//     isNewMode: false,
//     rowData: [],
//   });

//   return (
//     <div className={style.container}>
//       <div className={style.page}>
//         <div className={style.col1}>Location Details</div>

//         <div className={style.col2}>
//           <Button
//             variant="contained"
//             onClick={() => {
//               setModalData({
//                 isDisplayModal: true,
//                 isNewMode: true,
//                 rowData: [],
//               });
//             }}
//             sx={{ backgroundColor: "#191D88" }}
//             fontSize="medium"
//             startIcon={<AddIcon />}
//           >
//             New
//           </Button>

//           <InsertRecord
//             ModalData={ModalData}
//             onClose={() =>
//               setModalData({
//                 isDisplayModal: false,
//                 isNewMode: false,
//                 rowData: [],
//               })
//             }
//           />
//         </div>
//       </div>

//       <div className={style.dataGrid}>
//         <DataGridView
//           onEditClick={(row) =>
//             setModalData({
//               isDisplayModal: true,
//               isNewMode: false,
//               rowData: row,
//             })
//           }
//         />
//       </div>
//     </div>
//   );
// }

// export default App;
