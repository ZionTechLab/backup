export const API_URL = "https://edoc-uat.advantis.lk/FFApi/";
